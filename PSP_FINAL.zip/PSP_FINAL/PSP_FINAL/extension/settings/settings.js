// PhishingShield Pro v4.1 — Settings JS
// Developer: Payal Gandharba | NP069619 | CT052-3-3-IR

document.addEventListener('DOMContentLoaded', function() {

  // Back button
  var backBtn = document.getElementById('backBtn');
  if (backBtn) backBtn.addEventListener('click', function() {
    chrome.windows.create({ url: chrome.runtime.getURL('popup/popup.html'), type:'popup', width:390, height:600, focused:true });
    window.close();
  });

  // Sidebar navigation
  document.querySelectorAll('.nav-item').forEach(function(item) {
    item.addEventListener('click', function() {
      document.querySelectorAll('.nav-item').forEach(function(n){ n.classList.remove('active'); });
      document.querySelectorAll('.sec').forEach(function(s){ s.classList.remove('active'); });
      item.classList.add('active');
      var sec = item.getAttribute('data-sec');
      var el = document.getElementById('sec-' + sec);
      if (el) el.classList.add('active');
      if (sec === 'whitelist') loadWhitelist();
      if (sec === 'stats')     loadStats();
      if (sec === 'ai')        animateMLBars();
    });
  });

  // Load settings
  loadSettings();
  animateMLBars();

  // Buttons
  var saveBtn = document.getElementById('saveBtn');
  if (saveBtn) saveBtn.addEventListener('click', saveGeneral);

  var saveBtnAI = document.getElementById('saveBtnAI');
  if (saveBtnAI) saveBtnAI.addEventListener('click', saveAI);

  var saveBtnDet = document.getElementById('saveBtnDet');
  if (saveBtnDet) saveBtnDet.addEventListener('click', saveDetection);

  var resetBtn = document.getElementById('resetAllBtn');
  if (resetBtn) resetBtn.addEventListener('click', resetAll);

  var testBtn = document.getElementById('testBtn');
  if (testBtn) testBtn.addEventListener('click', testAPI);

  var clrCache = document.getElementById('clrCacheBtn');
  if (clrCache) clrCache.addEventListener('click', clearCache);

  var clrStats = document.getElementById('clrStatsBtn');
  if (clrStats) clrStats.addEventListener('click', clearHistory);

  var clrStats2 = document.getElementById('clrStatsBtn2');
  if (clrStats2) clrStats2.addEventListener('click', function() {
    if (!confirm('Reset all statistics?')) return;
    chrome.storage.local.set({ scanHistory:[], history:[], statsTotal:0, statsBlocked:0, statsWarned:0, statsSafe:0, streak:0, totalAvoided:0 }, function() {
      loadStats(); toast('✓ Statistics reset!');
    });
  });

  var wlAdd = document.getElementById('wlAddBtn');
  if (wlAdd) wlAdd.addEventListener('click', addWhitelist);

  var wlIn = document.getElementById('wlIn');
  if (wlIn) wlIn.addEventListener('keydown', function(e){ if(e.key==='Enter') addWhitelist(); });
});

// ── LOAD SETTINGS ─────────────────────────────────────
function loadSettings() {
  chrome.storage.local.get([
    'enabled','blockEnabled','warnEnabled','notifyEnabled',
    'warnThreshold','blockThreshold',
    'mlEnabled','heurEnabled','hoverEnabled','cacheEnabled','notifyWarn',
    'heurEnabled2','mlEnabled2','cacheEnabled2',
    'apiEndpoint'
  ], function(d) {
    setChk('s_enabled',      d.enabled      !== false);
    setChk('s_blockEnabled', d.blockEnabled !== false);
    setChk('s_warnEnabled',  d.warnEnabled  !== false);
    setChk('s_notifyEnabled',d.notifyEnabled !== false);
    setChk('s_mlEnabled',    d.mlEnabled    !== false);
    setChk('s_heurEnabled',  d.heurEnabled  !== false);
    setChk('s_hoverEnabled', d.hoverEnabled !== false);
    setChk('s_cacheEnabled', d.cacheEnabled !== false);
    setChk('s_notifyWarn',   d.notifyWarn   !== false);
    setChk('s_heurEnabled2', d.heurEnabled2 !== false);
    setChk('s_mlEnabled2',   d.mlEnabled2   !== false);
    setChk('s_cacheEnabled2',d.cacheEnabled2 !== false);

    var wt = d.warnThreshold  || 70;
    var bt = d.blockThreshold || 90;
    setVal('s_warnThreshold',  wt);
    setVal('s_blockThreshold', bt);
    updateThresholdRanges(wt, bt);

    var api = document.getElementById('s_apiEndpoint');
    if (api) api.value = d.apiEndpoint || 'http://localhost:8000';
  });
}

function setChk(id, val) { var el=document.getElementById(id); if(el) el.checked=val; }
function setVal(id, val) { var el=document.getElementById(id); if(el) el.value=val; }

// ── THRESHOLD RANGES ──────────────────────────────────
function updateThresholdRanges(wt, bt) {
  var sr = document.getElementById('safeRange');
  var wr = document.getElementById('warnRange');
  var br = document.getElementById('blockRange');
  if (sr) sr.textContent = 'Score 0 – '+(wt-1);
  if (wr) wr.textContent = 'Score '+wt+' – '+(bt-1);
  if (br) br.textContent = 'Score '+bt+' – 100';
}

// ── SAVE FUNCTIONS ────────────────────────────────────
function saveGeneral() {
  var wt = parseInt(document.getElementById('s_warnThreshold').value) || 70;
  var bt = parseInt(document.getElementById('s_blockThreshold').value) || 90;
  if (wt >= bt) { toast('⚠️ Warn must be lower than Block!'); return; }
  chrome.storage.local.set({
    enabled:       getChk('s_enabled'),
    blockEnabled:  getChk('s_blockEnabled'),
    warnEnabled:   getChk('s_warnEnabled'),
    notifyEnabled: getChk('s_notifyEnabled'),
    warnThreshold:  wt,
    blockThreshold: bt
  }, function() {
    updateThresholdRanges(wt, bt);
    toast('✓ General settings saved!');
  });
}

function saveAI() {
  var api = document.getElementById('s_apiEndpoint').value.trim();
  chrome.storage.local.set({
    mlEnabled:    getChk('s_mlEnabled'),
    heurEnabled:  getChk('s_heurEnabled'),
    hoverEnabled: getChk('s_hoverEnabled'),
    cacheEnabled: getChk('s_cacheEnabled'),
    notifyWarn:   getChk('s_notifyWarn'),
    apiEndpoint:  api || 'http://localhost:8000'
  }, function() { toast('✓ AI settings saved!'); });
}

function saveDetection() {
  chrome.storage.local.set({
    heurEnabled2: getChk('s_heurEnabled2'),
    mlEnabled2:   getChk('s_mlEnabled2')
  }, function() { toast('✓ Detection settings saved!'); });
}

function getChk(id) { var el=document.getElementById(id); return el ? el.checked : false; }

// ── API TEST ──────────────────────────────────────────
function testAPI() {
  var api = (document.getElementById('s_apiEndpoint').value || 'http://localhost:8000').trim();
  var res = document.getElementById('apiStatus');
  if (res) res.textContent = 'Testing…';
  fetch(api+'/health', { signal:AbortSignal.timeout(3000) })
    .then(function(r){ return r.json(); })
    .then(function(d){
      if (res) { res.textContent='✓ Connected · v'+(d.version||'4.1'); res.style.color='var(--green)'; }
      if (d.rf_accuracy)  document.getElementById('rfAcc').textContent  = d.rf_accuracy+'%';
      if (d.svm_accuracy) document.getElementById('svmAcc').textContent = d.svm_accuracy+'%';
      if (d.features)     document.getElementById('featCount').textContent = d.features;
      toast('✓ API connected!');
    })
    .catch(function(){
      if (res) { res.textContent='✗ Offline — run RUN_API.bat'; res.style.color='var(--red)'; }
      toast('✗ API offline');
    });
}

// ── ML BARS ───────────────────────────────────────────
function animateMLBars() {
  setTimeout(function() {
    var bars = { rfBar:97.75, svmBar:93.63, ensBar:97.57, uavBar:99.55 };
    Object.keys(bars).forEach(function(id) {
      var el = document.getElementById(id); if(el) el.style.width = bars[id]+'%';
    });
  }, 400);
}

// ── WHITELIST ─────────────────────────────────────────
function loadWhitelist() {
  chrome.storage.local.get('whitelist', function(d) {
    var list = d.whitelist || [];
    var wc   = document.getElementById('wlCount');
    var el   = document.getElementById('wlList');
    if (wc) wc.textContent = list.length+' sites';
    if (!el) return;
    if (!list.length) {
      el.innerHTML='<div style="color:var(--muted);font-size:12px;padding:12px 16px;font-family:\'DM Mono\',monospace;">No trusted domains yet</div>';
      return;
    }
    el.innerHTML = list.map(function(domain) {
      return '<div class="wl-item">'
        +'<span class="wl-domain">'+domain+'</span>'
        +'<button class="wl-rm" onclick="removeWhitelist(\''+domain+'\')">✕ Remove</button>'
        +'</div>';
    }).join('');
  });
}

function addWhitelist() {
  var inp = document.getElementById('wlIn');
  var val = inp ? inp.value.trim().toLowerCase().replace(/^https?:\/\//,'').replace(/\/.*/,'') : '';
  if (!val) { toast('⚠️ Enter a domain first'); return; }
  chrome.storage.local.get('whitelist', function(d) {
    var list = d.whitelist || [];
    if (list.includes(val)) { toast('⚠️ Already trusted!'); return; }
    list.push(val);
    chrome.storage.local.set({ whitelist:list }, function() {
      inp.value=''; loadWhitelist(); toast('✓ '+val+' trusted!');
    });
  });
}

function removeWhitelist(domain) {
  chrome.storage.local.get('whitelist', function(d) {
    var list = (d.whitelist||[]).filter(function(x){ return x!==domain; });
    chrome.storage.local.set({ whitelist:list }, function() {
      loadWhitelist(); toast('✓ '+domain+' removed!');
    });
  });
}

// ── STATS ─────────────────────────────────────────────
function loadStats() {
  chrome.storage.local.get(['scanHistory','history'], function(d) {
    var h   = d.scanHistory || d.history || [];
    var blk = h.filter(function(x){ return (x.status||'').toLowerCase()==='blocked'; }).length;
    var wrn = h.filter(function(x){ return (x.status||'').toLowerCase()==='warned'; }).length;
    var t   = document.getElementById('ss_tot');  if(t) t.textContent=h.length;
    var b   = document.getElementById('ss_blk');  if(b) b.textContent=blk;
    var w   = document.getElementById('ss_wrn');  if(w) w.textContent=wrn;
  });
}

// ── PRIVACY ───────────────────────────────────────────
function clearCache() {
  chrome.storage.local.remove(['scanCache','urlCache'], function() {
    toast('✓ Scan cache cleared!');
  });
}

function clearHistory() {
  if (!confirm('Clear all scan history? This cannot be undone.')) return;
  chrome.storage.local.set({ scanHistory:[], history:[], statsTotal:0, statsBlocked:0, statsWarned:0, statsSafe:0 }, function() {
    toast('✓ Scan history cleared!');
  });
}

function resetAll() {
  if (!confirm('Reset ALL settings to default? This cannot be undone.')) return;
  chrome.storage.local.clear(function() {
    toast('✓ All settings reset!');
    setTimeout(loadSettings, 300);
  });
}

// ── TOAST ─────────────────────────────────────────────
function toast(msg) {
  var t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2800);
}