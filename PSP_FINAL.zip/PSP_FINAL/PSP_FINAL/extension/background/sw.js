/**
 * PhishingShield Pro v4.1 — Service Worker
 * Developer: Payal Gandharba | NP069619 | CT052-3-3-IR | CyberShield Technologies
 */

const API       = 'http://localhost:8000';
const CACHE_TTL = 600000;
const MAX_CACHE = 500;
const MAX_HIST  = 500;
const WARN      = 70;
const BLOCK     = 90;

const cache    = new Map();
const tabState = new Map();
let whitelist  = new Set();
let blacklist  = new Set();

const MICRO_LESSONS = {
  'IP address as hostname': { title:'🔍 Lesson: IP Address URLs', lesson:'Real websites use domain names, never raw IP addresses. An IP-based URL almost always means the attacker wants to hide the real identity of their server.', tip:'Always check the address bar — if you see numbers like 192.x.x.x instead of a name, leave immediately.', badge:'IP Detective 🕵️' },
  'No HTTPS encryption':    { title:'🔒 Lesson: HTTPS Matters', lesson:'HTTPS encrypts the connection between your browser and the website. Without it, anyone on the same network can intercept your passwords and personal data.', tip:'Look for the padlock icon in the address bar. No padlock = no encryption = not safe.', badge:'HTTPS Guardian 🔐' },
  'Suspicious free TLD':    { title:'🌐 Lesson: Free Domain Tricks', lesson:'Domains ending in .tk, .ml, .ga, .cf, .gq, .xyz are free to register with no identity verification, making them popular with phishing attackers.', tip:'Legitimate company websites almost always use .com, .org, .gov, or their country TLD.', badge:'Domain Expert 🌐' },
  'Brand impersonation on free TLD': { title:'⚠️ Lesson: Brand Impersonation', lesson:'Attackers create URLs like "paypal-secure-login.tk" to trick you. The real paypal.com would never use a free .tk domain.', tip:'Always verify the exact domain — paypal.com is safe, paypal-anything-else.tk is fake.', badge:'Impersonation Spotter 🎭' },
  'Brand + phishing keywords': { title:'🚨 Lesson: Urgency + Brand = Red Flag', lesson:'Phishing attacks combine a trusted brand with urgent words like "verify", "suspend", "alert" to make you panic and act without thinking.', tip:'If a link says your account is "suspended" or needs "urgent verification", go directly to the official website.', badge:'Urgency Avoider 🧘' },
  'URL shortener used':     { title:'🔗 Lesson: Hidden Destinations', lesson:'URL shorteners hide the real destination. Attackers use them to disguise phishing URLs.', tip:'Use a URL expander to see the real destination before clicking shortened links.', badge:'Link Inspector 🔗' },
  'Phishing keywords detected': { title:'💬 Lesson: Phishing Vocabulary', lesson:'Phishing URLs often contain words like "verify", "secure", "alert", "confirm", "suspended", "login". These are rarely in URLs of legitimate sites.', tip:'If a URL contains multiple alarming words, treat it with extreme suspicion.', badge:'Word Watcher 👀' },
  'default': { title:'🛡️ PhishingShield Pro blocked a threat', lesson:'This website showed multiple signs of being a phishing or malicious site. Our system detected suspicious patterns matching known attack techniques.', tip:'When in doubt, do not click. Go directly to the website by typing the address yourself.', badge:'Threat Avoider 🛡️' }
};

function getMicroLesson(warnings) {
  if (!warnings || warnings.length === 0) return MICRO_LESSONS['default'];
  const priority = ['Brand impersonation on free TLD','IP address as hostname','Brand + phishing keywords','URL shortener used','Suspicious free TLD','No HTTPS encryption','Phishing keywords detected'];
  for (const p of priority) { if (warnings.includes(p)) return MICRO_LESSONS[p]; }
  return MICRO_LESSONS[warnings[0]] || MICRO_LESSONS['default'];
}

function extractFeatures(url) {
  const f = { url_length:0,domain_length:0,path_length:0,query_length:0,num_dots:0,num_hyphens:0,num_digits:0,num_special:0,num_slashes:0,num_subdomains:0,num_at:0,num_equals:0,num_ampersand:0,num_percent:0,has_ip:0,is_https:0,has_subdomain:0,has_susp_kw:0,has_brand:0,has_punycode:0,url_entropy:0,domain_entropy:0,path_entropy:0,ratio_digits:0,ratio_special:0,has_redirect:0,has_login:0,has_verify:0,has_brand_name:0,has_free_tld:0,has_exe:0,has_encoding:0,has_port:0,is_shortened:0,has_double_slash:0,long_url:0,has_tilde:0,suspicious_path:0 };
  try {
    const p = new URL(url.startsWith('http') ? url : 'http://' + url);
    const host = p.hostname.toLowerCase();
    const path = p.pathname.toLowerCase();
    const full = url.toLowerCase();
    f.url_length=url.length; f.domain_length=host.length; f.path_length=path.length; f.query_length=p.search.length;
    f.num_dots=(host.match(/\./g)||[]).length; f.num_hyphens=(host.match(/-/g)||[]).length;
    f.num_digits=(url.match(/\d/g)||[]).length; f.num_special=(url.match(/[!@#$%^&*()_+={}|<>?,]/g)||[]).length;
    f.num_slashes=(url.match(/\//g)||[]).length; f.num_subdomains=host.split('.').length-2;
    f.num_at=(url.match(/@/g)||[]).length; f.num_equals=(url.match(/=/g)||[]).length;
    f.num_ampersand=(url.match(/&/g)||[]).length; f.num_percent=(url.match(/%/g)||[]).length;
    f.has_ip=/^\d{1,3}(\.\d{1,3}){3}$/.test(host)?1:0;
    f.is_https=p.protocol==='https:'?1:0;
    f.has_subdomain=host.split('.').length>2?1:0;
    f.has_susp_kw=/login|verify|secure|account|password|confirm|update|suspend|alert|prize|free|win/.test(full)?1:0;
    f.has_brand=/paypal|amazon|apple|microsoft|google|facebook|netflix|ebay|bank|chase|wellsfargo/.test(full)?1:0;
    // Score path keywords separately so localhost URLs get flagged
    const pathFull = (p.pathname||'').toLowerCase();
    f.has_login  = /login|signin/.test(pathFull)?1:0;
    f.has_verify = /verify|confirm|validate|suspend|alert|account|update|secure/.test(pathFull)?1:0;
    f.suspicious_path = (f.has_login||f.has_verify) && f.has_brand ? 1 : 0;
    f.has_punycode=host.includes('xn--')?1:0;
    const ent=s=>{ if(!s)return 0; const fr={}; for(const c of s)fr[c]=(fr[c]||0)+1; return Object.values(fr).reduce((a,v)=>{ const p=v/s.length; return a-p*Math.log2(p); },0); };
    f.url_entropy=parseFloat(ent(url).toFixed(4)); f.domain_entropy=parseFloat(ent(host).toFixed(4)); f.path_entropy=parseFloat(ent(path||'/').toFixed(4));
    f.ratio_digits=parseFloat((f.num_digits/Math.max(url.length,1)).toFixed(4));
    f.ratio_special=parseFloat((f.num_special/Math.max(url.length,1)).toFixed(4));
    f.has_redirect=/redirect|redir|url=|next=|goto=/i.test(full)?1:0;
    f.has_login=/login|signin|logon/i.test(full)?1:0;
    f.has_verify=/verify|verification|confirm/i.test(full)?1:0;
    f.has_brand_name=f.has_brand;
    f.has_free_tld=/\.(tk|ml|ga|cf|gq|xyz|top|club|online|site)$/i.test(host)?1:0;
    f.has_exe=/\.(exe|zip|bat|sh|dmg|apk)$/i.test(url)?1:0;
    f.has_encoding=/%[0-9a-f]{2}/i.test(url)?1:0;
    f.has_port=!['','80','443'].includes(p.port)?1:0;
    f.is_shortened=/bit\.ly|tinyurl|t\.co|goo\.gl/i.test(host)?1:0;
    f.has_double_slash=url.indexOf('//',8)>8?1:0;
    f.long_url=url.length>100?1:0;
    f.has_tilde=url.includes('~')?1:0;
    f.suspicious_path=/wp-login|phishing|malware/i.test(path)?1:0;
  } catch {}
  return f;
}

function heuristic(f) {
  let s=0; const w=[];
  if(f.has_ip)              { s+=35; w.push('IP address as hostname'); }
  if(!f.is_https)           { s+=15; w.push('No HTTPS encryption'); }
  if(f.has_free_tld)        { s+=25; w.push('Suspicious free TLD'); }
  if(f.num_at>0)            { s+=25; w.push('"@" symbol in URL'); }
  if(f.has_punycode)        { s+=25; w.push('Punycode homoglyph domain'); }
  if(f.has_susp_kw&&f.has_brand){ s+=30; w.push('Brand + phishing keywords'); }
  else if(f.has_susp_kw)   { s+=15; w.push('Phishing keywords detected'); }
  if(f.has_brand&&f.has_free_tld){ s+=20; w.push('Brand impersonation on free TLD'); }
  if(f.has_brand&&!f.is_https)   { s+=15; w.push('Brand site without HTTPS'); }
  if(f.num_hyphens>1)       { s+=10; w.push('Multiple hyphens in domain'); }
  if(f.num_subdomains>3)    { s+=15; w.push('Excessive subdomains'); }
  if(f.url_entropy>4.5)     { s+=10; w.push('High URL entropy'); }
  if(f.long_url)            { s+=10; w.push('Unusually long URL'); }
  if(f.has_redirect)        { s+=15; w.push('Redirect parameter'); }
  if(f.has_exe)             { s+=20; w.push('Executable file extension'); }
  if(f.is_shortened)        { s+=20; w.push('URL shortener used'); }
  if(f.has_double_slash)    { s+=10; w.push('Double slash anomaly'); }
  // Extra: path hyphens (catches localhost:8080/paypal-login-verify-account-suspended)
  if(f.suspicious_path)     { s+=15; w.push('Suspicious path pattern'); }
  if(f.has_login&&f.has_brand){ s+=10; w.push('Login path on brand domain'); }
  if(f.has_verify&&f.has_brand){ s+=10; w.push('Verify path on brand domain'); }
  return { score:Math.min(s,100), warnings:w };
}

async function updateStreak(wasSafe) {
  try {
    const d=await chrome.storage.local.get(['streak','streakBadge','totalAvoided']);
    let streak=d.streak||0, totalAvoided=d.totalAvoided||0, badge=d.streakBadge||'🛡️ Newcomer';
    if(wasSafe){ streak++; } else { totalAvoided++; streak++; }
    if(streak>=100) badge='🏆 Phishing Master';
    else if(streak>=50) badge='💎 Security Pro';
    else if(streak>=25) badge='🥇 Threat Avoider';
    else if(streak>=10) badge='🥈 Stay Safe';
    else if(streak>=5)  badge='🥉 Getting Safer';
    else badge='🛡️ Newcomer';
    await chrome.storage.local.set({ streak, streakBadge:badge, totalAvoided });
    return { streak, badge, totalAvoided };
  } catch { return { streak:0, badge:'🛡️ Newcomer', totalAvoided:0 }; }
}

async function postSIEM(r, apiEndpoint) {
  try {
    await fetch((apiEndpoint||API)+'/api/v1/siem-log', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ url:r.url, score:r.score, verdict:r.status==='blocked'?'BLOCKED':r.status==='warned'?'WARNING':'SAFE', warnings:r.warnings||[], ml_score:r.ml_prob||null }),
      signal:AbortSignal.timeout(2000)
    });
  } catch {}
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({ enabled:true, mlEnabled:true, warnThreshold:30, blockThreshold:70, apiEndpoint:API, notifyEnabled:true, whitelist:[], blacklist:[], statsTotal:0, statsBlocked:0, statsWarned:0, statsSafe:0, scanHistory:[], streak:0, streakBadge:'🛡️ Newcomer', totalAvoided:0 });
  loadLists();
});
chrome.runtime.onStartup.addListener(loadLists);

async function loadLists() {
  const d=await chrome.storage.local.get(['whitelist','blacklist']);
  whitelist=new Set(d.whitelist||[]);
  blacklist=new Set([...(d.blacklist||[])]);
}

chrome.webNavigation.onCommitted.addListener(async (det) => {
  if(det.frameId!==0)return;
  const url=det.url;
  if(!url||!url.startsWith('http'))return;
  const cfg=await chrome.storage.local.get(['enabled','mlEnabled','warnThreshold','blockThreshold','apiEndpoint','notifyEnabled']);
  if(!cfg.enabled)return;
  doScan(url,det.tabId,cfg);
},{ url:[{ schemes:['http','https'] }] });

async function doScan(url, tabId, cfg) {
  const hit=null; // Cache disabled — always rescan
  // Cache disabled for demo — always rescan fresh
  // if(hit){ applyResult(hit,tabId,cfg); return; }
  let host='';
  try{ host=new URL(url).hostname.toLowerCase(); }catch{}
  if(whitelist.has(host)){
    const r=mk('safe',0,'whitelist',[],url);
    setTS(tabId,r); badge(tabId,'safe');
    try{ chrome.tabs.sendMessage(tabId,{ type:'SHOW_WIDGET', data:r }); }catch(e){}
    await updateStreak(true); return;
  }
  if(blacklist.has(host)){
    const r=mk('blocked',100,'blacklist',['Known phishing domain — UNSW-NB15 threat database'],url);
    r.lesson=getMicroLesson(r.warnings);
    setCache(url,r); saveHist(r); applyResult(r,tabId,cfg);
    await postSIEM(r,cfg.apiEndpoint); await updateStreak(false); return;
  }
  const feats=extractFeatures(url);
  const h=heuristic(feats);
  // Read fresh thresholds
  const freshCfg=await chrome.storage.local.get(['blockThreshold','warnThreshold']);
  const curBlock=parseInt(freshCfg.blockThreshold||cfg.blockThreshold||BLOCK);
  const curWarn=parseInt(freshCfg.warnThreshold||cfg.warnThreshold||WARN);
  const ts=h.score>=curBlock?'blocked':h.score>=curWarn?'warned':'safe';
  setTS(tabId,mk(ts,h.score,'heuristic',h.warnings,url)); badge(tabId,ts);

  // ── Try URL Database first ─────────────────────────────────────
  try {
    const dbRes = await fetch((cfg.apiEndpoint||API)+'/api/v1/url-check', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ url: url, full_url: url }),
      signal: AbortSignal.timeout(3000)
    });
    if (dbRes.ok) {
      const dbData = await dbRes.json();
      const dbStatus = dbData.verdict || dbData.status || ts;
      const dbScore  = dbData.score  || h.score;
      const dbWarns  = dbData.warnings || h.warnings;
      const final2   = mk(dbStatus, dbScore, 'ML_ENSEMBLE', dbWarns, url);
      if (dbStatus === 'blocked' || dbStatus === 'warned') final2.lesson = getMicroLesson(dbWarns);
      setCache(url, final2); saveHist(final2); applyResult(final2, tabId, cfg); updStats(final2.status);
      await forceUpdateBadge(final2, tabId);
      await postSIEM(final2, cfg.apiEndpoint);
      await updateStreak(final2.status === 'safe');
      return;
    }
  } catch(e) {
    // URL database not available — continue with ML/heuristic
  }

  let final=null;
  if(cfg.mlEnabled!==false){
    try{
      const res=await fetch((cfg.apiEndpoint||API)+'/api/v1/predict',{
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ url, features:feats }),
        signal:AbortSignal.timeout(4000)
      });
      if(res.ok){
        const d=await res.json();
        const mlProb=d.phishing_probability!=null?d.phishing_probability:d.ml_probability!=null?d.ml_probability:d.ml_score!=null?d.ml_score/100:null;
        // Always use FRESH thresholds
        const freshT=await chrome.storage.local.get(['blockThreshold','warnThreshold']);
        const fBk=parseInt(freshT.blockThreshold||BLOCK);
        const fWn=parseInt(freshT.warnThreshold||WARN);
        // Heuristic always wins — ML only used for display
        // Heuristic ALWAYS wins — ML never overrides
        let combined = h.score;
        let status;
        if(combined>=fBk){
          status = 'blocked';
        } else if(combined>=fWn){
          status = 'warned';
        } else {
          status = 'safe';
        }
        final=mk(status,combined,'heuristic',[...new Set([...h.warnings,...(d.warnings||[])])],url);
        final.ml_prob=mlProb; final.rf_prob=d.rf_probability||null; final.svm_prob=d.svm_probability||null; final.features=feats;
      }
    } catch {}
  }
  if(!final) final=mk(ts,h.score,'heuristic',h.warnings,url);
  if(final.status==='blocked'||final.status==='warned') final.lesson=getMicroLesson(final.warnings);
  setCache(url,final); saveHist(final); applyResult(final,tabId,cfg); updStats(final.status);
  // Force update floating badge with final ML result
  await forceUpdateBadge(final, tabId);
  await postSIEM(final,cfg.apiEndpoint);
  await updateStreak(final.status==='safe');
}

async function applyResult(r, tabId, cfg) {
  setTS(tabId,r); badge(tabId,r.status);
  // Always read fresh thresholds from storage
  const fresh = await chrome.storage.local.get(['blockThreshold','warnThreshold']);
  const bk = parseInt(fresh.blockThreshold || cfg.blockThreshold || BLOCK);
  const wn = parseInt(fresh.warnThreshold  || cfg.warnThreshold  || WARN);

  // Always try to inject content script first, then send message
  async function sendToTab(type, data) {
    // Try 1: direct message
    try {
      await chrome.tabs.sendMessage(tabId, { type, data });
      return;
    } catch(e) {}
    // Try 2: inject content script then message
    try {
      await chrome.scripting.executeScript({ target:{ tabId }, files:['content/content.js'] });
      await new Promise(res => setTimeout(res, 500));
      await chrome.tabs.sendMessage(tabId, { type, data });
      return;
    } catch(e) {}
    // Try 3: wait longer and retry
    await new Promise(res => setTimeout(res, 1000));
    try {
      await chrome.scripting.executeScript({ target:{ tabId }, files:['content/content.js'] });
      await new Promise(res => setTimeout(res, 500));
      await chrome.tabs.sendMessage(tabId, { type, data });
    } catch(e) {}
  }

  if(r.status==='blocked' && r.score>=bk){
    badge(tabId,'blocked');
    if(cfg.notifyEnabled) notify(r);
    await sendToTab('SHOW_WIDGET', r);
    await sendToTab('SHOW_BANNER', r);
    return;
  }
  if(r.status==='warned' && r.score>=wn){
    if(cfg.notifyEnabled) notify(r);
    await sendToTab('SHOW_WIDGET', r);
    await sendToTab('SHOW_BANNER', r);
    return;
  }
  // Safe — send widget
  await sendToTab('SHOW_WIDGET', r);
}

// Force update floating badge on all tabs after final result
async function forceUpdateBadge(r, tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'SHOW_WIDGET', data: r });
  } catch(e) {
    try {
      await chrome.scripting.executeScript({ target:{ tabId }, files:['content/content.js'] });
      await new Promise(res => setTimeout(res, 300));
      await chrome.tabs.sendMessage(tabId, { type: 'SHOW_WIDGET', data: r });
    } catch(e2) {}
  }
}

function badge(tabId, status) {
  const m={ blocked:{ t:'✕', c:'#ef4444' }, warned:{ t:'!', c:'#f59e0b' }, safe:{ t:'✓', c:'#10b981' } };
  const b=m[status]||{ t:'?', c:'#6366f1' };
  try{ chrome.action.setBadgeText({ tabId, text:b.t }); chrome.action.setBadgeBackgroundColor({ tabId, color:b.c }); }catch{}
}

function notify(r) {
  let h=''; try{ h=new URL(r.url).hostname; }catch{}
  chrome.notifications.create('psp'+Date.now(),{ type:'basic', iconUrl:'icons/icon48.png', title:r.status==='blocked'?'PhishingShield — Blocked!':'PhishingShield — Warning', message:h+' — Score: '+r.score+'/100', priority:2 });
}

async function saveHist(r) {
  try{
    const d=await chrome.storage.local.get('scanHistory');
    const h=d.scanHistory||[];
    h.push({ url:r.url, status:r.status, score:r.score, source:r.source, warnings:r.warnings, ml_prob:r.ml_prob, ts:r.ts });
    if(h.length>MAX_HIST) h.splice(0,h.length-MAX_HIST);
    await chrome.storage.local.set({ scanHistory:h });
  } catch {}
}

async function updStats(s) {
  const d=await chrome.storage.local.get(['statsTotal','statsBlocked','statsWarned','statsSafe']);
  await chrome.storage.local.set({ statsTotal:(d.statsTotal||0)+1, statsBlocked:(d.statsBlocked||0)+(s==='blocked'?1:0), statsWarned:(d.statsWarned||0)+(s==='warned'?1:0), statsSafe:(d.statsSafe||0)+(s==='safe'?1:0) });
}

function mk(status,score,source,warnings,url){ return { status,score,source,warnings:warnings||[],url,ts:Date.now() }; }
function setTS(id,r){ tabState.set(id,r); }
function getCache(url){ const e=cache.get(url); if(!e)return null; if(Date.now()-e.ts>CACHE_TTL){ cache.delete(url); return null; } return e.r; }
function setCache(url,r){ if(cache.size>=MAX_CACHE) cache.delete(cache.keys().next().value); cache.set(url,{ r,ts:Date.now() }); }

// ── Message handlers ───────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch(msg.type) {

    case 'GET_STATE':
      chrome.tabs.query({ active:true, currentWindow:true }, tabs => {
        sendResponse(tabs[0]?(tabState.get(tabs[0].id)||null):null);
      });
      return true;

    case 'GET_CURRENT_SCAN':
      // Use sender tab ID if available — more accurate than active tab
      if (sender && sender.tab && sender.tab.id) {
        sendResponse(tabState.get(sender.tab.id) || null);
      } else {
        chrome.tabs.query({ active:true, currentWindow:true }, tabs => {
          if(!tabs[0]){ sendResponse(null); return; }
          sendResponse(tabState.get(tabs[0].id)||null);
        });
        return true;
      }
      break;

    case 'RESCAN':
      chrome.tabs.query({ active:true, currentWindow:true }, async tabs => {
        if(!tabs[0]){ sendResponse({ ok:false }); return; }
        cache.delete(tabs[0].url);
        const cfg=await chrome.storage.local.get(['enabled','mlEnabled','warnThreshold','blockThreshold','apiEndpoint','notifyEnabled']);
        doScan(tabs[0].url,tabs[0].id,cfg);
        sendResponse({ ok:true });
      });
      return true;

    case 'ADD_WHITELIST':
      if(msg.domain){ whitelist.add(msg.domain); chrome.storage.local.get('whitelist',d=>{ const l=d.whitelist||[]; if(!l.includes(msg.domain))l.push(msg.domain); chrome.storage.local.set({ whitelist:l }); }); }
      sendResponse({ ok:true }); break;

    case 'REMOVE_WHITELIST':
      whitelist.delete(msg.domain);
      chrome.storage.local.get('whitelist',d=>{ const l=(d.whitelist||[]).filter(x=>x!==msg.domain); chrome.storage.local.set({ whitelist:l }); });
      sendResponse({ ok:true }); break;

    case 'CLEAR_CACHE':
      cache.clear(); sendResponse({ ok:true }); break;

    case 'OPEN':
      chrome.tabs.create({ url:chrome.runtime.getURL(msg.page) });
      sendResponse({ ok:true }); break;

    // ── ⛶ View Full Details — open popup ──────────────────────────────
    case 'OPEN_POPUP_DETAILS':
      chrome.windows.create({
        url: chrome.runtime.getURL('popup/popup.html#details'),
        type: 'popup',
        width: 390,
        height: 600,
        focused: true
      });
      sendResponse({ ok:true }); break;

    case 'OPEN_POPUP':
      chrome.action.openPopup().catch(() => {
        chrome.windows.create({
          url: chrome.runtime.getURL('popup/popup.html'),
          type: 'popup',
          width: 390,
          height: 620,
          focused: true
        });
      });
      sendResponse({ ok:true }); break;

    case 'OPEN_POPUP_TAB':
      chrome.tabs.create({ url:chrome.runtime.getURL('popup/popup.html') });
      sendResponse({ ok:true }); break;

    case 'SCAN_URL':
      (async () => {
        const f=extractFeatures(msg.url);
        const h=heuristic(f);
        sendResponse({ status:h.score>=BLOCK?'blocked':h.score>=WARN?'warned':'safe', score:h.score, warnings:h.warnings });
      })();
      return true;

    case 'GET_EXPLANATION':
      (async () => {
        try{
          const cfg=await chrome.storage.local.get('apiEndpoint');
          const res=await fetch((cfg.apiEndpoint||API)+'/api/v1/explain',{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(msg.payload), signal:AbortSignal.timeout(5000) });
          sendResponse({ ok:true, data:await res.json() });
        } catch(e){ sendResponse({ ok:false, error:e.message }); }
      })();
      return true;

    case 'GET_SANDBOX_PREVIEW':
      (async () => {
        try{
          const cfg=await chrome.storage.local.get('apiEndpoint');
          const res=await fetch((cfg.apiEndpoint||API)+'/api/v1/sandbox-preview',{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ url:msg.url, timeout_ms:10000 }), signal:AbortSignal.timeout(15000) });
          sendResponse({ ok:true, data:await res.json() });
        } catch(e){ sendResponse({ ok:false, error:e.message }); }
      })();
      return true;

    case 'GET_GAMIFICATION':
      chrome.storage.local.get(['streak','streakBadge','totalAvoided'],d=>{
        sendResponse({ streak:d.streak||0, badge:d.streakBadge||'🛡️ Newcomer', totalAvoided:d.totalAvoided||0 });
      });
      return true;
  }
});

chrome.tabs.onRemoved.addListener(id => tabState.delete(id));