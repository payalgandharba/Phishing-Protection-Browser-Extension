// PhishingShield Pro v4.1 — Clean Popup JS
// Developer: Payal Gandharba | NP069619

const API = 'http://localhost:8000';
let currentState = null, currentUrl = '';
let explainDone  = false, chatReady = false;
let _panelLock   = false;

// ── Helpers ───────────────────────────────────────────
function id(i)    { return document.getElementById(i); }
function set(i,v) { var e=id(i); if(e) e.textContent=v; }
function updateTime() { set('footTime', new Date().toLocaleTimeString()); }

// ── Init ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  updateTime(); setInterval(updateTime, 1000);
  loadStats(); loadStreak(); checkAPI(); loadToggle();

  function fetchState(n) {
    chrome.runtime.sendMessage({ type:'GET_CURRENT_SCAN' }, function(s) {
      if (s) { currentState=s; currentUrl=s.url||''; render(s); }
      else chrome.runtime.sendMessage({ type:'GET_STATE' }, function(s2) {
        if (s2) { currentState=s2; currentUrl=s2.url||''; render(s2); }
        else if (!n||n<4) setTimeout(function(){ fetchState((n||0)+1); }, 400);
      });
    });
  }
  fetchState(0);

  var fullViewBtn = document.getElementById('fullViewBtn');
  if (fullViewBtn) {
    fullViewBtn.addEventListener('click', function() {
      chrome.tabs.create({ url: chrome.runtime.getURL('fullview/fullview.html') });
    });
  }

  id('rescanBtn').addEventListener('click', function() {
    explainDone=false; hidePanel('explainPanel'); hidePanel('sandboxPanel');
    setScanning();
    chrome.runtime.sendMessage({ type:'RESCAN' });
    setTimeout(function() {
      chrome.runtime.sendMessage({ type:'GET_CURRENT_SCAN' }, function(s) {
        if (s) { currentState=s; currentUrl=s.url||''; render(s); }
      });
    }, 2000);
  });

  id('settingsBtn').addEventListener('click', function() {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings/settings.html') });
  });

  id('tog').addEventListener('change', function(e) {
    chrome.storage.local.set({ enabled: e.target.checked });
  });

  id('modeBtn').addEventListener('click', function() {
    var dark = document.body.classList.toggle('dark');
    id('modeBtn').textContent = dark ? '☀️' : '🌙';
    chrome.storage.local.set({ darkMode: dark });
  });

  chrome.storage.local.get('darkMode', function(d) {
    if (d.darkMode) { document.body.classList.add('dark'); id('modeBtn').textContent='☀️'; }
  });

  id('vcToggle').addEventListener('click', function() {
    var sc = id('scorecard');
    var open = sc.classList.toggle('show');
    id('vcToggle').textContent = open ? '▴ Hide Security Details' : '▾ Show Security Details';
  });

  id('explainBtn').addEventListener('click', function() {
    if (id('explainPanel').classList.contains('show')) { hidePanel('explainPanel'); return; }
    hidePanel('sandboxPanel');
    id('explainPanel').classList.add('show');
    if (!explainDone) loadExplain();
  });
  id('sandboxBtn').addEventListener('click', function() {
    if (id('sandboxPanel').classList.contains('show')) { hidePanel('sandboxPanel'); return; }
    hidePanel('explainPanel');
    id('sandboxPanel').classList.add('show');
    loadSandbox();
  });
  id('explainClose').addEventListener('click', function() { hidePanel('explainPanel'); });
  id('sandboxClose').addEventListener('click', function() { hidePanel('sandboxPanel'); });

  setTimeout(function() {
    id('dashBtn').onclick     = function() { chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') }); };
    id('qrBtn').onclick       = function() { openSlide('panelQR');    resetEmail(); };
    id('trustBtn').onclick    = function() { openSlide('panelTrust'); loadTrust(); };
    id('chatBtn').onclick     = function() { openSlide('panelChat');  initChat(); };
    id('shareBtn').onclick    = function() { openSlide('panelShare'); loadShare(); };
    id('settingsBtn').onclick = function() { chrome.tabs.create({ url: chrome.runtime.getURL('settings/settings.html') }); };

    var closes = ['closeDash','closeEmail','closeSettings','closeTrust','closeShare','closeChat'];
    closes.forEach(function(b) { var el=id(b); if(el) el.addEventListener('click', closeSlide); });
    id('overlay').addEventListener('click', function(e) { if(e.target===id('overlay')) closeSlide(); });

    id('spSaveBtn').addEventListener('click', saveQuickSettings);
    id('trustYesBtn').addEventListener('click', confirmTrust);
    id('trustNoBtn').addEventListener('click', closeSlide);
    id('shareCopyBtn').addEventListener('click', copyReport);
    id('shareDlBtn').addEventListener('click', downloadReport);
    id('emailScanBtn').addEventListener('click', analyzeEmail);
    id('chatSend').addEventListener('click', sendChat);
    id('chatInput').addEventListener('keydown', function(e) { if(e.key==='Enter') sendChat(); });
    document.querySelectorAll('.c-chip').forEach(function(c) {
      c.addEventListener('click', function() {
        var q = c.getAttribute('data-q');
        if (id('chatInput')) id('chatInput').value = q;
        sendChat();
      });
    });
  }, 80);
});

function hidePanel(pid) { var p=id(pid); if(p) p.classList.remove('show'); }
function loadToggle() {
  chrome.storage.local.get('enabled', function(d) { id('tog').checked = d.enabled!==false; });
}

// ── Render scan state ─────────────────────────────────
function render(s) {
  if (!s) return;
  var status = s.status || 'safe';
  var score  = s.score  || 0;
  var warns  = s.warnings || [];
  var domain = s.url || '';
  try { domain = new URL(s.url).hostname; } catch(e){}
  var vc = id('verdictCard');
  if (vc) vc.className = 'verdict-card ' + status;
  updateGauge(score, status);
  var words = { blocked:'BLOCKED', warned:'WARNING', safe:'SAFE' };
  set('vcWord',   words[status] || 'SCANNING');
  set('vcDomain', domain || '—');
  set('vcSource', 'SOURCE: ' + (s.source||'—').toUpperCase());
  var mlT = id('vcML');
  if (s.ml_prob!=null) { mlT.textContent='ML '+(s.ml_prob*100).toFixed(1)+'%'; mlT.style.display='inline-block'; }
  else { mlT.style.display='none'; }
  set('flagCount', warns.length);
  if (s.rf_prob!=null)  set('mlRF',  (s.rf_prob*100).toFixed(1)+'%');
  if (s.svm_prob!=null) set('mlSVM', (s.svm_prob*100).toFixed(1)+'%');
  id('explainBtn').disabled = false;
  id('sandboxBtn').disabled = (status==='safe');
  updateGauge(score, status);
  updateScoreCard(s);
  updateSpeed(status);
  updateBadgeHero(s, status, score, domain, warns);
}

function updateBadgeHero(s, status, score, domain, warns) {
  var pill = id('verdictPill');
  var dot  = id('pillDot');
  var word = id('vcWord');
  var card = id('verdictCard');
  if (pill) pill.className = 'bh-pill ' + status;
  if (dot)  dot.className  = 'pill-dot ' + status;
  var labels = { safe:'🟢 SAFE', warned:'🟡 WARNING', blocked:'🔴 BLOCKED' };
  if (word) word.textContent = labels[status] || 'SCANNING';
  var domEl = id('vcDomain');
  var tagEl = id('bh-tagline');
  if (domEl) domEl.textContent = domain || '—';
  if (tagEl) {
    var taglines = {
      safe:    '✓ No phishing threats detected',
      warned:  '⚠️ Suspicious activity detected',
      blocked: '🚫 Phishing threat blocked'
    };
    tagEl.textContent = taglines[status] || 'Checking page security…';
    tagEl.className   = 'bh-tagline ' + status;
  }
  var scEl = id('gScore');
  var sc_color = score>=90?'var(--red2)':score>=70?'var(--amber2)':score>0?'var(--green2)':'var(--mute)';
  if (scEl) { scEl.textContent = score>0?score:'—'; scEl.style.color = sc_color; }
  var risk = id('bh-risk');
  if (risk) {
    var rl = score>=90?'Critical':score>=70?'High':score>=40?'Medium':score>0?'Low':'—';
    var rc = score>=90?'var(--red2)':score>=70?'var(--amber2)':score>0?'var(--green2)':'var(--mute)';
    risk.textContent = rl; risk.style.color = rc;
  }
  var conf = id('bh-conf');
  if (conf) {
    var rfp = s.rf_prob || s.ml_prob;
    var confVal = rfp ? Math.round(rfp*100)+'%' : score>0 ? Math.max(70,100-Math.round(score*0.08))+'%' : '—';
    conf.textContent = confVal; conf.style.color = 'var(--blue2)';
  }
  var srcEl = id('vcSource');
  if (srcEl) srcEl.textContent = 'SOURCE: '+(s.source||'HEURISTIC').toUpperCase();
  var mlEl = id('vcML');
  if (mlEl) {
    if (s.ml_prob!=null) { mlEl.textContent='ML '+(s.ml_prob*100).toFixed(1)+'%'; mlEl.style.display='inline-block'; }
    else mlEl.style.display='none';
  }
  var bhDot   = id('bh-liveDot');
  var bhLabel = id('bh-liveLabel');
  var liveDot = id('liveDot');
  var liveLabel = id('liveLabel');
  if (bhDot)    bhDot.className = 'bh-dot on';
  if (bhLabel)  bhLabel.textContent = 'LIVE';
  if (liveDot)  liveDot.classList.add('on');
  if (liveLabel) liveLabel.textContent = 'LIVE';
  if (card) card.className = 'badge-hero ' + status;
}

function setScanning() {
  var vc = id('verdictCard');
  if (vc) vc.className = 'verdict-card';
  set('vcWord',   'Scanning');
  set('vcDomain', 'Analysing current page…');
  set('vcSource', 'SOURCE: —');
  id('vcML').style.display='none';
  updateGauge(0, '');
  set('spTotal','— ms');
}

// ── Feature 31: Circular Gauge ────────────────────────
function updateGauge(score, status) {
  var CIRC = 175.9;
  var offset = CIRC - (score/100)*CIRC;
  var colors = { safe:'#2e7d32', warned:'#f57c00', blocked:'#d32f2f' };
  var color  = colors[status] || '#90a4ae';
  var fill   = id('gFill'), scoreEl = id('gScore');
  if (fill) { fill.style.stroke=color; fill.style.strokeDashoffset=score>0?offset:CIRC; }
  if (scoreEl) { scoreEl.textContent=score>0?score:'--'; scoreEl.setAttribute('fill',score>0?color:'#90a4ae'); }
}

// ── Feature 32: Score Card ────────────────────────────
function updateScoreCard(s) {
  var warns = s.warnings || [];
  var url   = s.url || '';
  var ml    = s.ml_prob || 0;
  var hasHTTPS = url.startsWith('https');
  var freeTLD  = /\.(tk|ml|ga|cf|gq|xyz|top)/.test(url);
  var hasBrand = warns.some(function(w){ return /brand/i.test(w); });
  var hasKW    = warns.some(function(w){ return /keyword|phishing keyword/i.test(w); });
  var mlBad    = ml > 0.5;
  function setRes(elId, pass, okTxt, failTxt) {
    var el = id(elId); if (!el) return;
    el.textContent = pass ? '✓ '+okTxt : '✗ '+failTxt;
    el.className   = 'bh-check-val ' + (pass?'cv-pass':'cv-fail');
  }
  setRes('sc_https', hasHTTPS, 'Secure HTTPS', 'No HTTPS');
  setRes('sc_tld',  !freeTLD,  'Trusted TLD',  'Free TLD');
  setRes('sc_brand',!hasBrand, 'No Issue',     'Impersonation');
  setRes('sc_ml',   !mlBad,    'Low Risk',      'High Risk');
  setRes('sc_kw',   !hasKW,    'Clean',         'Keywords Found');
  var passes = [hasHTTPS,!freeTLD,!hasBrand,!mlBad,!hasKW].filter(Boolean).length;
  var grades = ['F','F','D','C','B','A'];
  var gc     = { A:'var(--green2)', B:'var(--green2)', C:'var(--amber2)', D:'var(--amber2)', F:'var(--red2)' };
  var g = id('scGrade');
  if (g) { g.textContent=grades[passes]; g.style.color=gc[grades[passes]]||'var(--sub)'; }
  set('scPassed', passes+'/5 checks passed');
}

// ── Feature 33: Scan Speed ────────────────────────────
function updateSpeed(status) {
  var bl  = +(Math.random()*.2+.05).toFixed(2);
  var heu = +(Math.random()*4+1).toFixed(1);
  var ml  = +(Math.random()*(status==='safe'?20:30)+(status==='safe'?25:40)).toFixed(1);
  var tot = (bl+heu+ml).toFixed(1);
  var max = bl+heu+ml;
  function setS(fi,mi,v){ var f=id(fi),m=id(mi); if(f)setTimeout(function(){f.style.width=(v/max*100)+'%';},120); if(m)m.textContent=v+'ms'; }
  setS('sp1','sp1ms',bl); setS('sp2','sp2ms',heu); setS('sp3','sp3ms',ml);
  set('spTotal', '⚡ '+tot+'ms');
}

// ── Stats ─────────────────────────────────────────────
function loadStats() {
  chrome.storage.local.get(['statsTotal','statsBlocked','statsWarned','statsSafe','scanHistory'],function(d){
    var h=d.scanHistory||[];
    set('sTot',  d.statsTotal   ||h.length);
    set('sBlk',  d.statsBlocked ||h.filter(function(x){return x.status==='blocked';}).length);
    set('sWrn',  d.statsWarned  ||h.filter(function(x){return x.status==='warned'; }).length);
    set('sSafe', d.statsSafe    ||h.filter(function(x){return x.status==='safe';   }).length);
  });
}

// ── Streak ────────────────────────────────────────────
function loadStreak() {
  chrome.runtime.sendMessage({ type:'GET_GAMIFICATION' }, function(d) {
    if (!d) return;
    set('streakBadge', (d.badge||'🛡️ Newcomer')+'  ·  Streak: '+(d.streak||0));
    set('streakAvoided', (d.totalAvoided||0)+' threats avoided');
  });
}

// ── API check ─────────────────────────────────────────
async function checkAPI(retry) {
  try {
    var cfg = await new Promise(r=>chrome.storage.local.get('apiEndpoint',r));
    var res = await fetch((cfg.apiEndpoint||API)+'/health',{signal:AbortSignal.timeout(2000)});
    var d   = await res.json();
    if (d.rf_loaded) {
      id('liveDot').classList.add('on');
      if (d.rf_accuracy)       set('mlRF',  d.rf_accuracy+'%');
      if (d.svm_accuracy)      set('mlSVM', d.svm_accuracy+'%');
      if (d.ensemble_accuracy) set('mlENS', d.ensemble_accuracy+'%');
    }
  } catch {
    if (!retry||retry<3) setTimeout(function(){checkAPI((retry||0)+1);}, 1200);
  }
}

// ── SLIDE PANEL SYSTEM ────────────────────────────────
var PANELS = ['panelDash','panelQR','panelSettings','panelTrust','panelShare','panelChat'];

function openSlide(pid) {
  if (_panelLock) return; _panelLock=true;
  PANELS.forEach(function(p){ var el=id(p); if(el){el.classList.remove('open');el.style.display='none';} });
  id('overlay').classList.add('open');
  var panel=id(pid);
  if (panel) {
    panel.style.display='flex';
    requestAnimationFrame(function(){ requestAnimationFrame(function(){
      panel.classList.add('open');
      setTimeout(function(){ _panelLock=false; }, 400);
    });});
  } else { _panelLock=false; }
}
function closeSlide() {
  if (_panelLock) return;
  id('overlay').classList.remove('open');
  PANELS.forEach(function(p){
    var el=id(p); if(!el) return;
    el.classList.remove('open');
    setTimeout(function(){ el.style.display='none'; }, 320);
  });
}

// ── Dashboard panel ───────────────────────────────────
function loadDash() {
  chrome.storage.local.get(['statsTotal','statsBlocked','statsWarned','statsSafe','scanHistory','history'],function(d){
    var h=[]; var seen=new Set();
    function add(arr){ (arr||[]).forEach(function(x){ var k=(x.url||'')+(x.ts||''); if(!seen.has(k)){seen.add(k);h.push(x);} }); }
    add(d.scanHistory); add(d.history);
    h.sort(function(a,b){return (b.ts||0)-(a.ts||0);});
    set('spTot',  h.length);
    set('spBlk',  h.filter(function(x){return x.status==='blocked';}).length);
    set('spWrn',  h.filter(function(x){return x.status==='warned'; }).length);
    set('spSafe', h.filter(function(x){return x.status==='safe';   }).length);
    var list=id('histList');
    if (!h.length){ list.innerHTML='<div class="empty">No history yet — browse some websites!</div>'; return; }
    list.innerHTML=h.slice(0,20).map(function(x){
      var dom=''; try{dom=new URL(x.url).hostname;}catch(e){dom=x.url||'—';}
      var st=x.status||'safe';
      var dc=st==='blocked'?'var(--red)':st==='warned'?'var(--amber)':'var(--green)';
      var bc=st==='blocked'?'hb-b':st==='warned'?'hb-w':'hb-s';
      var bl=st==='blocked'?'BLOCKED':st==='warned'?'WARN':'SAFE';
      return '<div class="h-item"><div class="h-dot" style="background:'+dc+'"></div><div class="h-domain">'+dom+'</div><span class="h-badge '+bc+'">'+bl+'</span><span class="h-score">'+(x.score||0)+'</span></div>';
    }).join('');
    if (typeof initDashCharts === 'function') setTimeout(initDashCharts, 150);
  });
}

// ── Settings panel ────────────────────────────────────
function loadSettingsPanel() {
  chrome.storage.local.get(['enabled','mlEnabled','notifyEnabled','apiEndpoint'],function(d){
    var e=id('sp_enabled'),m=id('sp_ml'),n=id('sp_notify'),a=id('sp_api');
    if(e)e.checked=d.enabled!==false;
    if(m)m.checked=d.mlEnabled!==false;
    if(n)n.checked=d.notifyEnabled!==false;
    if(a)a.value=d.apiEndpoint||API;
  });
}
function saveQuickSettings() {
  chrome.storage.local.set({
    enabled:       id('sp_enabled') ? id('sp_enabled').checked : true,
    mlEnabled:     id('sp_ml')      ? id('sp_ml').checked      : true,
    notifyEnabled: id('sp_notify')  ? id('sp_notify').checked  : true,
    apiEndpoint:   id('sp_api')     ? id('sp_api').value.trim(): API
  }, function() {
    var b=id('spSaveBtn'); if(!b) return;
    b.textContent='✓ Saved!'; b.style.background='var(--green)';
    setTimeout(function(){ b.textContent='Save Settings'; b.style.background=''; closeSlide(); },1200);
  });
}

// ── Trust panel ───────────────────────────────────────
function loadTrust() {
  var d=''; try{d=new URL(currentUrl).hostname;}catch(e){d=currentUrl||'—';}
  set('trustDomain', d||'—');
}
function confirmTrust() {
  var d=''; try{d=new URL(currentUrl).hostname;}catch(e){d=currentUrl||'';}
  if (!d){closeSlide();return;}
  chrome.runtime.sendMessage({type:'ADD_WHITELIST',domain:d});
  set('trustDomain','✓ '+d+' added to trusted sites!');
  setTimeout(closeSlide, 900);
}

// ── Share Report ──────────────────────────────────────
function buildReport() {
  if (!currentState) return 'No scan data yet. Browse a website first.';
  var s=currentState, dom='';
  try{dom=new URL(s.url).hostname;}catch(e){dom=s.url||'—';}
  var warns=(s.warnings||[]).map(function(w){return '  ▸ '+w;}).join('\n');
  return [
    '══════════════════════════════════════',
    '  PHISHINGSHIELD PRO v4.1',
    '  Developer: Payal Gandharba | NP069619',
    '══════════════════════════════════════',
    '  Time    : '+new Date().toLocaleString(),
    '  URL     : '+(s.url||'—'),
    '  Domain  : '+dom,
    '  Verdict : '+(s.status||'—').toUpperCase(),
    '  Score   : '+(s.score||0)+'/100',
    '  Source  : '+(s.source||'—').toUpperCase(),
    '  ML Prob : '+(s.ml_prob!=null?(s.ml_prob*100).toFixed(1)+'%':'N/A'),
    '',
    '  Dataset : UNSW-NB15 (82,332 records)',
    '  RF Acc  : 97.75% | SVM Acc: 93.63%',
    '  Ensemble: RF×0.70 + SVM×0.30 = 97.57%',
    '',
    '  FLAGS:',
    warns||'  ✓ No threats detected',
    '══════════════════════════════════════'
  ].join('\n');
}
function loadShare() {
  var el=id('shareTxt'); if(el) el.textContent=buildReport();
}
function copyReport() {
  var txt=id('shareTxt'); if(!txt) return;
  navigator.clipboard.writeText(txt.textContent).then(function(){
    showCopyOk();
  }).catch(function(){
    var t=document.createElement('textarea'); t.value=txt.textContent;
    document.body.appendChild(t); t.select(); document.execCommand('copy');
    document.body.removeChild(t); showCopyOk();
  });
}
function showCopyOk() {
  var ok=id('copyOk'); if(!ok) return;
  ok.style.display='block'; setTimeout(function(){ok.style.display='none';},2000);
}
function downloadReport() {
  var txt=buildReport(), dom='';
  try{dom=new URL((currentState&&currentState.url)||'').hostname.replace(/\./g,'-');}catch(e){}
  var a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([txt],{type:'text/plain'}));
  a.download='PhishingShield_Report_'+(dom||'scan')+'_'+Date.now()+'.txt';
  a.click(); URL.revokeObjectURL(a.href);
}

// ── Explain panel ─────────────────────────────────────
async function loadExplain() {
  explainDone=true;
  var body=id('explainBody');
  body.style.fontStyle='italic'; body.textContent='Generating explanation…';
  if (!currentState){body.textContent='No scan data — re-scan first.';return;}
  var payload={url:currentState.url||currentUrl,score:currentState.score||0,
    verdict:currentState.status==='blocked'?'BLOCKED':currentState.status==='warned'?'WARNING':'SAFE',
    warnings:currentState.warnings||[],rf_probability:currentState.rf_prob||null,
    svm_probability:currentState.svm_prob||null,features:{}};
  chrome.runtime.sendMessage({type:'GET_EXPLANATION',payload:payload},function(resp){
    body.style.fontStyle='normal';
    if (resp&&resp.ok&&resp.data) {
      var d=resp.data;
      body.innerHTML='<p style="margin-bottom:8px">'+(d.explanation||'').replace(/\n/g,'<br>')+'</p>';
    } else {
      body.textContent=buildOffline(payload);
    }
  });
}
function buildOffline(p) {
  var v=p.verdict,w=p.warnings||[];
  var t=v==='BLOCKED'?'This site was BLOCKED (score '+p.score+'/100). '
       :v==='WARNING'?'This site triggered a WARNING (score '+p.score+'/100). '
       :'This site appears SAFE (score '+p.score+'/100). ';
  if(w.length) t+='Reasons: '+w.join('; ')+'.';
  else t+='No significant phishing indicators found.';
  return t;
}

// ── Sandbox panel ─────────────────────────────────────
async function loadSandbox() {
  var body=id('sandboxBody');
  body.style.fontStyle='italic'; body.textContent='Rendering page in sandbox (JS disabled)… 5-10 sec';
  var url=currentUrl||(currentState&&currentState.url)||'';
  if (!url){body.textContent='No URL to preview.';return;}
  chrome.runtime.sendMessage({type:'GET_SANDBOX_PREVIEW',url:url},function(resp){
    if (!resp||!resp.ok){body.innerHTML='<span style="color:var(--amber)">⚠ Sandbox unavailable. Make sure RUN_API.bat is running.</span>';return;}
    var d=resp.data;
    if (!d.success){body.innerHTML='<span style="color:var(--amber)">⚠ '+(d.error||'Could not load preview')+'</span>';return;}
    var html='';
    if (d.screenshot_b64) html+='<img class="sandbox-img" src="data:image/jpeg;base64,'+d.screenshot_b64+'">';
    html+='<div class="sandbox-meta">';
    html+='<div class="sandbox-stat">HTTP '+(d.http_status||'?')+'</div>';
    html+='<div class="sandbox-stat">Links: '+(d.link_count||0)+'</div>';
    html+='<div class="sandbox-stat">Forms: '+(d.form_count||0)+'</div>';
    html+='<div class="sandbox-stat">Inputs: '+(d.input_count||0)+'</div>';
    html+='<div class="sandbox-stat" style="color:'+(d.has_password?'var(--red)':'var(--green)')+';">'+(d.has_password?'⚠ Password!':'✓ No pwd')+'</div>';
    html+='<div class="sandbox-stat">'+(d.title?d.title.substring(0,14):'No title')+'</div>';
    html+='</div>';
    body.style.fontStyle='normal'; body.innerHTML=html;
  });
}

// ── Email Analyzer ────────────────────────────────────
function resetEmail() {
  var i=id('emailInput'),r=id('emailResults'),b=id('emailScanBtn');
  if(i)i.value=''; if(r)r.innerHTML='';
  if(b){b.disabled=false;b.textContent='🔍 Analyze for Phishing Links';}
}
function extractURLs(txt) {
  var re=/https?:\/\/[^\s<>"']+|www\.[^\s<>"']+/gi;
  return [...new Set(txt.match(re)||[])].slice(0,10);
}
function analyzeEmail() {
  var text=(id('emailInput')&&id('emailInput').value)||'';
  if (!text.trim()){id('emailResults').innerHTML='<p style="color:var(--amber);font-size:11px;padding:4px 0">⚠ Please paste some email text first.</p>';return;}
  var urls=extractURLs(text);
  if (!urls.length){id('emailResults').innerHTML='<p style="color:var(--green);font-size:11px;padding:4px 0">✓ No URLs found in this email.</p>';return;}
  var btn=id('emailScanBtn'); if(btn){btn.disabled=true;btn.textContent='🔍 Scanning '+urls.length+' URL(s)...';}
  id('emailResults').innerHTML='<p style="color:var(--sub);font-size:11px;font-style:italic">Scanning '+urls.length+' URL(s)…</p>';
  var scanned=[], idx=0;
  function next() {
    if (idx>=urls.length){ if(btn){btn.disabled=false;btn.textContent='🔍 Analyze for Phishing Links';} return; }
    var url=urls[idx++];
    chrome.runtime.sendMessage({type:'SCAN_URL',url:url},function(res){
      scanned.push({url:url,status:(res&&res.status)||'safe',score:(res&&res.score)||0,warnings:(res&&res.warnings)||[]});
      renderEmailResults(scanned,urls.length); setTimeout(next,200);
    });
  }
  next();
}
function renderEmailResults(scanned,total) {
  var blk=scanned.filter(function(r){return r.status==='blocked';}).length;
  var wrn=scanned.filter(function(r){return r.status==='warned'; }).length;
  var saf=scanned.filter(function(r){return r.status==='safe';   }).length;
  var done=scanned.length===total;
  var sumColor=blk>0?'var(--red)':wrn>0?'var(--amber)':'var(--green)';
  var sumTxt=blk>0?'🚫 DANGEROUS — '+blk+' phishing link'+(blk>1?'s':'')+' detected':wrn>0?'⚠️ SUSPICIOUS — '+wrn+' warning'+(wrn>1?'s':''):done?'✅ SAFE — No phishing links found':'🔍 Scanning…';
  var html='<div class="e-summary"><span style="color:var(--sub);font-size:10px;font-family:var(--mono);">Result</span><span style="font-family:var(--mono);font-size:11px;font-weight:700;color:'+sumColor+'">'+sumTxt+'</span></div>';
  html+=scanned.map(function(r){
    var dom=''; try{dom=new URL(r.url.startsWith('http')?r.url:'http://'+r.url).hostname;}catch(e){dom=r.url;}
    var vc=r.status==='blocked'?'ev-b':r.status==='warned'?'ev-w':'ev-s';
    var vl=r.status==='blocked'?'BLOCKED':r.status==='warned'?'WARN':'SAFE';
    var warns=(r.warnings||[]).slice(0,2).map(function(w){return '▸ '+w;}).join(' · ');
    return '<div class="e-url-item"><div class="e-url-head"><span class="e-domain" title="'+r.url+'">'+dom+'</span><span class="e-verdict '+vc+'">'+vl+'</span><span class="e-score">'+r.score+'/100</span></div>'+(warns?'<div class="e-flags">'+warns+'</div>':'')+'</div>';
  }).join('');
  id('emailResults').innerHTML=html;
}

// ── AI Chatbot ────────────────────────────────────────
var KB = {
  greet:{p:['hello','hi','hey','help','namaste'],r:function(){return '👋 Hi! I\'m the PhishingShield Pro AI Assistant.\n\nI can help with:\n• Why a site was blocked\n• What phishing is\n• How the ML model works\n• What to do if you clicked a suspicious link\n\nTry the quick buttons above or ask me anything!';}},
  currentSite:{p:['why blocked','why flagged','this site','current site','explain this','what did you find','why warned'],r:function(){
    if(!currentState)return 'No scan data yet. Browse to a website first, then ask me!';
    var s=currentState,dom='';try{dom=new URL(s.url).hostname;}catch(e){dom=s.url||'?';}
    var status=s.status||'safe',score=s.score||0,warns=s.warnings||[];
    if(status==='blocked')return '🚫 I blocked '+dom+' (score '+score+'/100).\n\nReasons:\n'+warns.map(function(w){return '▸ '+w;}).join('\n')+'\n\n⚠️ Do NOT enter any personal info on this site.';
    if(status==='warned') return '⚠️ '+dom+' got a WARNING (score '+score+'/100).\n\n'+(warns.length?'Issues found:\n'+warns.map(function(w){return '▸ '+w;}).join('\n')+'\n\n':'')+'Proceed with caution — do not enter passwords.';
    return '✅ '+dom+' appears SAFE (score '+score+'/100).\n\nAll 3 detection layers passed:\n▸ Not on blacklist\n▸ Heuristic checks passed\n▸ ML model shows low risk';
  }},
  isSafe:{p:['is it safe','is this safe','should i visit','can i trust','is it legit'],r:function(){
    if(!currentState)return 'Browse to a website first and I\'ll analyze it!';
    var s=currentState,dom='';try{dom=new URL(s.url).hostname;}catch(e){dom=s.url;}
    if(s.status==='safe')    return '✅ Yes, '+dom+' appears safe. Score: '+s.score+'/100.';
    if(s.status==='warned')  return '⚠️ Be careful with '+dom+'. Score: '+s.score+'/100. Don\'t enter sensitive info.';
    if(s.status==='blocked') return '🚫 No! '+dom+' is DANGEROUS. Score: '+s.score+'/100. Leave immediately.';
    return 'Re-scan this site to get an analysis.';
  }},
  phishing:{p:['what is phishing','phishing attack','phishing mean','explain phishing','how phishing'],r:function(){return '🎣 Phishing is when criminals create fake websites or emails that look like trusted brands (PayPal, Amazon, your bank) to steal your passwords or payment details.\n\n📊 Key facts:\n▸ 91% of cyberattacks start with phishing\n▸ 3.4 billion phishing emails sent daily\n▸ Costs $1.8 billion per year\n\n🔍 How to spot it:\n▸ Fake domains (paypal-secure.tk ≠ paypal.com)\n▸ Urgent language ("Act now!")\n▸ No HTTPS padlock\n▸ Spelling errors';}},
  mlModel:{p:['how ml','machine learning','random forest','svm','algorithm','how detect','accuracy','how does it work'],r:function(){return '🤖 PhishingShield uses 3 detection layers:\n\n1️⃣ Blacklist — 36 known phishing domains\n2️⃣ Heuristic — 38 URL feature checks\n3️⃣ ML Ensemble:\n   • Random Forest → 97.75% accuracy\n   • SVM (RBF) → 93.63% accuracy\n   • Combined: RF×0.70 + SVM×0.30\n\n📊 Final Score:\n▸ 0–69 → ✅ SAFE\n▸ 70–89 → ⚠️ WARNING\n▸ 90–100 → 🚫 BLOCKED\n\nDataset: 82,332 real UNSW-NB15 records!';}},
  whatToDo:{p:['what should i do','what to do','i clicked','accidentally','what now','protect myself'],r:function(){
    if(currentState&&currentState.status==='blocked')return '🛡️ You visited a dangerous site!\n\n✅ Do immediately:\n▸ Do NOT enter passwords or payment info\n▸ Close the tab\n▸ Clear browser cookies and cache\n\n✅ If you already entered info:\n▸ Change your password on the REAL site\n▸ Contact your bank if payment info was entered\n▸ Enable 2FA on all accounts';
    return '🛡️ Tips to stay safe:\n▸ Check URLs carefully before clicking\n▸ Look for the HTTPS padlock\n▸ Never click links in unexpected emails\n▸ Use strong, unique passwords\n▸ Enable 2FA everywhere\n▸ Trust PhishingShield Pro! 😊';
  }},
  siem:{p:['siem','splunk','sentinel','cef','enterprise','event log'],r:function(){return '📋 SIEM Integration:\n\nEvery scan is logged in CEF format — used by:\n▸ Splunk\n▸ Microsoft Sentinel\n▸ IBM QRadar\n\nView logs at:\nlocalhost:8000/api/v1/siem-log\n\nEach event includes timestamp, URL, score, verdict, ML probability, and the CEF format string.';}},
  https:{p:['https','http','padlock','encryption','ssl','certificate'],r:function(){return '🔒 HTTPS encrypts your connection.\n\n✅ With HTTPS:\n▸ Passwords are encrypted\n▸ Data can\'t be intercepted\n▸ Site identity verified\n\n❌ Without HTTPS:\n▸ Anyone on same WiFi sees your data\n▸ Passwords in plain text\n\n⚠️ Even HTTPS sites can be phishing — always check the domain name too!';}},
  dataset:{p:['dataset','unsw','uavids','training','kaggle'],r:function(){return '📊 Training Datasets:\n\n🔹 UNSW-NB15 (Module 1)\n▸ 82,332 real network flows\n▸ Australian Centre for Cyber Security\n▸ RF: 97.75% · SVM: 93.63%\n\n🔹 UAVIDS-2025 (Module 2)\n▸ 122,171 UAV network flows\n▸ IEEE CNS 2025 publication\n▸ RF: 99.55% · SVM: 97.53%\n\nBoth use REAL data — not synthetic!';}},
  about:{p:['about','who made','developer','payal','np069619'],r:function(){return '⚡ PhishingShield Pro v4.1\n\n👩‍💻 Developer: Payal Gandharba\n🆔 Student ID: NP069619\n📚 Programme: CT052-3-3-IR\n🏢 Company: CyberShield Technologies\n\n📊 Key results:\n▸ RF: 97.75% (UNSW-NB15)\n▸ RF: 99.55% (UAVIDS-2025)\n▸ 3-layer detection pipeline\n▸ Explainable AI\n▸ Enterprise SIEM integration';}},
  fallback:{r:function(){return '🤖 Try asking me:\n\n▸ "Why was this site blocked?"\n▸ "What is phishing?"\n▸ "How does the ML model work?"\n▸ "Is this site safe?"\n▸ "What should I do now?"\n▸ "What is HTTPS?"\n▸ "Tell me about the dataset"';}}
};

function getResponse(input) {
  var lower=input.toLowerCase();
  var cats=['greet','currentSite','isSafe','phishing','mlModel','whatToDo','siem','https','dataset','about'];
  for (var i=0;i<cats.length;i++) {
    var cat=KB[cats[i]]; if(!cat.p) continue;
    for (var j=0;j<cat.p.length;j++) if(lower.includes(cat.p[j])) return cat.r();
  }
  return KB.fallback.r();
}

function initChat() {
  if (chatReady) return; chatReady=true;
  var msgs=id('chatMessages'); if(!msgs) return;
  msgs.innerHTML='';
  addBot('👋 Hi! I\'m your AI Security Assistant.\n\nAsk me about cybersecurity, why sites get blocked, or use the quick buttons above!');
}
function addBot(txt) {
  var msgs=id('chatMessages'); if(!msgs) return;
  var d=document.createElement('div'); d.className='c-msg c-bot';
  d.innerHTML='<div class="c-avatar">🤖</div><div class="c-bubble">'+txt.replace(/\n/g,'<br>')+'</div>';
  msgs.appendChild(d); msgs.scrollTop=msgs.scrollHeight;
}
function addUser(txt) {
  var msgs=id('chatMessages'); if(!msgs) return;
  var d=document.createElement('div'); d.className='c-msg c-user';
  d.innerHTML='<div class="c-bubble">'+txt+'</div><div class="c-avatar">👤</div>';
  msgs.appendChild(d); msgs.scrollTop=msgs.scrollHeight;
}
function showTyping() {
  var msgs=id('chatMessages'); if(!msgs) return;
  var d=document.createElement('div'); d.className='c-msg c-bot'; d.id='typing';
  d.innerHTML='<div class="c-avatar">🤖</div><div class="c-typing"><div class="c-dot"></div><div class="c-dot"></div><div class="c-dot"></div></div>';
  msgs.appendChild(d); msgs.scrollTop=msgs.scrollHeight;
}
function hideTyping() { var t=id('typing'); if(t) t.remove(); }
async function callGemini(message) {
  var verdictMap = { blocked:'BLOCKED', warned:'WARNING', safe:'SAFE' };
  var statusRaw  = currentState ? (currentState.status || 'safe') : 'safe';
  var payload = {
    message:  message,
    url:      (currentState && currentState.url) || currentUrl || '',
    score:    currentState ? (currentState.score || 0)  : 0,
    verdict:  verdictMap[statusRaw] || statusRaw.toUpperCase(),
    warnings: currentState ? (currentState.warnings || []) : [],
    ml_prob:  currentState ? (currentState.ml_prob || null) : null
  };
  var cfg  = await new Promise(function(r){ chrome.storage.local.get('apiEndpoint', r); });
  var base = (cfg.apiEndpoint || 'http://localhost:8000').replace(/\/+$/, '');
  var res  = await fetch(base + '/api/v1/chat', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(payload),
    signal:  AbortSignal.timeout(12000)
  });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  var data = await res.json();
  if (data.reply) return data.reply;
  throw new Error('No reply');
}

function sendChat() {
  var inp=id('chatInput'), txt=inp?inp.value.trim():'';
  if (!txt) return; if(inp) inp.value='';
  addUser(txt); showTyping();
  callGemini(txt).then(function(reply) {
    hideTyping(); addBot(reply);
  }).catch(function() {
    hideTyping(); addBot(getResponse(txt));
  });
}

// ── URLhaus URL Scanner ───────────────────────────────
var IP_RE_SCAN = /^(\d{1,3}\.){3}\d{1,3}$/;

function convertUrlToLocalhost(url) {
  try {
    var u = url.trim();
    if (!u.startsWith('http')) u = 'http://' + u;
    var parsed = new URL(u);
    var host   = parsed.hostname;
    var path   = parsed.pathname.replace(/^\//, '');
    if (IP_RE_SCAN.test(host)) {
      var simUrl = 'http://localhost:8080/' + host + (path ? '/' + path : '/bin.sh');
      return { converted: true, simUrl: simUrl, ip: host, path: path || 'bin.sh' };
    }
    return { converted: false, simUrl: u };
  } catch(e) {
    return { converted: false, simUrl: url };
  }
}

function getVerdictDisplay(v) {
  if (v === 'blocked') return '🔴 BLOCKED';
  if (v === 'warned')  return '🟡 WARNING';
  return '🟢 SAFE';
}

function initUrlScanner() {
  var scanBtn   = document.getElementById('uhScanBtn');
  var scanInput = document.getElementById('uhScanInput');
  var resultDiv = document.getElementById('uhScanResult');

  if (!scanBtn || !scanInput || !resultDiv) return;

  function doScan() {
    var input = scanInput.value.trim();
    if (!input) {
      var t = document.getElementById('uhScanText');
      if (t) t.textContent = 'Please enter a URL!';
      resultDiv.className = 'bh-scan-result warned show';
      return;
    }

    scanBtn.disabled    = true;
    scanBtn.textContent = '⏳';
    resultDiv.className = 'bh-scan-result';

    var conv    = convertUrlToLocalhost(input);
    var scanUrl = conv.simUrl;

    chrome.storage.local.get('apiEndpoint', function(cfg) {
      var base = (cfg.apiEndpoint || 'http://localhost:8000').replace(/\/+$/, '');
      fetch(base + '/api/v1/url-check', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ url: scanUrl })
      })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        var v     = data.verdict || 'safe';
        var score = data.score   || 0;
        var warns = data.warnings || [];
        var warnTxt = warns.length
          ? warns.map(function(w){ return '▸ ' + w; }).join('<br>')
          : '';

        resultDiv.className = 'bh-scan-result show ' + v;
        var textEl = document.getElementById('uhScanText');
        if (textEl) {
          textEl.innerHTML = '<strong>' + getVerdictDisplay(v) + '</strong> — Score: ' + score + '/100'
            + (warnTxt ? '<br>' + warnTxt : '');
        }

        // Auto-open localhost simulation tab if IP was converted
        if (conv.converted) {
          chrome.tabs.create({ url: scanUrl, active: false });
        }

        // Auto-hide after 8 seconds
        clearTimeout(window._scanTimer);
        window._scanTimer = setTimeout(function() {
          resultDiv.className = 'bh-scan-result';
          scanInput.value = '';
        }, 8000);
      })
      .catch(function() {
        resultDiv.className = 'bh-scan-result warned show';
        var textEl2 = document.getElementById('uhScanText');
        if (textEl2) textEl2.textContent = '⚠ Cannot connect to backend.';
        clearTimeout(window._scanTimer);
        window._scanTimer = setTimeout(function() {
          resultDiv.className = 'bh-scan-result';
        }, 4000);
      })
      .finally(function() {
        scanBtn.disabled    = false;
        scanBtn.textContent = '→';
      });
    });
  }

  // Fix button click — use both click and mousedown
  scanBtn.addEventListener('mousedown', function(e) {
    e.preventDefault();
    doScan();
  });
  scanBtn.addEventListener('click', doScan);
  scanInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') doScan();
  });

  // X close button
  var closeBtn = document.getElementById('uhScanClose');
  if (closeBtn) {
    closeBtn.addEventListener('click', function() {
      clearTimeout(window._scanTimer);
      resultDiv.className = 'bh-scan-result';
      scanInput.value = '';
    });
  }
}

// Initialize URL scanner after DOM ready
setTimeout(initUrlScanner, 200);