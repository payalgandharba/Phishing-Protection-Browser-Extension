// PhishingShield Pro v4.1 — Content Script (Floating Badge)
// Developer: Payal Gandharba | NP069619 | CT052-3-3-IR

(function() {
  'use strict';
  if (window.__pspInjected) return;
  window.__pspInjected = true;
  if (location.protocol === 'chrome-extension:') return;

  // ── STYLES ────────────────────────────────────────────
  var css = document.createElement('style');
  css.textContent = `
    #psp-widget {
      position: fixed;
      bottom: 20px;
      right: 18px;
      z-index: 2147483647;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      -webkit-font-smoothing: antialiased;
      animation: pspIn .4s cubic-bezier(.4,0,.2,1);
    }
    @keyframes pspIn {
      from { opacity:0; transform:translateY(16px) scale(.95); }
      to   { opacity:1; transform:translateY(0) scale(1); }
    }

    /* ── DEFAULT PILL ── */
    #psp-pill {
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 8px 14px 8px 10px;
      border-radius: 99px;
      cursor: pointer;
      border: 1.5px solid rgba(255,255,255,.28);
      box-shadow: 0 4px 20px rgba(0,0,0,.2), 0 2px 6px rgba(0,0,0,.12);
      transition: transform .2s, box-shadow .2s;
      user-select: none;
    }
    #psp-pill:hover {
      transform: translateY(-2px) scale(1.03);
      box-shadow: 0 8px 28px rgba(0,0,0,.25);
    }
    #psp-pill.safe    { background: linear-gradient(135deg,#16a34a,#15803d); }
    #psp-pill.warned  { background: linear-gradient(135deg,#d97706,#b45309); }
    #psp-pill.blocked { background: linear-gradient(135deg,#dc2626,#b91c1c); }
    #psp-pill.scanning{ background: linear-gradient(135deg,#2563eb,#7c3aed); }

    .psp-dot {
      width: 8px; height: 8px; border-radius: 50%;
      background: rgba(255,255,255,.5); flex-shrink: 0;
    }
    .psp-dot.pulse { animation: pspPulse 1.5s ease infinite; }
    @keyframes pspPulse { 0%,100%{opacity:1;transform:scale(1);}50%{opacity:.4;transform:scale(.7);} }
    .psp-dot.safe    { background: #bbf7d0; box-shadow: 0 0 0 2px rgba(187,247,208,.4); }
    .psp-dot.warned  { background: #fef08a; box-shadow: 0 0 0 2px rgba(254,240,138,.4); }
    .psp-dot.blocked { background: #fecaca; box-shadow: 0 0 0 2px rgba(254,202,202,.4); }

    .psp-pill-text {
      font-size: 12px; font-weight: 800; color: #fff; letter-spacing: .3px;
    }
    .psp-pill-score {
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px; font-weight: 600;
      color: rgba(255,255,255,.8);
      background: rgba(0,0,0,.18);
      border-radius: 99px; padding: 1px 7px;
    }
    .psp-chevron {
      font-size: 9px; color: rgba(255,255,255,.7);
      transition: transform .25s; margin-left: 1px;
    }
    #psp-widget.open .psp-chevron { transform: rotate(180deg); }

    /* ── EXPANDED PANEL ── */
    #psp-panel {
      position: absolute;
      bottom: calc(100% + 10px);
      right: 0;
      width: 268px;
      background: #fff;
      border-radius: 18px;
      border: 1.5px solid #e2e8f0;
      box-shadow: 0 12px 40px rgba(0,0,0,.16), 0 4px 12px rgba(0,0,0,.08);
      overflow: hidden;
      transform: translateY(14px) scale(.95);
      opacity: 0;
      pointer-events: none;
      transition: all .28s cubic-bezier(.4,0,.2,1);
      transform-origin: bottom right;
    }
    #psp-widget.open #psp-panel {
      transform: translateY(0) scale(1);
      opacity: 1;
      pointer-events: all;
    }

    /* Top accent strip */
    .psp-accent { height: 4px; }
    .psp-accent.safe    { background: linear-gradient(90deg,#22c55e,#4ade80); }
    .psp-accent.warned  { background: linear-gradient(90deg,#f59e0b,#fbbf24); }
    .psp-accent.blocked { background: linear-gradient(90deg,#ef4444,#f87171); }
    .psp-accent.scanning{ background: linear-gradient(90deg,#3b82f6,#8b5cf6); }

    /* Panel header — brand row */
    .psp-head {
      display: flex; align-items: center; gap: 9px;
      padding: 11px 13px 9px;
      border-bottom: 1px solid #f1f5f9;
      background: #f8faff;
    }
    .psp-logo {
      width: 26px; height: 26px; border-radius: 7px;
      background: linear-gradient(135deg,#2563eb,#7c3aed);
      display: flex; align-items: center; justify-content: center;
      font-size: 13px; flex-shrink: 0;
    }
    .psp-brand-name { font-size: 11px; font-weight: 800; color: #0f172a; }
    .psp-brand-sub  { font-size: 8px; color: #94a3b8; font-family: monospace; margin-top: 1px; }
    .psp-close {
      margin-left: auto; width: 22px; height: 22px;
      border-radius: 6px; background: #f1f5f9;
      border: none; cursor: pointer; font-size: 12px;
      color: #64748b; display: flex; align-items: center;
      justify-content: center; transition: .15s; flex-shrink: 0;
    }
    .psp-close:hover { background: #fee2e2; color: #dc2626; }

    /* Verdict row */
    .psp-verdict {
      display: flex; align-items: center; gap: 11px;
      padding: 13px 14px 10px;
    }
    .psp-verdict-pill {
      display: flex; align-items: center; gap: 7px;
      padding: 8px 13px; border-radius: 99px;
      font-size: 13px; font-weight: 900;
      flex-shrink: 0; color: #fff;
    }
    .psp-verdict-pill.safe    { background: linear-gradient(135deg,#16a34a,#15803d); box-shadow: 0 3px 12px rgba(22,163,74,.35); }
    .psp-verdict-pill.warned  { background: linear-gradient(135deg,#d97706,#b45309); box-shadow: 0 3px 12px rgba(217,119,6,.35); }
    .psp-verdict-pill.blocked { background: linear-gradient(135deg,#dc2626,#b91c1c); box-shadow: 0 3px 12px rgba(220,38,38,.35); }
    .psp-verdict-pill.scanning{ background: linear-gradient(135deg,#2563eb,#7c3aed); box-shadow: 0 3px 12px rgba(37,99,235,.35); }

    .psp-vinfo { flex: 1; min-width: 0; }
    .psp-domain {
      font-family: monospace; font-size: 10px; color: #64748b;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
      margin-bottom: 3px; font-weight: 600;
    }
    .psp-tagline { font-size: 10px; font-weight: 600; }
    .psp-tagline.safe    { color: #16a34a; }
    .psp-tagline.warned  { color: #d97706; }
    .psp-tagline.blocked { color: #dc2626; }
    .psp-tagline.scanning{ color: #64748b; }

    /* Risk + Confidence cards */
    .psp-meta {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 7px; padding: 0 14px 10px;
    }
    .psp-meta-card {
      background: #f8faff; border: 1px solid #e2e8f0;
      border-radius: 9px; padding: 8px 10px; text-align: center;
    }
    .psp-meta-lbl {
      font-size: 8px; text-transform: uppercase; letter-spacing: .5px;
      color: #94a3b8; font-weight: 700; margin-bottom: 4px; font-family: monospace;
    }
    .psp-meta-val { font-size: 14px; font-weight: 800; font-family: monospace; }

    /* Flags */
    .psp-flags { padding: 0 14px 10px; }
    .psp-flag-item {
      display: flex; align-items: flex-start; gap: 6px;
      font-size: 10px; color: #64748b; padding: 3px 0;
      border-bottom: 1px solid #f1f5f9;
    }
    .psp-flag-item:last-child { border-bottom: none; }
    .psp-flag-arrow { color: #f59e0b; font-size: 9px; margin-top: 2px; flex-shrink: 0; }
    .psp-no-flags { font-size: 10px; color: #16a34a; font-weight: 600; padding: 3px 0; }

    /* ML strip */
    .psp-ml {
      display: flex; justify-content: space-between;
      margin: 0 14px 10px;
      background: #f8faff; border: 1px solid #e2e8f0;
      border-radius: 8px; padding: 7px 10px;
      font-family: monospace; font-size: 9px;
    }
    .psp-ml-lbl { color: #94a3b8; }
    .psp-ml-vals { display: flex; gap: 8px; }
    .psp-ml-v { font-weight: 700; }

    /* View Details button */
    .psp-btn-details {
      display: flex; align-items: center; justify-content: center; gap: 6px;
      width: calc(100% - 28px); margin: 0 14px 13px;
      padding: 9px; border-radius: 10px; border: none; cursor: pointer;
      background: linear-gradient(135deg,#2563eb,#7c3aed);
      color: #fff; font-size: 11px; font-weight: 700;
      box-shadow: 0 2px 10px rgba(37,99,235,.3);
      transition: all .2s; font-family: inherit;
    }
    .psp-btn-details:hover {
      transform: translateY(-1px);
      box-shadow: 0 4px 16px rgba(37,99,235,.4);
    }

    /* Action buttons for blocked/warned */
    .psp-actions {
      display: grid; grid-template-columns: 1fr 1fr;
      gap: 6px; padding: 0 14px 13px;
    }
    .psp-act-btn {
      padding: 8px; border-radius: 9px; font-family: inherit;
      font-size: 11px; font-weight: 700; cursor: pointer;
      border: 1.5px solid; transition: .15s; text-align: center;
    }
    .psp-act-back {
      background: rgba(220,38,38,.08); color: #dc2626;
      border-color: rgba(220,38,38,.2);
    }
    .psp-act-back:hover { background: rgba(220,38,38,.14); }
    .psp-act-stay {
      background: #f8faff; color: #64748b;
      border-color: #e2e8f0;
    }
    .psp-act-stay:hover { background: #f1f5f9; }

    /* Panel footer */
    .psp-footer {
      display: flex; justify-content: space-between;
      padding: 6px 14px; border-top: 1px solid #f1f5f9;
      background: #fafbff;
    }
    .psp-footer span { font-family: monospace; font-size: 8px; color: #cbd5e1; }

    /* ── TOP WARNING BANNER ── */
    #psp-banner {
      position: fixed; top: 0; left: 0; right: 0;
      z-index: 2147483646;
      display: flex; align-items: center; gap: 12px;
      padding: 10px 18px;
      font-family: 'Inter', -apple-system, sans-serif;
      color: #fff;
      transform: translateY(-100%);
      transition: transform .35s cubic-bezier(.4,0,.2,1);
    }
    #psp-banner.warned  { background: linear-gradient(90deg,#d97706,#b45309); border-bottom: 2px solid #fbbf24; }
    #psp-banner.blocked { background: linear-gradient(90deg,#dc2626,#b91c1c); border-bottom: 2px solid #f87171; }
    #psp-banner.show    { transform: translateY(0); }
    .psp-banner-icon  { font-size: 18px; flex-shrink: 0; }
    .psp-banner-body  { flex: 1; }
    .psp-banner-title { font-size: 12px; font-weight: 800; }
    .psp-banner-sub   { font-size: 10px; color: rgba(255,255,255,.75); margin-top: 1px; }
    .psp-banner-score {
      font-family: monospace; font-size: 13px; font-weight: 700;
      background: rgba(0,0,0,.2); border-radius: 6px; padding: 3px 10px; flex-shrink: 0;
    }
    .psp-banner-back {
      background: #fff; color: #dc2626; border: none;
      padding: 5px 12px; border-radius: 7px; font-size: 11px;
      font-weight: 700; cursor: pointer; font-family: inherit;
    }
    .psp-banner-dismiss {
      background: rgba(255,255,255,.15); border: 1px solid rgba(255,255,255,.25);
      color: #fff; padding: 5px 12px; border-radius: 7px;
      font-size: 11px; font-weight: 600; cursor: pointer; font-family: inherit;
    }
    .psp-banner-x {
      background: none; border: none; color: rgba(255,255,255,.6);
      font-size: 18px; cursor: pointer; padding: 0 2px; flex-shrink: 0;
    }
    .psp-banner-x:hover { color: #fff; }
  `;
  document.head.appendChild(css);

  // ── BUILD WIDGET ──────────────────────────────────────
  var widget = document.createElement('div');
  widget.id = 'psp-widget';
  widget.innerHTML = `
    <div id="psp-panel">
      <div class="psp-accent scanning" id="psp-acc"></div>
      <div class="psp-head">
        <div class="psp-logo">⚡</div>
        <div>
          <div class="psp-brand-name">PhishingShield Pro</div>
          <div class="psp-brand-sub">NP069619 · CT052-3-3-IR · v4.1</div>
        </div>
        <button class="psp-close" id="psp-x">✕</button>
      </div>
      <div class="psp-verdict">
        <div class="psp-verdict-pill scanning" id="psp-vpill">
          <div class="psp-dot pulse" id="psp-vdot"></div>
          <span id="psp-vword">SCANNING</span>
        </div>
        <div class="psp-vinfo">
          <div class="psp-domain" id="psp-domain">Analysing…</div>
          <div class="psp-tagline scanning" id="psp-tag">Checking page security…</div>
        </div>
      </div>
      <div class="psp-meta">
        <div class="psp-meta-card">
          <div class="psp-meta-lbl">Risk Level</div>
          <div class="psp-meta-val" id="psp-risk" style="color:#94a3b8">—</div>
        </div>
        <div class="psp-meta-card">
          <div class="psp-meta-lbl">Confidence</div>
          <div class="psp-meta-val" id="psp-conf" style="color:#2563eb">—</div>
        </div>
      </div>
      <div class="psp-flags" id="psp-flags">
        <div class="psp-no-flags">✓ No threats detected</div>
      </div>
      <div class="psp-ml">
        <span class="psp-ml-lbl">🤖 ML · UNSW-NB15</span>
        <div class="psp-ml-vals">
          <span class="psp-ml-v" style="color:#16a34a">RF <span id="psp-rf">97.75%</span></span>
          <span class="psp-ml-v" style="color:#2563eb">SVM <span id="psp-svm">93.63%</span></span>
        </div>
      </div>
      <div id="psp-actions"></div>
      <button class="psp-btn-details" id="psp-details">⛶ View Full Details</button>
      <div class="psp-footer">
        <span>PhishingShield Pro · NP069619</span>
        <span id="psp-time"></span>
      </div>
    </div>
    <div id="psp-pill" class="scanning">
      <div class="psp-dot pulse" id="psp-pdot"></div>
      <span class="psp-pill-text" id="psp-plabel">SCANNING</span>
      <span class="psp-chevron">▲</span>
    </div>
  `;
  document.body.appendChild(widget);

  // ── TOGGLE ────────────────────────────────────────────
  document.getElementById('psp-pill').addEventListener('click', function(e) {
    e.stopPropagation();
    widget.classList.toggle('open');
    // User clicked — cancel auto-hide and show widget
    clearTimeout(window._pspHideTimer);
    widget.style.display   = '';
    widget.style.opacity   = '1';
    widget.style.transform = '';
    if (widget.classList.contains('open')) {
      document.getElementById('psp-time').textContent = new Date().toLocaleTimeString();
    }
  });
  document.getElementById('psp-x').addEventListener('click', function(e) {
    e.stopPropagation();
    widget.classList.remove('open');
  });
  document.getElementById('psp-details').addEventListener('click', function() {
    chrome.runtime.sendMessage({ type: 'OPEN_POPUP_DETAILS' });
  });
  document.addEventListener('click', function(e) {
    if (!widget.contains(e.target)) widget.classList.remove('open');
  });

  // ── RENDER ────────────────────────────────────────────
  function render(data) {
    var v   = (data.status || 'scanning').toLowerCase();
    var sc  = data.score || 0;
    var dom = '';
    try { dom = new URL(data.url || ('http://' + location.hostname)).hostname; }
    catch(e) { dom = data.domain || location.hostname; }
    var warns = data.warnings || [];
    var cls   = v === 'safe' ? 'safe' : v === 'warned' ? 'warned' : v === 'blocked' ? 'blocked' : 'scanning';

    // Pill
    var pill    = document.getElementById('psp-pill');
    var plabel  = document.getElementById('psp-plabel');
    var pdot    = document.getElementById('psp-pdot');
    var pilllbl = v === 'safe' ? '🟢 SAFE' : v === 'warned' ? '🟡 WARNING' : v === 'blocked' ? '🔴 BLOCKED' : '⏳ SCANNING';
    pill.className = cls;
    plabel.textContent = pilllbl;
    pdot.className = 'psp-dot ' + (v === 'safe' ? 'safe' : v === 'warned' ? 'warned' : v === 'blocked' ? 'blocked' : 'pulse');

    // Panel accent
    document.getElementById('psp-acc').className = 'psp-accent ' + cls;

    // Verdict pill
    var vp = document.getElementById('psp-vpill');
    vp.className = 'psp-verdict-pill ' + cls;
    document.getElementById('psp-vdot').className = 'psp-dot ' + (v === 'safe' ? 'safe' : v === 'warned' ? 'warned' : v === 'blocked' ? 'blocked' : 'pulse');
    document.getElementById('psp-vword').textContent = v === 'safe' ? '✅ SAFE' : v === 'warned' ? '⚠️ WARNING' : v === 'blocked' ? '🚫 BLOCKED' : '⏳ Scanning…';

    // Domain + tagline
    document.getElementById('psp-domain').textContent = dom;
    var tag = document.getElementById('psp-tag');
    tag.className = 'psp-tagline ' + cls;
    tag.textContent = v === 'safe' ? '✓ No phishing threats detected'
      : v === 'warned' ? '⚠️ Suspicious activity detected'
      : v === 'blocked' ? '🚫 Phishing threat blocked'
      : 'Checking page security…';

    // Risk — always show even for safe sites with score 0
    var risk = document.getElementById('psp-risk');
    var rl   = sc >= 90 ? 'Critical' : sc >= 70 ? 'High' : sc >= 40 ? 'Medium' : 'Low';
    var rc   = sc >= 90 ? '#dc2626' : sc >= 70 ? '#d97706' : sc >= 40 ? '#f59e0b' : '#16a34a';
    risk.textContent = rl; risk.style.color = rc;

    // Confidence — always show
    var conf = document.getElementById('psp-conf');
    var rfp  = data.rf_prob || data.ml_prob;
    var confVal = rfp ? Math.round(rfp * 100) + '%' : Math.max(72, 100 - Math.round(sc * 0.08)) + '%';
    conf.textContent = confVal;

    // ML probs
    if (data.rf_prob  != null) document.getElementById('psp-rf').textContent  = (data.rf_prob  * 100).toFixed(1) + '%';
    if (data.svm_prob != null) document.getElementById('psp-svm').textContent = (data.svm_prob * 100).toFixed(1) + '%';

    // Flags
    var flags = document.getElementById('psp-flags');
    if (!warns.length) {
      flags.innerHTML = '<div class="psp-no-flags">✓ No threats detected</div>';
    } else {
      flags.innerHTML = warns.slice(0, 3).map(function(w) {
        return '<div class="psp-flag-item"><span class="psp-flag-arrow">▸</span>' + w + '</div>';
      }).join('');
    }

    // Action buttons
    var acts = document.getElementById('psp-actions');
    if (v === 'blocked' || v === 'warned') {
      acts.innerHTML = '<div class="psp-actions">'
        + '<button class="psp-act-btn psp-act-back" id="psp-goback">← Go Back</button>'
        + '<button class="psp-act-btn psp-act-stay" id="psp-stay">Proceed</button>'
        + '</div>';
      document.getElementById('psp-goback').addEventListener('click', function() { history.back(); });
      document.getElementById('psp-stay').addEventListener('click', function() { widget.classList.remove('open'); });
    } else {
      acts.innerHTML = '';
    }

    // Auto-open panel for threats
    if (v === 'blocked' || v === 'warned') {
      widget.classList.add('open');
      document.getElementById('psp-time').textContent = new Date().toLocaleTimeString();
    }

    // Auto-hide — safe sites hide after 5s, blocked/warned stay visible
    clearTimeout(window._pspHideTimer);
    if (v === 'safe') {
      window._pspHideTimer = setTimeout(function() {
        widget.style.transition = 'opacity .4s, transform .4s';
        widget.style.opacity    = '0';
        widget.style.transform  = 'translateY(20px) scale(.9)';
        setTimeout(function() {
          widget.style.display = 'none';
        }, 400);
      }, 5000);
    }
    // blocked/warned — badge stays visible permanently
  }

  // ── WARNING BANNER ────────────────────────────────────
  function showBanner(data) {
    var existing = document.getElementById('psp-banner');
    if (existing) existing.remove();

    var v   = (data.status || 'warned').toLowerCase();
    var sc  = data.score || 0;
    var dom = '';
    try { dom = new URL(data.url || '').hostname; } catch(e) { dom = data.domain || ''; }
    var warns = (data.warnings || []).slice(0, 2).join(' · ');

    var banner = document.createElement('div');
    banner.id = 'psp-banner';
    banner.className = v;
    banner.innerHTML =
      '<span class="psp-banner-icon">' + (v === 'blocked' ? '🚫' : '⚠️') + '</span>'
      + '<div class="psp-banner-body">'
      + '<div class="psp-banner-title">PhishingShield Pro — ' + (v === 'blocked' ? 'Phishing Site Blocked' : 'Suspicious Site Detected') + '</div>'
      + '<div class="psp-banner-sub">' + dom + (warns ? ' · ' + warns : '') + '</div>'
      + '</div>'
      + '<div class="psp-banner-score">' + sc + '/100</div>'
      + (v === 'blocked' ? '<button class="psp-banner-back" id="psp-bb">← Go Back</button>' : '')
      + '<button class="psp-banner-dismiss" id="psp-bd">Continue</button>'
      + '<button class="psp-banner-x" id="psp-bx">✕</button>';

    document.body.insertBefore(banner, document.body.firstChild);
    setTimeout(function() { banner.classList.add('show'); }, 50);

    function closeBanner() {
      banner.classList.remove('show');
      setTimeout(function() { if (banner.parentNode) banner.remove(); }, 350);
    }

    var bx = document.getElementById('psp-bx');
    var bd = document.getElementById('psp-bd');
    var bb = document.getElementById('psp-bb');
    if (bx) bx.addEventListener('click', closeBanner);
    if (bd) bd.addEventListener('click', closeBanner);
    if (bb) bb.addEventListener('click', function() { history.back(); });

    if (v === 'warned') setTimeout(closeBanner, 8000);
  }

  // ── MESSAGE LISTENER ──────────────────────────────────
  chrome.runtime.onMessage.addListener(function(msg) {
    // Support both old and new message formats
    var data = msg.data || msg;

    if (msg.type === 'SHOW_WIDGET' || msg.type === 'SHOW_BADGE') {
      // Always render latest result — override any previous render
      render(data);
      // Make sure widget is visible
      widget.style.display   = '';
      widget.style.opacity   = '1';
      widget.style.transform = '';
    }
    if (msg.type === 'SHOW_BANNER' || msg.type === 'SHOW_WARNING_BANNER') {
      showBanner(data);
      render(data);
    }
    if (msg.type === 'HIDE_WIDGET' || msg.type === 'HIDE_BADGE') {
      widget.remove();
    }
  });

  // ── REQUEST CURRENT SCAN ON LOAD — retry 3 times ────
  function requestScan(attempt) {
    chrome.runtime.sendMessage({ type: 'GET_CURRENT_SCAN' }, function(resp) {
      if (chrome.runtime.lastError) return;
      if (resp && resp.status) {
        render(resp);
      } else if (attempt < 3) {
        // Retry — scan may not be ready yet
        setTimeout(function() { requestScan(attempt + 1); }, 800);
      }
    });
  }
  requestScan(1);

})();


// ── LINK HOVER PREVIEW ────────────────────────────────
// Shows verdict tooltip when hovering over any link
(function() {
  var tooltip = null;
  var hoverTimer = null;

  function createTooltip() {
    var t = document.createElement('div');
    t.id = 'psp-hover-tooltip';
    t.style.cssText = [
      'position:fixed',
      'z-index:2147483647',
      'background:#fff',
      'border-radius:12px',
      'padding:10px 14px',
      'box-shadow:0 4px 24px rgba(109,36,71,.2),0 2px 8px rgba(0,0,0,.1)',
      'font-family:Inter,sans-serif',
      'font-size:12px',
      'pointer-events:none',
      'transition:opacity .2s',
      'opacity:0',
      'min-width:200px',
      'max-width:300px',
      'border:1.5px solid #f5d0d8'
    ].join(';');
    document.body.appendChild(t);
    return t;
  }

  function scoreURL(url) {
    var s = 0; var w = [];
    var u = url.toLowerCase();
    var p = '';
    try { p = new URL(u).pathname.toLowerCase(); } catch(e) {}
    var full = u + p;

    // Basic checks
    if (!u.startsWith('https'))                                            { s+=15; w.push('No HTTPS'); }

    // Suspicious TLDs
    if (/\.(tk|ml|ga|cf|gq|xyz|top|club|pw|cc|ru|cn|to|ws)(|\/)/.test(u)) { s+=25; w.push('Suspicious TLD'); }

    // IP address as host — strong malware signal
    if (/^https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(u))       { s+=40; w.push('IP address URL'); }

    // Executable/malware file extensions — very strong signal
    if (/\.(exe|dll|bat|ps1|vbs|msi|jar|sh|elf|bin|php|py|rb)(\?|$)/.test(full)) { s+=40; w.push('Malware file type'); }

    // Malware path keywords
    if (/\/bin\/|\/gate\.php|\/panel\/|\/upload\/|\/bot\/|\/c2\/|\/drop\/|\/down\/|\/shell\/|\/cmd\//.test(full)) { s+=35; w.push('Malware path pattern'); }

    // Known malware family names
    if (/mozi|mirai|emotet|lokibot|nanocore|remcos|asyncrat|redline|raccoon|stealc|cobalt|metasploit|msf\/|meterpreter/.test(full)) { s+=45; w.push('Known malware family'); }

    // Malware keywords in path
    if (/malware|virus|payload|ransomware|botnet|exploit|trojan|worm|keylog|backdoor|stealer|loader|dropper|inject|shellcode/.test(full)) { s+=35; w.push('Malware keywords'); }

    // Phishing brand + keywords
    if (/paypal|amazon|apple|microsoft|google|facebook|netflix|bank|ebay|chase/.test(full) &&
        /login|verify|secure|account|suspend|alert|confirm|update/.test(full)) { s+=30; w.push('Brand phishing'); }
    else if (/login|verify|secure|suspend|alert|confirm/.test(full))           { s+=15; w.push('Phishing keywords'); }

    // Random looking domain (many numbers/hyphens)
    if ((u.match(/-/g)||[]).length > 3)  { s+=10; w.push('Many hyphens'); }
    if ((u.match(/\d/g)||[]).length > 8) { s+=10; w.push('Many numbers in URL'); }
    if (u.length > 100)                  { s+=10; w.push('Long URL'); }

    // Port number — suspicious
    if (/:\d{4,5}\//.test(u) && !/localhost|127\.0\.0\.1/.test(u)) { s+=15; w.push('Unusual port'); }

    return { score: Math.min(s, 100), warnings: w };
  }

  function showTooltip(url, x, y) {
    if (!tooltip) tooltip = createTooltip();
    var result = scoreURL(url);
    var sc = result.score;
    var verdict = sc >= 90 ? 'BLOCKED' : sc >= 70 ? 'WARNING' : 'SAFE';
    var colors = {
      BLOCKED: { color:'#c40000', bg:'rgba(230,1,1,.08)', icon:'🔴', border:'rgba(230,1,1,.2)' },
      WARNING: { color:'#b86e00', bg:'rgba(217,130,0,.08)', icon:'🟡', border:'rgba(217,130,0,.2)' },
      SAFE:    { color:'#2e7a1a', bg:'rgba(63,160,36,.08)', icon:'🟢', border:'rgba(63,160,36,.2)' }
    };
    var c = colors[verdict];
    var domain = url;
    try { domain = new URL(url.startsWith('http')?url:'http://'+url).hostname; } catch(e) {}

    tooltip.style.border = '1.5px solid ' + c.border;
    tooltip.innerHTML =
      '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">'
      +'<span style="font-size:16px;">'+c.icon+'</span>'
      +'<div>'
      +'<div style="font-weight:900;color:'+c.color+';font-size:13px;letter-spacing:.2px;">'+verdict+'</div>'
      +'<div style="font-family:JetBrains Mono,monospace;font-size:9px;color:#64748b;margin-top:1px;">'+domain+'</div>'
      +'</div>'
      +'<div style="margin-left:auto;text-align:right;">'
      +'<div style="font-family:JetBrains Mono,monospace;font-size:18px;font-weight:900;color:'+c.color+';">'+sc+'</div>'
      +'<div style="font-family:JetBrains Mono,monospace;font-size:8px;color:#94a3b8;">/100</div>'
      +'</div>'
      +'</div>'
      +(result.warnings.length
        ? '<div style="background:'+c.bg+';border-radius:7px;padding:6px 8px;">'
          +result.warnings.slice(0,3).map(function(w){
            return '<div style="font-family:JetBrains Mono,monospace;font-size:9px;color:#64748b;margin-bottom:2px;">▸ '+w+'</div>';
          }).join('')
          +'</div>'
        : '')
      +'<div style="font-family:JetBrains Mono,monospace;font-size:8px;color:#94a3b8;margin-top:6px;text-align:center;">PhishingShield Pro · NP069619</div>';

    // Position tooltip
    var tw = 280;
    var tx = Math.min(x + 12, window.innerWidth - tw - 10);
    var ty = y + 20;
    if (ty + 150 > window.innerHeight) ty = y - 160;
    tooltip.style.left = tx + 'px';
    tooltip.style.top  = ty + 'px';
    tooltip.style.opacity = '1';
  }

  function hideTooltip() {
    if (tooltip) tooltip.style.opacity = '0';
  }

  // Attach hover listeners to all links
  function attachHoverListeners() {
    document.querySelectorAll('a[href]').forEach(function(a) {
      if (a._pspHover) return;
      a._pspHover = true;

      a.addEventListener('mouseenter', function(e) {
        var href = a.href;
        if (!href || href.startsWith('javascript') || href.startsWith('#')) return;
        clearTimeout(hoverTimer);
        hoverTimer = setTimeout(function() {
          showTooltip(href, e.clientX, e.clientY);
        }, 400);
      });

      a.addEventListener('mousemove', function(e) {
        if (tooltip && parseFloat(tooltip.style.opacity) > 0) {
          var tw = 280;
          var tx = Math.min(e.clientX + 12, window.innerWidth - tw - 10);
          var ty = e.clientY + 20;
          if (ty + 150 > window.innerHeight) ty = e.clientY - 160;
          tooltip.style.left = tx + 'px';
          tooltip.style.top  = ty + 'px';
        }
      });

      a.addEventListener('mouseleave', function() {
        clearTimeout(hoverTimer);
        hideTooltip();
      });
    });
  }

  // Run on page load
  attachHoverListeners();

  // Re-run when new links appear (dynamic pages like URLhaus)
  var observer = new MutationObserver(function() {
    attachHoverListeners();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();