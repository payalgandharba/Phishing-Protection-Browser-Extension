// PhishingShield Pro v4.1 — Dashboard JS
// Developer: Payal Gandharba | NP069619 | CT052-3-3-IR

var API = 'http://localhost:8000';
var allEvents = [];
var filteredEvents = [];
var currentPage = 1;
var perPage = 12;
var activeFilter = 'all';
var searchTerm = '';
var startTime = Date.now();
var refreshTimer;

// ── INIT ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

  var backBtn = document.getElementById('backBtn');
  if (backBtn) backBtn.addEventListener('click', function() {
    chrome.windows.create({ url: chrome.runtime.getURL('popup/popup.html'), type:'popup', width:390, height:600, focused:true });
    window.close();
  });

  chrome.storage.local.get('apiEndpoint', function(d) {
    if (d.apiEndpoint) API = d.apiEndpoint;
    var el = document.getElementById('apiEndpointDisplay');
    if (el) el.textContent = API.replace('http://', '');
  });

  // Sidebar navigation
  document.querySelectorAll('.nav-item').forEach(function(item) {
    item.addEventListener('click', function() {
      document.querySelectorAll('.nav-item').forEach(function(n){ n.classList.remove('active'); });
      item.classList.add('active');
      var sec = item.getAttribute('data-sec');
      document.querySelectorAll('.sec').forEach(function(s){ s.classList.remove('active'); });
      var target = document.getElementById('sec-' + sec) || document.getElementById('sec-about');
      if (sec === 'about') target = document.getElementById('sec-about');
      if (sec === 'gamification') { target = document.getElementById('sec-gamification'); loadGamification(); }
      if (target) { target.classList.add('active'); target.scrollIntoView({ behavior:'smooth', block:'start' }); }
      if (sec === 'overview')   { renderRecentList(); updateRiskBars(); }
      if (sec === 'health')     loadHealth();
      if (sec === 'threats')    loadThreatFeed();
      if (sec === 'top')        renderTopDomains();
      if (sec === 'ml')         animateMLBars();
      if (sec === 'apistatus')  loadHealth();
      if (sec === 'urlcheck')   {} // URL checker is self-contained
    });
  });

  loadFromStorage(function() {
    loadAll();
    startAutoRefresh();
  });

  updateClock();
  setInterval(updateClock, 1000);
  animateMLBars();

  var refreshBtn = document.getElementById('refreshBtn');
  if (refreshBtn) refreshBtn.addEventListener('click', function() { loadAll(); toast('⟳ Data refreshed!'); });
  var exportCsvBtn = document.getElementById('exportCsvBtn');
  if (exportCsvBtn) exportCsvBtn.addEventListener('click', exportCSV);
  var exportJsonBtn = document.getElementById('exportJsonBtn');
  if (exportJsonBtn) exportJsonBtn.addEventListener('click', exportJSON);
  var clearBtn = document.getElementById('clearBtn');
  if (clearBtn) clearBtn.addEventListener('click', clearAll);

  var filtSel = document.getElementById('filtSel');
  if (filtSel) filtSel.addEventListener('change', function() {
    activeFilter = this.value; currentPage = 1; renderTable();
  });
  var searchIn = document.getElementById('searchIn');
  if (searchIn) searchIn.addEventListener('input', function() {
    searchTerm = this.value.toLowerCase().trim(); currentPage = 1; renderTable();
  });
});

// ── LOAD FROM STORAGE FIRST ───────────────────────────
function loadFromStorage(callback) {
  chrome.storage.local.get(['scanHistory','history'], function(d) {
    var h = d.scanHistory || d.history || [];
    allEvents = h.map(function(x) {
      return {
        url:       x.url || x.domain || '—',
        verdict:   (x.verdict || x.status || 'safe').toUpperCase(),
        status:    (x.status  || 'safe').toLowerCase(),
        score:     x.score || 0,
        warnings:  x.warnings || [],
        source:    x.source || 'heuristic',
        timestamp: x.ts ? new Date(x.ts).toLocaleTimeString() : (x.timestamp || '—')
      };
    });
    renderStats();
    renderTable();
    renderTopDomains();
    renderRecentList();
    if (callback) callback();
  });
}

// ── CLOCK + UPTIME ────────────────────────────────────
function updateClock() {
  var up  = Math.floor((Date.now() - startTime) / 1000);
  var h   = Math.floor(up / 3600);
  var m   = Math.floor((up % 3600) / 60);
  var s   = up % 60;
  var str = pad(h)+':'+pad(m)+':'+pad(s);
  var el  = document.getElementById('uptimeDisp');   if (el) el.textContent = str;
  var hu  = document.getElementById('healthUptime'); if (hu) hu.textContent = 'Uptime: '+str;
}
function pad(n) { return String(n).padStart(2,'0'); }

// ── AUTO REFRESH ──────────────────────────────────────
function startAutoRefresh() {
  clearInterval(refreshTimer);
  refreshTimer = setInterval(loadAll, 5000);
}

// ── LOAD ALL ──────────────────────────────────────────
function loadAll() {
  loadHealth();
  loadHistory();
  loadThreatFeed();
  var su = document.getElementById('stUpdated');   if (su) su.textContent = 'Updated '+new Date().toLocaleTimeString();
  var lu = document.getElementById('lastUpdated'); if (lu) lu.textContent = 'Updated '+new Date().toLocaleTimeString();
}

// ── HEALTH ────────────────────────────────────────────
function loadHealth() {
  fetch(API+'/health', { signal:AbortSignal.timeout(3000) })
    .then(function(r){ return r.json(); })
    .then(function(d){
      setHealth('hd-api',    'hv-api',    true,               'Healthy · v'+(d.version||'4.1'));
      setHealth('hd-rf',     'hv-rf',     d.rf_loaded,        d.rf_loaded     ? (d.rf_accuracy||97.75)+'% acc'   : 'Not loaded');
      setHealth('hd-svm',    'hv-svm',    d.svm_loaded,       d.svm_loaded    ? (d.svm_accuracy||93.63)+'% acc'  : 'Not loaded');
      setHealth('hd-gemini', 'hv-gemini', d.gemini_enabled,   d.gemini_enabled ? 'Configured'      : 'Offline KB');
      setHealth('hd-sandbox','hv-sandbox',d.sandbox_available, d.sandbox_available ? 'Playwright ready' : 'Not available');
      setHealth('hd-siem',   'hv-siem',   true,               (d.siem_events||0)+' events');
      if (d.rf_accuracy)       updateMLBar('rfBar',  d.rf_accuracy);
      if (d.svm_accuracy)      updateMLBar('svmBar', d.svm_accuracy);
      if (d.ensemble_accuracy) updateMLBar('ensBar', d.ensemble_accuracy);
      if (d.features) { var fc=document.getElementById('featCount'); if(fc)fc.textContent=d.features; }
      updateAPIStatus(d, true);
    })
    .catch(function(){
      setHealth('hd-api',    'hv-api',    false, 'Offline — run RUN_API.bat');
      setHealth('hd-rf',     'hv-rf',     false, '—');
      setHealth('hd-svm',    'hv-svm',    false, '—');
      setHealth('hd-gemini', 'hv-gemini', false, '—');
      setHealth('hd-sandbox','hv-sandbox',false, '—');
      setHealth('hd-siem',   'hv-siem',   false, '—');
      updateAPIStatus({}, false);
    });
}

function setHealth(dotId, valId, ok, val) {
  var dot = document.getElementById(dotId);
  if (dot) dot.className = 'h-dot '+(ok ? 'hd-ok' : 'hd-err');
  if (valId && val) { var el=document.getElementById(valId); if(el)el.textContent=val; }
}

// ── API STATUS SECTION ────────────────────────────────
function updateAPIStatus(d, online) {
  var badge = document.getElementById('apiStatusBadge');
  var text  = document.getElementById('apiStatusText');
  if (online) {
    if (badge) { badge.textContent='● LIVE'; badge.style.color='var(--green2)'; }
    if (text)  { text.textContent='Connected ✓'; text.style.color='var(--green2)'; }
    var map = {
      apiVersion: 'v'+(d.version||'4.1'),
      apiRF:      d.rf_loaded    ? (d.rf_accuracy||97.75)+'% accuracy ✓' : 'Not loaded ✗',
      apiSVM:     d.svm_loaded   ? (d.svm_accuracy||93.63)+'% accuracy ✓' : 'Not loaded ✗',
      apiGemini:  d.gemini_enabled ? 'Configured ✓' : 'Offline KB mode',
      apiSandbox: d.sandbox_available ? 'Playwright ready ✓' : 'Not available'
    };
    Object.keys(map).forEach(function(id) {
      var el = document.getElementById(id);
      if (el) {
        el.textContent = map[id];
        el.style.color = map[id].includes('✓') ? 'var(--green2)' : map[id].includes('✗') ? 'var(--red2)' : 'var(--sub)';
      }
    });
  } else {
    if (badge) { badge.textContent='● OFFLINE'; badge.style.color='var(--red2)'; }
    if (text)  { text.textContent='Cannot connect — run RUN_API.bat'; text.style.color='var(--red2)'; }
    ['apiVersion','apiRF','apiSVM','apiGemini','apiSandbox'].forEach(function(id) {
      var el=document.getElementById(id);
      if (el) { el.textContent='—'; el.style.color='var(--mute)'; }
    });
  }
}

// ── ML BARS ───────────────────────────────────────────
function animateMLBars() {
  setTimeout(function() {
    updateMLBar('rfBar', 97.75);
    updateMLBar('svmBar', 93.63);
    updateMLBar('ensBar', 97.57);
    updateMLBar('uavBar', 99.55);
  }, 600);
}
function updateMLBar(id, pct) { var el=document.getElementById(id); if(el) el.style.width=pct+'%'; }

// ── HISTORY ───────────────────────────────────────────
function loadHistory() {
  fetch(API+'/api/v1/siem-log?limit=500', { signal:AbortSignal.timeout(3000) })
    .then(function(r){ return r.json(); })
    .then(function(d){
      allEvents = d.events || [];
      renderStats(); renderTable(); renderTopDomains(); renderRecentList();
    })
    .catch(function(){
      chrome.storage.local.get(['scanHistory','history'], function(d) {
        var h = d.scanHistory || d.history || [];
        allEvents = h.map(function(x) {
          return {
            url:       x.url || x.domain || '—',
            verdict:   (x.verdict || x.status || 'safe').toUpperCase(),
            status:    (x.status  || 'safe').toLowerCase(),
            score:     x.score || 0,
            warnings:  x.warnings || [],
            source:    x.source || 'heuristic',
            timestamp: x.ts ? new Date(x.ts).toLocaleTimeString() : (x.timestamp || '—')
          };
        });
        renderStats(); renderTable(); renderTopDomains(); renderRecentList();
      });
    });
}

// ── STATS ─────────────────────────────────────────────
function renderStats() {
  var tot = allEvents.length;
  var blk = allEvents.filter(function(e){ var v=(e.verdict||e.status||'').toLowerCase(); return v==='blocked'; }).length;
  var wrn = allEvents.filter(function(e){ var v=(e.verdict||e.status||'').toLowerCase(); return v==='warned'||v==='warning'; }).length;
  var saf = allEvents.filter(function(e){ var v=(e.verdict||e.status||'').toLowerCase(); return v==='safe'; }).length;
  setText('stTot',   tot);
  setText('stBlk',   blk);
  setText('stWrn',   wrn);
  setText('stSafe',  saf);
  setText('stToday', tot+' events logged');
  setText('stBR', tot ? Math.round(blk/tot*100)+'% of total' : '0% of total');
  setText('stWR', tot ? Math.round(wrn/tot*100)+'% of total' : '0% of total');
  setText('stSR', tot ? Math.round(saf/tot*100)+'% of total' : '0% of total');
  updateRiskBars();
}
function setText(id, val) { var el=document.getElementById(id); if(el) el.textContent=val; }

// ── TABLE ─────────────────────────────────────────────
function renderTable() {
  filteredEvents = allEvents.filter(function(e) {
    var v  = (e.verdict||'').toLowerCase();
    var mf = activeFilter==='all' ||
             (activeFilter==='blocked' && v==='blocked') ||
             (activeFilter==='warned'  && (v==='warned'||v==='warning')) ||
             (activeFilter==='safe'    && v==='safe');
    var ms = !searchTerm || (e.url||'').toLowerCase().includes(searchTerm);
    return mf && ms;
  });
  setText('filterCount', filteredEvents.length+' events');
  var total = Math.ceil(filteredEvents.length / perPage);
  if (currentPage > total && total > 0) currentPage = total;
  var start = (currentPage-1)*perPage;
  var slice = filteredEvents.slice(start, start+perPage);
  var tbody = document.getElementById('histTbody');
  if (!tbody) return;
  if (!slice.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="empty">No events match the current filter</td></tr>';
    var pe = document.getElementById('pages'); if(pe) pe.innerHTML='';
    return;
  }
  tbody.innerHTML = slice.map(function(e, i) {
    var domain = '—';
    try { domain = new URL(e.url.startsWith('http')?e.url:'http://'+e.url).hostname; } catch(x){ domain=e.url||'—'; }
    var v    = (e.verdict||'safe').toLowerCase();
    var vc   = v==='blocked'?'b-blocked':v==='warning'||v==='warned'?'b-warned':'b-safe';
    var sc   = e.score||0;
    var sc_c = sc>=90?'var(--red2)':sc>=70?'var(--amber2)':'var(--green2)';
    var flags = (e.warnings||[]).slice(0,2).join(', ')||'—';
    var src   = e.source||'heuristic';
    var time  = e.timestamp||'—';
    return '<tr>'+
      '<td style="font-family:var(--mono);font-size:10px;color:var(--mute);">'+(start+i+1)+'</td>'+
      '<td class="td-domain" title="'+(e.url||'')+'">'+domain+'</td>'+
      '<td><span class="badge '+vc+'">'+(e.verdict||'SAFE')+'</span></td>'+
      '<td class="score-cell" style="color:'+sc_c+'">'+sc+'</td>'+
      '<td><div class="sb-track"><div class="sb-fill" style="background:'+sc_c+';width:'+sc+'%"></div></div></td>'+
      '<td class="flag-cell" title="'+(e.warnings||[]).join(', ')+'">'+flags+'</td>'+
      '<td><span style="font-family:var(--mono);font-size:9px;background:rgba(109,36,71,.08);color:var(--primary);padding:2px 7px;border-radius:4px;">'+src+'</span></td>'+
      '<td class="time-cell">'+time+'</td>'+
      '</tr>';
  }).join('');

  var pagesEl = document.getElementById('pages');
  if (!pagesEl) return;
  if (total <= 1) { pagesEl.innerHTML = ''; return; }
  var html = '';
  for (var i=1; i<=total; i++) {
    html += '<button class="pbn'+(i===currentPage?' active':'')+'" data-p="'+i+'">'+i+'</button>';
  }
  pagesEl.innerHTML = html;
  pagesEl.querySelectorAll('.pbn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      currentPage = parseInt(this.getAttribute('data-p')); renderTable();
    });
  });
}

// ── RECENT LIST ───────────────────────────────────────
function renderRecentList() {
  var el = document.getElementById('recentList');
  var rc = document.getElementById('recentCount');
  if (!el) return;
  if (rc) rc.textContent = allEvents.length+' events';
  var recent = allEvents.slice(-8).reverse();
  if (!recent.length) { el.innerHTML='<div class="empty">No scans yet — browse some websites!</div>'; return; }
  el.innerHTML = recent.map(function(x) {
    var domain = x.url||'—';
    try { domain = new URL(x.url.startsWith('http')?x.url:'http://'+x.url).hostname; } catch(e) {}
    var v  = (x.status||x.verdict||'safe').toLowerCase();
    var vc = v==='blocked'?'b-blocked':v==='warned'||v==='warning'?'b-warned':'b-safe';
    var dc = v==='blocked'?'var(--red2)':v==='warned'||v==='warning'?'var(--amber2)':'var(--green2)';
    return '<div style="display:flex;align-items:center;gap:9px;padding:9px 16px;border-bottom:1px solid var(--line);">'
      +'<div style="width:8px;height:8px;border-radius:50%;background:'+dc+';flex-shrink:0;"></div>'
      +'<span style="flex:1;font-family:var(--mono);font-size:11px;color:var(--sub);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+domain+'</span>'
      +'<span class="badge '+vc+'">'+v.toUpperCase()+'</span>'
      +'<span style="font-family:var(--mono);font-size:10px;color:var(--mute);min-width:28px;text-align:right;">'+(x.score||0)+'</span>'
      +'</div>';
  }).join('');
}

// ── TOP DOMAINS ───────────────────────────────────────
function renderTopDomains() {
  var blocked = allEvents.filter(function(e){ return (e.verdict||'').toLowerCase()==='blocked'; });
  var counts = {};
  blocked.forEach(function(e) {
    var domain = '—';
    try { domain = new URL(e.url.startsWith('http')?e.url:'http://'+e.url).hostname; } catch(x){ domain=e.url||'—'; }
    counts[domain] = (counts[domain]||0)+1;
  });
  var sorted = Object.keys(counts).sort(function(a,b){ return counts[b]-counts[a]; }).slice(0,8);
  var el = document.getElementById('topList');
  if (!el) return;
  if (!sorted.length) { el.innerHTML='<div class="empty">No blocked domains yet</div>'; return; }
  el.innerHTML = sorted.map(function(d,i) {
    return '<div class="top-item">'
      +'<span class="top-rank">'+(i+1)+'</span>'
      +'<span class="top-domain">'+d+'</span>'
      +'<span class="top-count">×'+counts[d]+'</span>'
      +'</div>';
  }).join('');
}

// ── THREAT FEED ───────────────────────────────────────
function loadThreatFeed() {
  fetch(API+'/api/v1/threat-feed', { signal:AbortSignal.timeout(3000) })
    .then(function(r){ return r.json(); })
    .then(function(d){
      var domains = d.domains||d.blacklist||[];
      var el = document.getElementById('threatFeed');
      if (!el) return;
      if (!domains.length){ el.innerHTML='<div class="empty">No threat feed data</div>'; return; }
      el.innerHTML = domains.slice(0,36).map(function(dom){
        return '<div class="feed-item"><div class="feed-dot"></div><span class="feed-domain">'+dom+'</span><span class="feed-badge">PHISHING</span></div>';
      }).join('');
    })
    .catch(function(){
      var builtin = [
        'paypal-secure-login.tk','amazon-security-alert.com','netflix-billing-update.net',
        'google-account-verify.ml','facebook-login-secure.gq','apple-id-suspended.cf',
        'microsoft-support-alert.tk','steam-trade-offer.pw','discord-nitro-free.xyz',
        'instagram-verify.ml','twitter-suspension.tk','ebay-payment-pending.cf',
        'wellsfargo-secure.ml','bankofamerica-alert.tk','chase-account-verify.gq',
        'paypal-secure-verify.tk','amazon-account-alert.ml','microsoft-security-now.ga',
        'apple-id-locked-verify.cf','netflix-billing-issue.xyz','banklogin-secure.top',
        'facebook-verify-now.tk','google-security-alert.ml','instagram-prize.ga',
        'crypto-investment-win.xyz','free-iphone-claim.top','tax-refund-now.cf',
        'ebay-security-update.ml','account-suspended-paypal.xyz','coinbase-account-verify.xyz',
        'binance-security-alert.gq','crypto-wallet-verify.cf','usps-delivery-alert.ml',
        'dhl-package-tracking.tk','fedex-delivery-notification.xyz','irs-refund-gov.cf'
      ];
      var el = document.getElementById('threatFeed');
      if (!el) return;
      el.innerHTML = builtin.map(function(dom){
        return '<div class="feed-item"><div class="feed-dot"></div><span class="feed-domain">'+dom+'</span><span class="feed-badge">PHISHING</span></div>';
      }).join('');
    });
}

// ── EXPORT ────────────────────────────────────────────
function exportCSV() {
  if (!allEvents.length){ toast('⚠️ No data to export'); return; }
  var csv = 'Timestamp,URL,Verdict,Score,Warnings\n'+allEvents.map(function(e){
    return [e.timestamp,'"'+(e.url||'')+'"',e.verdict,e.score,'"'+(e.warnings||[]).join('; ')+'"'].join(',');
  }).join('\n');
  download('phishingshield_'+Date.now()+'.csv', csv, 'text/csv');
  toast('✓ CSV exported!');
}
function exportJSON() {
  if (!allEvents.length){ toast('⚠️ No data to export'); return; }
  download('phishingshield_'+Date.now()+'.json', JSON.stringify(allEvents,null,2), 'application/json');
  toast('✓ JSON exported!');
}
function download(name, content, type) {
  var a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content],{ type:type }));
  a.download = name; a.click();
}

// ── CLEAR ─────────────────────────────────────────────
function clearAll() {
  if (!window.confirm('Clear all scan history? This cannot be undone.')) return;
  chrome.storage.local.set({
    scanHistory:[], history:[],
    statsTotal:0, statsBlocked:0, statsWarned:0, statsSafe:0
  }, function() {
    fetch(API+'/api/v1/siem-log',{ method:'DELETE' }).catch(function(){});
    allEvents=[]; filteredEvents=[]; currentPage=1;
    renderStats(); renderTable(); renderTopDomains(); renderRecentList();
    ['stTot','stBlk','stWrn','stSafe'].forEach(function(id){ setText(id,'0'); });
    ['stBR','stWR','stSR'].forEach(function(id){ setText(id,'0% of total'); });
    setText('stToday','0 events logged');
    toast('✓ History cleared!');
  });
}

// ── TOAST ─────────────────────────────────────────────
function toast(msg) {
  var t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 2800);
}

// ── CHARTS STUB ───────────────────────────────────────
function updateCharts() {}

// ── GAMIFICATION ──────────────────────────────────────
function loadGamification() {
  chrome.storage.local.get(['streak','streakBadge','totalAvoided'], function(d) {
    var sv = document.getElementById('streakVal');
    var av = document.getElementById('avoidedVal');
    var sb = document.getElementById('streakBadgeEl');
    if (sv) sv.textContent = d.streak || 0;
    if (av) av.textContent = d.totalAvoided || 0;
    if (sb) sb.textContent = d.streakBadge || '🛡️ Newcomer';
  });
}

// ── RISK BARS ─────────────────────────────────────────
function updateRiskBars() {
  var bars = document.getElementById('riskBars');
  if (!bars) return;
  var tot = Math.max(allEvents.length, 1);
  var blk = allEvents.filter(function(e){ return (e.verdict||e.status||'').toLowerCase()==='blocked'; }).length;
  var wrn = allEvents.filter(function(e){ var v=(e.verdict||e.status||'').toLowerCase(); return v==='warned'||v==='warning'; }).length;
  var saf = allEvents.filter(function(e){ return (e.verdict||e.status||'').toLowerCase()==='safe'; }).length;

  var safH = Math.max(15, Math.round(saf/tot*90));
  var wrnH = Math.max(15, Math.round(wrn/tot*90));
  var blkH = Math.max(15, Math.round(blk/tot*90));
  var safN = Math.max(1, Math.round(saf/tot*5)+1);
  var wrnN = Math.max(1, Math.round(wrn/tot*3)+1);
  var blkN = Math.max(1, Math.round(blk/tot*3)+1);

  var html = ''; var i;
  for (i=0; i<safN; i++) html += '<div style="width:14px;height:'+safH+'%;background:#2e7a1a;border-radius:3px 3px 0 0;transition:height 1s ease;"></div>';
  for (i=0; i<wrnN; i++) html += '<div style="width:14px;height:'+wrnH+'%;background:#b86e00;border-radius:3px 3px 0 0;transition:height 1s ease;"></div>';
  for (i=0; i<blkN; i++) html += '<div style="width:14px;height:'+blkH+'%;background:#c40000;border-radius:3px 3px 0 0;transition:height 1s ease;"></div>';
  bars.innerHTML = html;
}

// ── URL CHECKER ───────────────────────────────────────
function scoreURL(url) {
  var s = 0; var w = [];
  var u = url.toLowerCase();
  var p = '';
  try { p = new URL(u).pathname.toLowerCase(); } catch(e) {}
  var full = u + p;

  if (!u.startsWith('https'))                                              { s+=15; w.push('No HTTPS'); }
  if (/\.(tk|ml|ga|cf|gq|xyz|top|club|pw|cc|ru|cn|to|ws)(\b|\/)/.test(u)){ s+=25; w.push('Suspicious TLD'); }
  if (/^https?:\/\/\d{1,3}(\.\d{1,3}){3}/.test(u))                       { s+=40; w.push('IP address URL'); }
  if (/\.(exe|dll|bat|ps1|vbs|msi|jar|sh|elf|bin)(\?|$)/.test(full))     { s+=40; w.push('Malware file type'); }
  if (/\/bin\/|\/gate\.php|\/panel\/|\/bot\/|\/c2\/|\/drop\/|\/shell\//.test(full)) { s+=35; w.push('Malware path pattern'); }
  if (/mozi|mirai|emotet|lokibot|nanocore|remcos|asyncrat|redline|raccoon|stealc/.test(full)) { s+=45; w.push('Known malware family'); }
  if (/malware|virus|payload|ransomware|botnet|exploit|trojan|worm|stealer|loader/.test(full)) { s+=35; w.push('Malware keywords'); }
  if (/paypal|amazon|apple|microsoft|google|facebook|netflix|bank|ebay|chase/.test(full) &&
      /login|verify|secure|account|suspend|alert|confirm|update/.test(full)) { s+=30; w.push('Brand + phishing keywords'); }
  else if (/login|verify|secure|suspend|alert|confirm/.test(full))          { s+=15; w.push('Phishing keywords'); }
  if ((u.match(/-/g)||[]).length > 3)   { s+=10; w.push('Many hyphens'); }
  if ((u.match(/\d/g)||[]).length > 8)  { s+=10; w.push('Many numbers'); }
  if (u.length > 100)                   { s+=10; w.push('Long URL'); }
  if (/:\d{4,5}\//.test(u) && !/localhost|127/.test(u)) { s+=15; w.push('Unusual port'); }

  return { score: Math.min(s, 100), warnings: w };
}

function renderURLResult(url) {
  var r  = scoreURL(url);
  var sc = r.score;
  var verdict = sc >= 90 ? 'BLOCKED' : sc >= 70 ? 'WARNING' : 'SAFE';
  var colors = {
    BLOCKED: { color:'var(--red2)',   bg:'var(--red-d)',   border:'rgba(230,1,1,.2)',   icon:'🔴' },
    WARNING: { color:'var(--amber2)', bg:'var(--amber-d)', border:'rgba(217,130,0,.2)', icon:'🟡' },
    SAFE:    { color:'var(--green2)', bg:'var(--green-d)', border:'rgba(63,160,36,.2)', icon:'🟢' }
  };
  var c = colors[verdict];
  var domain = url;
  try { domain = new URL(url.startsWith('http')?url:'http://'+url).hostname; } catch(e) {}

  return '<div style="background:'+c.bg+';border:1.5px solid '+c.border+';border-radius:12px;padding:14px 16px;margin-bottom:8px;">'
    +'<div style="display:flex;align-items:center;gap:10px;margin-bottom:'+(r.warnings.length?'8px':'0')+';">'
    +'<span style="font-size:18px;">'+c.icon+'</span>'
    +'<div style="flex:1;min-width:0;">'
    +'<div style="font-weight:900;color:'+c.color+';font-size:13px;">'+verdict+'</div>'
    +'<div style="font-family:var(--mono);font-size:10px;color:var(--sub);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">'+domain+'</div>'
    +'</div>'
    +'<div style="text-align:right;">'
    +'<div style="font-family:var(--mono);font-size:20px;font-weight:900;color:'+c.color+';">'+sc+'</div>'
    +'<div style="font-family:var(--mono);font-size:9px;color:var(--mute);">/100</div>'
    +'</div></div>'
    +(r.warnings.length
      ? '<div style="display:flex;flex-wrap:wrap;gap:4px;">'
        +r.warnings.map(function(w){
          return '<span style="font-family:var(--mono);font-size:9px;background:rgba(0,0,0,.05);padding:2px 8px;border-radius:99px;color:var(--sub);">▸ '+w+'</span>';
        }).join('')+'</div>'
      : '')
    +'</div>';
}

function checkSingleURL() {
  var inp = document.getElementById('urlCheckInput');
  var res = document.getElementById('urlCheckResult');
  if (!inp || !res) return;
  var url = inp.value.trim();
  if (!url) { toast('⚠️ Please enter a URL'); return; }
  if (!url.startsWith('http')) url = 'http://' + url;
  res.style.display = 'block';
  res.innerHTML = renderURLResult(url);
}

function checkBulkURLs() {
  var inp = document.getElementById('bulkUrlInput');
  var res = document.getElementById('bulkCheckResults');
  if (!inp || !res) return;
  var urls = inp.value.split('\n').map(function(u){ return u.trim(); }).filter(function(u){ return u.length > 3; });
  if (!urls.length) { toast('⚠️ Please paste some URLs'); return; }

  var blocked=0, warned=0, safe=0;
  var html = '';
  urls.forEach(function(url) {
    if (!url.startsWith('http')) url = 'http://' + url;
    var r = scoreURL(url);
    if (r.score>=90) blocked++;
    else if (r.score>=70) warned++;
    else safe++;
    html += renderURLResult(url);
  });

  res.innerHTML =
    '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:12px;">'
    +'<div style="background:var(--red-d);border:1.5px solid rgba(230,1,1,.2);border-radius:10px;padding:12px;text-align:center;">'
    +'<div style="font-size:22px;font-weight:900;font-family:var(--mono);color:var(--red2);">'+blocked+'</div>'
    +'<div style="font-size:9px;color:var(--mute);text-transform:uppercase;">Blocked</div></div>'
    +'<div style="background:var(--amber-d);border:1.5px solid rgba(217,130,0,.2);border-radius:10px;padding:12px;text-align:center;">'
    +'<div style="font-size:22px;font-weight:900;font-family:var(--mono);color:var(--amber2);">'+warned+'</div>'
    +'<div style="font-size:9px;color:var(--mute);text-transform:uppercase;">Warned</div></div>'
    +'<div style="background:var(--green-d);border:1.5px solid rgba(63,160,36,.2);border-radius:10px;padding:12px;text-align:center;">'
    +'<div style="font-size:22px;font-weight:900;font-family:var(--mono);color:var(--green2);">'+safe+'</div>'
    +'<div style="font-size:9px;color:var(--mute);text-transform:uppercase;">Safe</div></div>'
    +'</div>' + html;
}