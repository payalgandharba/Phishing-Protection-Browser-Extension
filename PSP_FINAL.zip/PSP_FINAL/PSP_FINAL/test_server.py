# -*- coding: utf-8 -*-
# PhishingShield Pro v4.1 - Test Server
# Developer: Payal Gandharba | NP069619 | CT052-3-3-IR
# Run: python test_server.py

from http.server import HTTPServer, BaseHTTPRequestHandler
import re

# All URLhaus IPs
URLHAUS_IPS = [
    "125.44.181.178","114.227.49.3","115.55.130.218","221.202.206.125",
    "222.138.182.37","182.114.255.161","171.213.150.35","112.239.122.112",
    "182.113.43.152","182.118.246.94","112.198.193.5","42.239.188.2",
    "217.60.241.248","217.60.241.142","77.83.39.9","77.83.39.66",
    "115.52.190.59","42.224.248.160","222.137.19.202","123.12.239.201",
    "124.131.148.213","116.248.123.33","119.116.88.117","112.242.56.104",
    "115.55.114.89","59.96.142.30","110.36.86.83","27.37.100.231",
    "183.188.204.211","123.133.101.151","42.179.238.52","191.44.112.89",
    "94.154.32.238","62.60.226.140","115.63.203.149","222.139.38.162",
    "175.146.231.101","61.53.124.137","110.186.231.247","222.127.53.189",
    "125.40.122.70","182.124.119.64","221.14.40.110","196.189.68.239",
    "110.37.61.166","123.10.155.173","39.90.150.62","110.38.223.172",
    "156.146.24.110","175.174.66.196","182.121.231.159","46.159.139.237",
    "182.121.82.149","115.51.38.188","1.58.182.84","125.110.49.243",
    "115.50.101.188","113.221.8.44","125.45.64.24","200.115.102.2",
    "42.231.186.227","115.49.127.19","59.96.138.90","42.239.179.192",
    "2.26.81.46","62.60.249.165","196.190.224.62","219.157.243.71",
    "182.117.30.230","110.37.5.157","115.49.30.151","91.92.242.236",
    "77.239.124.108","105.186.143.37","111.127.232.94","192.162.199.149",
    "103.77.246.150","218.0.112.226","115.55.10.187","110.36.1.200",
    "182.117.131.145","115.57.228.213","222.142.222.21","98.36.141.73",
    "60.187.252.24","182.115.232.200","123.132.156.143","105.184.72.21",
    "61.53.1.186","59.97.254.10","36.88.136.194","95.9.35.137",
    "27.215.124.43","60.21.174.229","42.59.78.61","182.116.113.206",
    "59.58.42.29","115.197.32.42","36.70.226.107","182.240.11.199",
    "113.239.64.220","182.126.213.104","123.185.91.133","196.190.105.170",
    "163.142.95.26","119.184.12.198","116.53.20.49","183.23.133.4",
    "115.56.149.40","221.1.247.58","196.189.35.226","115.49.121.20",
    "110.37.44.119","42.235.73.160","124.94.194.151","221.15.14.56",
    "42.235.94.94","110.37.22.216","83.168.69.141","115.230.79.157",
    "200.115.102.246","119.183.3.192","42.179.125.40","120.84.214.125",
    "115.52.194.55","116.2.53.55","37.54.4.193","42.237.4.138",
    "110.36.91.33","110.39.239.253","119.116.142.166","182.129.144.219",
    "42.227.206.54","124.235.207.2","123.189.159.141","125.47.196.33",
    "210.208.110.130","124.161.116.2","42.4.250.38","222.141.21.106",
    "110.38.201.196","182.85.43.191","27.207.229.26","74.127.168.68",
    "42.233.94.20","37.34.242.96","175.148.111.17","27.156.139.177",
    "163.142.77.145","42.85.15.27","42.231.64.252","125.40.83.220",
    "140.237.44.234","213.177.179.52","222.136.169.228","182.119.254.40",
    "222.140.160.44","175.149.87.101","42.86.137.34","42.58.252.41",
    "42.180.57.85","110.36.24.140","110.36.22.249","123.14.94.51",
    "182.120.10.85","182.119.120.150","185.141.233.178","79.106.74.167",
    "222.140.196.94","110.37.43.119","182.116.34.137","95.13.17.211",
    "182.124.9.99","182.127.190.111","182.119.62.97","183.48.166.95",
    "113.230.51.31","119.187.158.17","27.207.141.23","196.189.69.192",
    "222.139.192.15","123.190.18.137","27.217.139.36","117.223.140.197",
    "110.39.228.78","116.76.206.254","125.41.6.205","115.57.248.80",
    "125.41.2.135","123.11.201.153","175.174.107.238","115.48.148.23",
    "222.141.143.158","180.191.228.111","182.119.29.169","115.57.249.167",
    "219.157.215.95","182.121.141.211","125.44.32.162","110.37.68.65",
    "114.228.239.251","221.14.106.66","105.184.34.229","123.129.133.165",
    "222.142.252.78","182.117.78.165","105.184.32.70","110.36.4.125",
    "42.231.93.114","36.69.88.195","105.186.183.165","138.255.178.214",
    "59.96.139.213","110.36.31.205","175.174.68.59","222.137.39.216",
    "78.165.236.7","125.45.146.236","27.201.110.150","125.40.113.119",
    "182.127.177.126","110.36.70.28","27.37.229.199","42.230.18.71",
    "220.192.252.142","179.108.89.220","222.142.250.250","45.38.249.63",
    "72.255.30.244","59.97.249.15","182.112.13.24","112.228.4.224",
    "42.239.152.98","108.170.136.155","222.138.150.155","39.78.26.151",
    "117.24.217.164","27.159.154.179",
]

IP_PATTERN = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")

def is_ip(text):
    return bool(IP_PATTERN.match(text))

def make_malware_page(ip, path):
    if any(x in path for x in ['mozi','Mozi']): family = "Mozi P2P Botnet"
    elif any(x in path for x in ['pito','dp.sh']): family = "Mirai Multi-Arch Botnet"
    elif any(x in path for x in ['main_','gfg','scanner']): family = "Gafgyt/BASHLITE IoT Botnet"
    elif 's.ps1' in path: family = "PowerShell Malware Dropper"
    elif any(x in path for x in ['ScreenConnect','support.client']): family = "ScreenConnect RAT"
    elif any(x in path for x in ['Tz2SZvL','omega','file.exe']): family = "Amadey Botnet Dropper"
    elif any(x in path for x in ['pandora','got','p1.sh','loader']): family = "Generic ELF Malware"
    elif any(x in path for x in ['data_','bbc']): family = "IoT Botnet Payload"
    elif any(x in path for x in ['.exe','.msi','.dat']): family = "Windows Malware Dropper"
    elif 'bin.sh' in path: family = "Mirai Botnet Shell Dropper"
    elif path in ['i','']: family = "Mirai Infection Script"
    else: family = "Malware C2 Server"

    arch = ""
    if 'arm7' in path: arch = "ARM v7"
    elif 'arm6' in path: arch = "ARM v6"
    elif 'arm5' in path: arch = "ARM v5"
    elif 'arm4' in path: arch = "ARM v4"
    elif 'aarch64' in path: arch = "ARM64"
    elif 'arm' in path: arch = "ARM"
    elif 'mipsel' in path or 'mpsl' in path: arch = "MIPS Little-Endian"
    elif 'mips' in path: arch = "MIPS"
    elif 'x86_64' in path or 'x64' in path: arch = "x86-64"
    elif 'x86' in path: arch = "x86 32-bit"
    elif 'ppc440' in path: arch = "PowerPC 440"
    elif 'ppc' in path: arch = "PowerPC"
    elif 'sh4' in path: arch = "SuperH SH4"
    elif 'm68k' in path: arch = "Motorola 68k"
    elif 'sparc' in path: arch = "SPARC"
    elif 'i686' in path: arch = "Intel 686"
    elif 'i486' in path: arch = "Intel 486"

    arch_line = f'<p style="color:#aaa">Architecture: {arch}</p>' if arch else ''

    html = (
        '<!DOCTYPE html><html><head><title>' + family + ' - ' + ip + '</title></head>'
        '<body style="background:#0a0a0a;color:#ff4444;font-family:monospace;padding:40px;text-align:center">'
        '<h1 style="color:#ff0000">' + family.upper() + '</h1>'
        '<p style="color:#00ff00">C2 Server: ' + ip + '</p>'
        '<p style="color:#aaa">Payload: /' + path + '</p>'
        + arch_line +
        '<div style="background:#111;border:1px solid #333;padding:20px;margin:20px auto;max-width:500px;text-align:left">'
        '<p style="color:#ff4444">Threat Intelligence: URLhaus abuse.ch</p>'
        '<p style="color:#aaa">Status: ACTIVE - Reported malware distribution</p>'
        '<p style="color:#aaa">Type: ' + family + '</p>'
        '<p style="color:#aaa">Protocol: HTTP on non-standard port</p>'
        '<p style="color:#ff4444">DO NOT DOWNLOAD - Malware payload!</p>'
        '</div>'
        '<p style="color:#555;font-size:12px">[!] SIMULATION ONLY - PhishingShield Pro v4.1 Demo</p>'
        '<p style="font-size:11px;color:#333">URLhaus Reported - Simulated for safe demonstration</p>'
        '</body></html>'
    )
    return html.encode('ascii', 'replace')

def make_safe_page(url):
    html = (
        '<!DOCTYPE html><html><head><title>URLhaus - Threat Intelligence</title></head>'
        '<body style="background:#fff;color:#333;font-family:Arial;padding:40px;text-align:center">'
        '<h1 style="color:#2e7a1a">URLhaus - abuse.ch</h1>'
        '<p style="color:#2e7a1a">This is a legitimate security research website</p>'
        '<p>URLhaus is operated by abuse.ch - Swiss non-profit cybersecurity organization</p>'
        '<p style="color:#666">URL: ' + url + '</p>'
        '<div style="background:#f0fff0;border:1px solid #2e7a1a;padding:20px;margin:20px auto;max-width:500px">'
        '<p style="color:#2e7a1a">This site is SAFE - Security research platform</p>'
        '<p>Used by security researchers worldwide to report malware URLs</p>'
        '</div>'
        '<p style="font-size:11px;color:#aaa">PhishingShield Pro v4.1 - SAFE verdict</p>'
        '</body></html>'
    )
    return html.encode('ascii', 'replace')

def make_warning_page(url):
    html = (
        '<!DOCTYPE html><html><head><title>Suspicious Site - Warning</title></head>'
        '<body style="background:#fff3cd;color:#856404;font-family:Arial;padding:40px;text-align:center">'
        '<h1>Suspicious Website</h1>'
        '<p>This website shows suspicious characteristics</p>'
        '<p style="color:#666">URL: ' + url + '</p>'
        '<div style="background:#fff8e1;border:1px solid #856404;padding:20px;margin:20px auto;max-width:500px">'
        '<p style="color:#856404">Suspicious domain detected</p>'
        '<p>No HTTPS encryption - data may be intercepted</p>'
        '<p>Proceed with caution - do not enter passwords</p>'
        '</div>'
        '<p style="font-size:11px;color:#aaa">PhishingShield Pro v4.1 - WARNING verdict</p>'
        '</body></html>'
    )
    return html.encode('ascii', 'replace')

# Phishing pages
PAYPAL_BLOCK = b'<!DOCTYPE html><html><head><title>PayPal - Login Verify Account Suspended</title></head><body style="background:#003087;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>PayPal</h2><h1>Login Verify Account Suspended</h1><p>Your account has been suspended. Verify immediately to restore access.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#0070ba;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Login and Verify</button><p style="font-size:11px;margin-top:20px;color:#aad4f5">paypal-login-verify-account-suspended.tk</p></body></html>'
AMAZON_BLOCK = b'<!DOCTYPE html><html><head><title>Amazon - Security Alert</title></head><body style="background:#131921;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#ff9900">Amazon</h2><h1 style="color:#ff9900">Security Alert Verify Account</h1><p>Your Amazon account has been locked. Verify your identity immediately.</p><input type="email" placeholder="Email or Phone" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#ff9900;color:#000;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Sign In and Verify</button><p style="font-size:11px;margin-top:20px;color:#aaa">amazon-security-alert-verify-account.ml</p></body></html>'
MICROSOFT_BLOCK = b'<!DOCTYPE html><html><head><title>Microsoft - Account Alert</title></head><body style="background:#0078d4;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>Microsoft</h2><h1>Account Alert Verify Suspended</h1><p>Your Microsoft account has been locked. Verify your credentials immediately.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#fff;color:#0078d4;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Sign In and Verify</button></body></html>'
NETFLIX_BLOCK = b'<!DOCTYPE html><html><head><title>Netflix - Billing Suspended</title></head><body style="background:#141414;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#e50914;font-size:36px">NETFLIX</h2><h1>Billing Suspended Update Verify</h1><p>Your Netflix account has been suspended due to a billing issue.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="text" placeholder="Card Number" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#e50914;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Update and Verify Payment</button></body></html>'
APPLE_BLOCK = b'<!DOCTYPE html><html><head><title>Apple ID - Suspended</title></head><body style="background:#f5f5f7;color:#1d1d1f;font-family:Arial;padding:40px;text-align:center"><h2>Apple ID</h2><h1>Account Suspended Verify</h1><p style="color:#6e6e73">Your Apple ID has been suspended. Verify your account to restore access.</p><input type="email" placeholder="Apple ID (Email)" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:8px;border:1px solid #ccc"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:8px;border:1px solid #ccc"><button style="background:#0071e3;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:8px;cursor:pointer">Verify Apple ID</button></body></html>'
BANK_BLOCK = b'<!DOCTYPE html><html><head><title>Bank of America - Suspended</title></head><body style="background:#00395d;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>Bank of America</h2><h1>Account Suspended Verify Now</h1><p>Your account has been suspended due to suspicious activity.</p><input type="text" placeholder="Username" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#e31837;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify and Unlock</button></body></html>'
FACEBOOK_BLOCK = b'<!DOCTYPE html><html><head><title>Facebook - Account Suspended</title></head><body style="background:#1877f2;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2 style="font-size:48px;font-weight:900">f</h2><h1>Account Suspended Verify Identity</h1><p>Your Facebook account has been suspended. Verify your identity to restore access.</p><input type="email" placeholder="Email or Phone" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#fff;color:#1877f2;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Log In and Verify</button></body></html>'
GOOGLE_BLOCK = b'<!DOCTYPE html><html><head><title>Google - Account Suspended</title></head><body style="background:#fff;color:#202124;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#4285f4;font-size:36px">Google</h2><h1>Account Suspended Verify Now</h1><p style="color:#5f6368">Your Google account has been suspended. Verify immediately.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:1px solid #ccc"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:1px solid #ccc"><button style="background:#4285f4;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
INSTAGRAM_BLOCK = b'<!DOCTYPE html><html><head><title>Instagram - Verify Account</title></head><body style="background:#833ab4;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>Instagram</h2><h1>Account Suspended Verify Now</h1><p>Your Instagram account has been suspended. Verify to restore access.</p><input type="email" placeholder="Email or Phone" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#fff;color:#dc2743;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Log In and Verify</button></body></html>'
TWITTER_BLOCK = b'<!DOCTYPE html><html><head><title>X - Account Suspended</title></head><body style="background:#000;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2 style="font-size:36px">X</h2><h1>Account Suspended Verify Now</h1><p style="color:#71767b">Your X account has been suspended. Verify to restore access.</p><input type="email" placeholder="Email or Phone" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:1px solid #333;background:#111;color:#fff"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:1px solid #333;background:#111;color:#fff"><button style="background:#1d9bf0;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:99px;cursor:pointer;font-weight:bold">Verify Account</button></body></html>'
COINBASE_BLOCK = b'<!DOCTYPE html><html><head><title>Coinbase - Account Suspended</title></head><body style="background:#0052ff;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>Coinbase</h2><h1>Account Suspended Verify Now</h1><p>Your Coinbase account has been locked due to suspicious activity.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#fff;color:#0052ff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Verify and Unlock</button></body></html>'
EBAY_BLOCK = b'<!DOCTYPE html><html><head><title>eBay - Account Suspended</title></head><body style="background:#e43137;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>ebay</h2><h1>Account Suspended Verify Payment</h1><p>Your eBay account has been suspended. Verify your payment details.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#fff;color:#e43137;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Verify Account</button></body></html>'
MALWARE_BLOCK = b'<!DOCTYPE html><html><head><title>Malware Server</title></head><body style="background:#1a1a1a;color:#ff4444;font-family:monospace;padding:40px;text-align:center"><h1>MALWARE DISTRIBUTION SERVER</h1><p style="color:#aaa">This server distributes malicious payloads and executables.</p><p>botnet-c2.pw | payload.exe | ransomware-loader.dll</p></body></html>'
CHASE_BLOCK = b'<!DOCTYPE html><html><head><title>Chase - Account Suspended</title></head><body style="background:#117aca;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>Chase</h2><h1>Account Suspended Verify Now</h1><p>Your Chase account has been suspended due to suspicious activity.</p><input type="text" placeholder="Username" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#fff;color:#117aca;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Verify Account</button></body></html>'
WELLS_BLOCK = b'<!DOCTYPE html><html><head><title>Wells Fargo - Account Alert</title></head><body style="background:#d71e28;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>Wells Fargo</h2><h1>Account Alert Verify Now</h1><p>Your Wells Fargo account requires immediate verification.</p><input type="text" placeholder="Username" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#ffcd41;color:#000;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Verify Account</button></body></html>'
DISCORD_BLOCK = b'<!DOCTYPE html><html><head><title>Discord - Free Nitro</title></head><body style="background:#5865f2;color:#fff;font-family:Arial;padding:40px;text-align:center"><h2>Discord</h2><h1>You Won FREE Nitro!</h1><p>Claim your free Discord Nitro subscription now! Limited time offer!</p><input type="email" placeholder="Discord Email" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><input type="password" placeholder="Password" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:4px;border:none"><button style="background:#fff;color:#5865f2;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Claim Free Nitro!</button></body></html>'
WARN_PAYPAL = b'<!DOCTYPE html><html><head><title>PayPal - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2>PayPal</h2><h1 style="color:#856404">Verify Your Account</h1><p style="color:#856404">Please verify your account details to continue using PayPal.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#856404;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
WARN_AMAZON = b'<!DOCTYPE html><html><head><title>Amazon - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#ff9900">Amazon</h2><h1 style="color:#856404">Verify Your Account</h1><p style="color:#856404">Please verify your account details to continue.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#ff9900;color:#000;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer;font-weight:bold">Verify Account</button></body></html>'
WARN_MICROSOFT = b'<!DOCTYPE html><html><head><title>Microsoft - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2>Microsoft</h2><h1 style="color:#856404">Account Verification Required</h1><p style="color:#856404">Please verify your Microsoft account to continue.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#0078d4;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
WARN_NETFLIX = b'<!DOCTYPE html><html><head><title>Netflix - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#e50914">NETFLIX</h2><h1 style="color:#856404">Billing Verification Required</h1><p style="color:#856404">Please verify your billing details to continue.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#e50914;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Payment</button></body></html>'
WARN_APPLE = b'<!DOCTYPE html><html><head><title>Apple - Verify</title></head><body style="background:#fff3cd;color:#1d1d1f;font-family:Arial;padding:40px;text-align:center"><h2>Apple ID</h2><h1 style="color:#856404">Verification Required</h1><p style="color:#856404">Please verify your Apple ID to continue.</p><input type="email" placeholder="Apple ID" style="padding:10px;width:300px;display:block;margin:10px auto;border-radius:8px;border:1px solid #ccc"><button style="background:#0071e3;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:8px;cursor:pointer">Verify Apple ID</button></body></html>'
WARN_BANK = b'<!DOCTYPE html><html><head><title>Bank - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2>Bank of America</h2><h1 style="color:#856404">Verification Required</h1><p style="color:#856404">Please verify your account to continue banking.</p><input type="text" placeholder="Username" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#e31837;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
WARN_GOOGLE = b'<!DOCTYPE html><html><head><title>Google - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#4285f4">Google</h2><h1 style="color:#856404">Verification Required</h1><p style="color:#856404">Please verify your Google account to continue.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#4285f4;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
WARN_FACEBOOK = b'<!DOCTYPE html><html><head><title>Facebook - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#1877f2">Facebook</h2><h1 style="color:#856404">Verification Required</h1><p style="color:#856404">Please verify your Facebook account to continue.</p><input type="email" placeholder="Email or Phone" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#1877f2;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
WARN_INSTAGRAM = b'<!DOCTYPE html><html><head><title>Instagram - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#dc2743">Instagram</h2><h1 style="color:#856404">Verification Required</h1><p style="color:#856404">Please verify your Instagram account to continue.</p><input type="email" placeholder="Email or Phone" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#dc2743;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
WARN_TWITTER = b'<!DOCTYPE html><html><head><title>X - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2>X (Twitter)</h2><h1 style="color:#856404">Verification Required</h1><p style="color:#856404">Please verify your X account to continue.</p><input type="email" placeholder="Email or Phone" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#1d9bf0;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:99px;cursor:pointer">Verify Account</button></body></html>'
WARN_EBAY = b'<!DOCTYPE html><html><head><title>eBay - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#e43137">ebay</h2><h1 style="color:#856404">Account Verification Required</h1><p style="color:#856404">Please verify your eBay account to continue.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#e43137;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'
WARN_COINBASE = b'<!DOCTYPE html><html><head><title>Coinbase - Verify</title></head><body style="background:#fff3cd;font-family:Arial;padding:40px;text-align:center"><h2 style="color:#0052ff">Coinbase</h2><h1 style="color:#856404">Verification Required</h1><p style="color:#856404">Please verify your Coinbase account to continue.</p><input type="email" placeholder="Email" style="padding:10px;width:300px;display:block;margin:10px auto;border:1px solid #ccc;border-radius:4px"><button style="background:#0052ff;color:#fff;padding:12px 40px;border:none;font-size:16px;border-radius:4px;cursor:pointer">Verify Account</button></body></html>'

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        p = self.path.lower().lstrip('/')
        original = self.path.lstrip('/')

        # ── 1. URLhaus website links → SAFE ──────────────────────
        if 'urlhaus.abuse.ch' in p or 'abuse.ch' in p:
            self.wfile.write(make_safe_page(original))
            return

        # ── 2. URLhaus IP simulations → BLOCKED ──────────────────
        parts = p.split('/')
        first = parts[0] if parts else ''
        # Remove port if present
        first_clean = first.split(':')[0]
        if is_ip(first_clean) or first_clean in [ip.lower() for ip in URLHAUS_IPS]:
            orig_parts = original.split('/')
            orig_ip = orig_parts[0].split(':')[0]
            path = '/'.join(orig_parts[1:]) if len(orig_parts) > 1 else 'bin.sh'
            self.wfile.write(make_malware_page(orig_ip, path or 'bin.sh'))
            return

        # ── 3. Suspicious domains → WARNING ──────────────────────
        if any(x in p for x in ['krypton','lomeqpe','lovable.app','newstan','thu-iphone']):
            self.wfile.write(make_warning_page(original))
            return

        # ── 4. Phishing BLOCKED ───────────────────────────────────
        if   'malware' in p or 'ransomware' in p or 'payload' in p or 'virus' in p: self.wfile.write(MALWARE_BLOCK)
        elif 'discord' in p:                                    self.wfile.write(DISCORD_BLOCK)
        elif 'coinbase' in p and 'warn' not in p:              self.wfile.write(COINBASE_BLOCK)
        elif 'ebay'     in p and 'warn' not in p:              self.wfile.write(EBAY_BLOCK)
        elif 'facebook' in p and 'warn' not in p:              self.wfile.write(FACEBOOK_BLOCK)
        elif 'twitter'  in p and 'warn' not in p:              self.wfile.write(TWITTER_BLOCK)
        elif 'instagram'in p and 'warn' not in p:              self.wfile.write(INSTAGRAM_BLOCK)
        elif 'google'   in p and 'warn' not in p:              self.wfile.write(GOOGLE_BLOCK)
        elif 'amazon'   in p and 'warn' not in p:              self.wfile.write(AMAZON_BLOCK)
        elif 'wells'    in p and 'warn' not in p:              self.wfile.write(WELLS_BLOCK)
        elif 'chase'    in p and 'warn' not in p:              self.wfile.write(CHASE_BLOCK)
        elif 'bank'     in p and 'warn' not in p:              self.wfile.write(BANK_BLOCK)
        elif 'microsoft'in p and 'warn' not in p:              self.wfile.write(MICROSOFT_BLOCK)
        elif 'netflix'  in p and 'warn' not in p:              self.wfile.write(NETFLIX_BLOCK)
        elif 'apple'    in p and 'warn' not in p:              self.wfile.write(APPLE_BLOCK)
        elif 'paypal'   in p and 'warn' not in p:              self.wfile.write(PAYPAL_BLOCK)
        # ── 5. WARNING ────────────────────────────────────────────
        elif 'warn-paypal'    in p or ('paypal'    in p and 'warn' in p): self.wfile.write(WARN_PAYPAL)
        elif 'warn-amazon'    in p or ('amazon'    in p and 'warn' in p): self.wfile.write(WARN_AMAZON)
        elif 'warn-microsoft' in p or ('microsoft' in p and 'warn' in p): self.wfile.write(WARN_MICROSOFT)
        elif 'warn-netflix'   in p or ('netflix'   in p and 'warn' in p): self.wfile.write(WARN_NETFLIX)
        elif 'warn-apple'     in p or ('apple'     in p and 'warn' in p): self.wfile.write(WARN_APPLE)
        elif 'warn-bank'      in p or ('bank'      in p and 'warn' in p): self.wfile.write(WARN_BANK)
        elif 'warn-google'    in p or ('google'    in p and 'warn' in p): self.wfile.write(WARN_GOOGLE)
        elif 'warn-facebook'  in p or ('facebook'  in p and 'warn' in p): self.wfile.write(WARN_FACEBOOK)
        elif 'warn-instagram' in p or ('instagram' in p and 'warn' in p): self.wfile.write(WARN_INSTAGRAM)
        elif 'warn-twitter'   in p or ('twitter'   in p and 'warn' in p): self.wfile.write(WARN_TWITTER)
        elif 'warn-ebay'      in p or ('ebay'      in p and 'warn' in p): self.wfile.write(WARN_EBAY)
        elif 'warn-coinbase'  in p or ('coinbase'  in p and 'warn' in p): self.wfile.write(WARN_COINBASE)
        elif 'warn'           in p:                                        self.wfile.write(WARN_PAYPAL)
        else: self.wfile.write(PAYPAL_BLOCK)

    def log_message(self, *args): pass

print("=" * 65)
print("  PhishingShield Pro - Test Server v4.1")
print("  Developer: Payal Gandharba | NP069619 | CT052-3-3-IR")
print("=" * 65)
print()
print("SAFE (30+):")
print("  https://www.google.com ... any https:// site")
print("  http://localhost:8080/urlhaus.abuse.ch/url/3904198/")
print()
print("WARNING (12+):")
print("  http://localhost:8080/warn-paypal")
print("  http://localhost:8080/warn-amazon ... and 10 more")
print("  http://localhost:8080/kryptonclientliista.lovable.app")
print("  http://localhost:8080/newstan.online/asset/update.dat")
print()
print("BLOCKED Phishing (16):")
print("  http://localhost:8080/paypal-login-verify-account-suspended")
print("  http://localhost:8080/netflix-billing-suspended-update-verify")
print("  ... and 14 more")
print()
print("BLOCKED URLhaus IPs (all 521 IPs):")
print("  http://localhost:8080/125.44.181.178/bin.sh    (Mirai)")
print("  http://localhost:8080/114.227.49.3/bin.sh      (Mozi)")
print("  http://localhost:8080/191.44.112.89/pito.x86   (Mirai Multi)")
print("  http://localhost:8080/62.60.249.165/main_arm7  (Gafgyt)")
print("  http://localhost:8080/94.154.32.238/s.ps1      (PowerShell)")
print("  http://localhost:8080/217.60.241.248/support.client.exe (RAT)")
print("  http://localhost:8080/62.60.226.140/Tz2SZvL.exe (Amadey)")
print("  ... ALL other IPs from URLhaus list")
print()
print("Server running at http://localhost:8080")
print("Keep this window open during demo!")
print("=" * 65)

HTTPServer(('', 8080), Handler).serve_forever()