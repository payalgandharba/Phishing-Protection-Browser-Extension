"""
PhishingShield Pro v4.0 — UAVIDS-2025 Module (Module 2)
Developer: Payal Gandharba | NP069619 | CT052-3-3-IR

SEPARATE module from the main UNSW-NB15 phishing/URL detector (Module 1).
Trained on the REAL UAVIDS-2025 dataset downloaded from:
    https://www.kaggle.com/datasets/qinglizeng1997/uavids-2025

Reference paper:
    Zeng, Q., Bashir, A., Nait-Abdesselam, F. "UAVIDS-2025: A Benchmark
    Dataset for Intrusion Detection in UAV Networks Using Machine
    Learning Techniques." IEEE CNS 2025.

HOW TO RUN:
    1. Place UAVIDS-2025.csv in ml/data/ (already done if using this package)
    2. Run: python ml/scripts/train_uavids.py
"""

import os, sys, json, pickle, time

print("=" * 60)
print("  PhishingShield Pro v4.0 — UAVIDS-2025 Module")
print("  Developer: Payal Gandharba | NP069619")
print("  Dataset:   UAVIDS-2025 (UAV Network Intrusion Detection)")
print("  Source:    kaggle.com/datasets/qinglizeng1997/uavids-2025")
print("=" * 60)

try:
    import pandas as pd
    import numpy as np
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.svm import SVC
    from sklearn.preprocessing import StandardScaler, LabelEncoder
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
    print("\n✅ All packages available")
except ImportError as e:
    print(f"\n❌ Missing package: {e}")
    print("Run: pip install pandas scikit-learn numpy")
    sys.exit(1)

CSV_PATHS = ["ml/data/UAVIDS-2025.csv", "UAVIDS-2025.csv"]
csv_path = next((p for p in CSV_PATHS if os.path.exists(p)), None)

if not csv_path:
    print("\n❌ UAVIDS-2025.csv not found.")
    print("   Download from: https://www.kaggle.com/datasets/qinglizeng1997/uavids-2025")
    print("   Place it in: ml/data/UAVIDS-2025.csv")
    sys.exit(1)

print(f"\n✅ Found: {csv_path}")
df = pd.read_csv(csv_path)
print(f"✅ Loaded: {len(df):,} records | {len(df.columns)} columns")

# ── Real column structure (confirmed from actual file) ──────────────
# FlowID, FlowDuration/s, SrcAddr, SrcPort, DstAddr, DstPort, Protocol,
# TxPackets, RxPackets, LostPackets, TxBytes, RxBytes, TxPacketRate/s,
# RxPacketRate/s, TxByteRate/s, RxByteRate/s, MeanDelay/s, MeanJitter/s,
# Throughput/Kbps, MeanPacketSize, PacketDropRate, AverageHopCount, label

print(f"\nClass distribution:")
print(df['label'].value_counts())

# Binary label: Normal Traffic = 0, any attack = 1
df['binary_label'] = (df['label'] != 'Normal Traffic').astype(int)
normal_count = (df['binary_label'] == 0).sum()
attack_count = (df['binary_label'] == 1).sum()
print(f"\nBinary — Normal: {normal_count:,} | Attack: {attack_count:,}")

# Encode categorical Protocol column (UDP/TCP)
proto_le = LabelEncoder()
df['Protocol'] = proto_le.fit_transform(df['Protocol'])

# Encode multi-class attack type for reference
attack_le = LabelEncoder()
df['attack_class'] = attack_le.fit_transform(df['label'])

# Feature columns — exclude IDs, IP addresses (not generalizable), and labels
exclude_cols = ['FlowID', 'SrcAddr', 'DstAddr', 'label', 'binary_label', 'attack_class']
feature_cols = [c for c in df.columns if c not in exclude_cols]
print(f"\n✅ Features used ({len(feature_cols)}): {feature_cols}")

X = df[feature_cols].values
y = df['binary_label'].values

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)
print(f"\nTrain: {len(X_train):,} | Test: {len(X_test):,}")

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

print("\n🧠 Training Random Forest (100 trees)...")
t0 = time.time()
rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
rf.fit(X_train_s, y_train)
rf_acc = accuracy_score(y_test, rf.predict(X_test_s))
print(f"   ✅ RF Accuracy: {rf_acc*100:.2f}% (trained in {time.time()-t0:.1f}s)")

print("\n🧠 Training SVM (RBF kernel, C=10)...")
t0 = time.time()
svm = SVC(kernel='rbf', C=10, probability=True, random_state=42)
# Subsample for SVM training speed (standard practice on large datasets)
sub_idx = np.random.RandomState(42).choice(len(X_train_s), min(8000, len(X_train_s)), replace=False)
svm.fit(X_train_s[sub_idx], y_train[sub_idx])
svm_acc = accuracy_score(y_test, svm.predict(X_test_s))
print(f"   ✅ SVM Accuracy: {svm_acc*100:.2f}% (trained in {time.time()-t0:.1f}s)")

rf_probs = rf.predict_proba(X_test_s)[:, 1]
svm_probs = svm.predict_proba(X_test_s)[:, 1]
ens_probs = rf_probs * 0.7 + svm_probs * 0.3
ens_preds = (ens_probs >= 0.5).astype(int)
ens_acc = accuracy_score(y_test, ens_preds)
print(f"\n✅ Ensemble Accuracy (RF×0.7 + SVM×0.3): {ens_acc*100:.2f}%")

cm = confusion_matrix(y_test, ens_preds).tolist()
report = classification_report(y_test, ens_preds, target_names=['Normal','Attack'], output_dict=True)
print("\nClassification Report:")
print(classification_report(y_test, ens_preds, target_names=['Normal','Attack']))

fi = sorted(zip(feature_cols, rf.feature_importances_), key=lambda x: -x[1])
print("\nTop 10 Feature Importances:")
for name, imp in fi[:10]:
    print(f"   {name}: {imp*100:.2f}%")

# Save models
os.makedirs("ml/models/uavids", exist_ok=True)
with open("ml/models/uavids/rf_model.pkl", "wb") as f: pickle.dump(rf, f)
with open("ml/models/uavids/svm_model.pkl", "wb") as f: pickle.dump(svm, f)
with open("ml/models/uavids/scaler.pkl", "wb") as f: pickle.dump(scaler, f)
with open("ml/models/uavids/proto_encoder.pkl", "wb") as f: pickle.dump(proto_le, f)

result = {
    "module": "uavids-2025",
    "dataset": "UAVIDS-2025 (real data from Kaggle)",
    "total_records": int(len(df)),
    "normal": int(normal_count),
    "attack": int(attack_count),
    "features": len(feature_cols),
    "feature_names": feature_cols,
    "train_size": int(len(X_train)),
    "test_size": int(len(X_test)),
    "rf_accuracy": round(rf_acc * 100, 2),
    "svm_accuracy": round(svm_acc * 100, 2),
    "ensemble_accuracy": round(ens_acc * 100, 2),
    "confusion_matrix": {"tn": cm[0][0], "fp": cm[0][1], "fn": cm[1][0], "tp": cm[1][1]},
    "precision_normal": round(report['Normal']['precision'], 3),
    "recall_normal": round(report['Normal']['recall'], 3),
    "f1_normal": round(report['Normal']['f1-score'], 3),
    "precision_attack": round(report['Attack']['precision'], 3),
    "recall_attack": round(report['Attack']['recall'], 3),
    "f1_attack": round(report['Attack']['f1-score'], 3),
    "feature_importances": {name: round(float(imp)*100, 2) for name, imp in fi[:10]},
    "attack_type_counts": df['label'].value_counts().to_dict(),
}
with open("uavids_result.json", "w") as f:
    json.dump(result, f, indent=2)

print(f"\n✅ UAVIDS-2025 MODULE TRAINING COMPLETE!")
print(f"   RF:       {rf_acc*100:.2f}%")
print(f"   SVM:      {svm_acc*100:.2f}%")
print(f"   Ensemble: {ens_acc*100:.2f}%")
print("\n📄 Saved: uavids_result.json")
print("📄 Saved: ml/models/uavids/*.pkl")
