# PhishingShield Pro v4.0 — ML Training Script
# Developer: Payal Gandharba | NP069619 | CyberShield Technologies
import os, json, pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

os.makedirs('models', exist_ok=True)
print("=" * 50)
print(" PhishingShield Pro v4.0 — ML Training")
print(" Developer: Payal Gandharba | NP069619")
print("=" * 50)

np.random.seed(42)
N = 20000

print("\n[1/5] Generating dataset (20,000 URLs)...")

phish = pd.DataFrame({
    'url_length':       np.random.randint(60, 200, N//2),
    'domain_length':    np.random.randint(15, 60,  N//2),
    'path_length':      np.random.randint(10, 80,  N//2),
    'query_length':     np.random.randint(0,  50,  N//2),
    'num_dots':         np.random.randint(3,  8,   N//2),
    'num_hyphens':      np.random.randint(2,  8,   N//2),
    'num_digits':       np.random.randint(4,  15,  N//2),
    'num_at':           np.random.randint(0,  3,   N//2),
    'num_percent':      np.random.randint(0,  5,   N//2),
    'num_special':      np.random.randint(2,  10,  N//2),
    'num_params':       np.random.randint(0,  5,   N//2),
    'has_ip':           np.random.randint(0,  2,   N//2),
    'is_https':         np.random.randint(0,  2,   N//2),
    'has_subdomain':    np.ones(N//2),
    'has_brand_kw':     np.ones(N//2),
    'has_suspicious':   np.ones(N//2),
    'has_free_tld':     np.random.randint(0,  2,   N//2),
    'has_punycode':     np.random.randint(0,  2,   N//2),
    'url_entropy':      np.random.uniform(3.5, 5.0, N//2),
    'domain_entropy':   np.random.uniform(3.0, 4.5, N//2),
    'path_entropy':     np.random.uniform(2.5, 4.0, N//2),
    'ratio_digits':     np.random.uniform(0.1, 0.4, N//2),
    'ratio_special':    np.random.uniform(0.05, 0.2, N//2),
    'is_shortened':     np.random.randint(0,  2,   N//2),
    'has_redirect':     np.random.randint(0,  2,   N//2),
    'has_login_path':   np.ones(N//2),
    'has_exe':          np.random.randint(0,  2,   N//2),
    'double_slash':     np.random.randint(0,  2,   N//2),
    'has_hex':          np.random.randint(0,  2,   N//2),
    'subdomain_count':  np.random.randint(2,  5,   N//2),
    'path_depth':       np.random.randint(2,  6,   N//2),
    'label': 1
})

legit = pd.DataFrame({
    'url_length':       np.random.randint(15, 60,  N//2),
    'domain_length':    np.random.randint(4,  20,  N//2),
    'path_length':      np.random.randint(0,  30,  N//2),
    'query_length':     np.random.randint(0,  20,  N//2),
    'num_dots':         np.random.randint(1,  3,   N//2),
    'num_hyphens':      np.random.randint(0,  2,   N//2),
    'num_digits':       np.random.randint(0,  4,   N//2),
    'num_at':           np.zeros(N//2),
    'num_percent':      np.zeros(N//2),
    'num_special':      np.random.randint(0,  3,   N//2),
    'num_params':       np.random.randint(0,  3,   N//2),
    'has_ip':           np.zeros(N//2),
    'is_https':         np.ones(N//2),
    'has_subdomain':    np.random.randint(0,  2,   N//2),
    'has_brand_kw':     np.zeros(N//2),
    'has_suspicious':   np.zeros(N//2),
    'has_free_tld':     np.zeros(N//2),
    'has_punycode':     np.zeros(N//2),
    'url_entropy':      np.random.uniform(2.0, 3.8, N//2),
    'domain_entropy':   np.random.uniform(1.5, 3.2, N//2),
    'path_entropy':     np.random.uniform(1.0, 2.8, N//2),
    'ratio_digits':     np.random.uniform(0.0, 0.1, N//2),
    'ratio_special':    np.random.uniform(0.0, 0.05, N//2),
    'is_shortened':     np.zeros(N//2),
    'has_redirect':     np.zeros(N//2),
    'has_login_path':   np.random.randint(0, 2, N//2),
    'has_exe':          np.zeros(N//2),
    'double_slash':     np.zeros(N//2),
    'has_hex':          np.zeros(N//2),
    'subdomain_count':  np.random.randint(0, 2, N//2),
    'path_depth':       np.random.randint(0, 3, N//2),
    'label': 0
})

df = pd.concat([phish, legit]).sample(frac=1, random_state=42).reset_index(drop=True)
features = [c for c in df.columns if c != 'label']
X = df[features].values
y = df['label'].values
print(f"    Dataset: {len(df):,} URLs | {features.__len__()} features | Phishing: {y.sum():,} | Legit: {(y==0).sum():,}")

print("\n[2/5] Splitting 80% train / 20% test...")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
print(f"    Train: {len(X_train):,} | Test: {len(X_test):,}")

print("\n[3/5] Scaling features...")
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

print("\n[4/5] Training Random Forest (100 trees)...")
rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
rf.fit(X_train_s, y_train)
rf_acc = accuracy_score(y_test, rf.predict(X_test_s))
print(f"    RF Accuracy:  {rf_acc*100:.2f}%")

print("\n[5/5] Training SVM (RBF kernel, C=10)...")
svm = SVC(kernel='rbf', C=10, probability=True, random_state=42)
svm.fit(X_train_s, y_train)
svm_acc = accuracy_score(y_test, svm.predict(X_test_s))
print(f"    SVM Accuracy: {svm_acc*100:.2f}%")

# Ensemble evaluation
rf_probs  = rf.predict_proba(X_test_s)[:,1]
svm_probs = svm.predict_proba(X_test_s)[:,1]
ensemble  = rf_probs * 0.7 + svm_probs * 0.3
ens_preds = (ensemble > 0.5).astype(int)
ens_acc   = accuracy_score(y_test, ens_preds)
print(f"    Ensemble Accuracy: {ens_acc*100:.2f}%")

print("\nSaving models...")
pickle.dump(rf,     open('models/rf_model.pkl',  'wb'))
pickle.dump(svm,    open('models/svm_model.pkl', 'wb'))
pickle.dump(scaler, open('models/scaler.pkl',    'wb'))
json.dump(features, open('models/feature_names.json', 'w'))
json.dump({
    'rf_accuracy': rf_acc, 'svm_accuracy': svm_acc, 'ensemble_accuracy': ens_acc,
    'features': len(features), 'train_size': len(X_train), 'test_size': len(X_test),
    'ensemble_formula': 'RF*0.7 + SVM*0.3', 'version': '4.0.0'
}, open('models/eval_results.json', 'w'), indent=2)

print("\n" + "=" * 50)
print(f" ✅ Training Complete!")
print(f"    RF Accuracy:       {rf_acc*100:.2f}%")
print(f"    SVM Accuracy:      {svm_acc*100:.2f}%")
print(f"    Ensemble Accuracy: {ens_acc*100:.2f}%")
print(f"    Models saved to:   models/")
print("=" * 50)
