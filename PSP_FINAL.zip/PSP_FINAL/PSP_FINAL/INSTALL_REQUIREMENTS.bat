@echo off
echo =====================================================
echo  PhishingShield Pro v4.1 - Install Requirements
echo  Developer: Payal Gandharba NP069619
echo =====================================================
echo.
cd /d %~dp0
echo Installing Python packages...
pip install fastapi uvicorn scikit-learn pandas numpy playwright python-multipart
echo.
echo Installing Playwright Chromium (for Sandboxed Preview)...
python -m playwright install chromium
echo.
echo =====================================================
echo  Done! Next steps:
echo  1. Add CSV files to ml\data\
echo  2. Run TRAIN_MODELS.bat
echo  3. Run RUN_API.bat
echo  4. Load extension\ in chrome://extensions
echo =====================================================
pause
