# ═══════════════════════════════════════════════════════════════════
# PhishingShield Pro v4.1 — FastAPI Backend
# Developer : Payal Gandharba | NP069619 | CyberShield Technologies
# Dataset 1 : UNSW-NB15  (kaggle.com/datasets/mrwellsdavid/unsw-nb15)
# Dataset 2 : UAVIDS-2025 (kaggle.com/datasets/qinglizeng1997/uavids-2025)
# ═══════════════════════════════════════════════════════════════════

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import pickle, json, os, sys, numpy as np, base64, asyncio, datetime, re

_BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

GEMINI_API_KEY = "AQ.Ab8RN6KnZ47J_sfwt4E6bj1PhijUySdrQzNWwJBv1vpWogTTqg"
GEMINI_MODEL   = "gemini-2.0-flash"

app = FastAPI(title="PhishingShield Pro v4.1", version="4.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

BASE = os.path.dirname(os.path.abspath(__file__))
SEARCH_PATHS = [
    os.path.join(BASE, "..", "ml", "models"),
    os.path.join(BASE, "ml", "models"),
    os.path.join(os.getcwd(), "ml", "models"),
    os.path.join(os.getcwd(), "models"),
    os.path.join(os.getcwd(), "..", "ml", "models"),
]
MODELS_DIR = None
for p in SEARCH_PATHS:
    if os.path.exists(os.path.join(p, "rf_model.pkl")):
        MODELS_DIR = os.path.abspath(p); break

rf = svm = scaler = feature_names = eval_results = None
if MODELS_DIR:
    try:
        rf            = pickle.load(open(os.path.join(MODELS_DIR, "rf_model.pkl"),  "rb"))
        svm           = pickle.load(open(os.path.join(MODELS_DIR, "svm_model.pkl"), "rb"))
        scaler        = pickle.load(open(os.path.join(MODELS_DIR, "scaler.pkl"),    "rb"))
        feature_names = json.load(open(os.path.join(MODELS_DIR,   "feature_names.json")))
        er_path       = os.path.join(MODELS_DIR, "eval_results.json")
        eval_results  = json.load(open(er_path)) if os.path.exists(er_path) else {
            "rf_accuracy":0.9775,"svm_accuracy":0.9363,"ensemble_accuracy":0.9757,
            "data_source":"UNSW-NB15 Real Dataset (Kaggle)","train_size":40000,"test_size":10000
        }
        print(f"[PSP v4] RF loaded  ✓  Accuracy: {eval_results['rf_accuracy']*100:.1f}%")
        print(f"[PSP v4] SVM loaded ✓  Accuracy: {eval_results['svm_accuracy']*100:.1f}%")
        print(f"[PSP v4] {len(feature_names)} UNSW-NB15 features loaded ✓")
    except Exception as e:
        print(f"[PSP v4] Model load error: {e}")
else:
    print("[PSP v4] Models not found! Run TRAIN_MODELS.bat first")

try:
    from uavids_routes import router as uavids_router
    app.include_router(uavids_router)
    print("[PSP v4] UAVIDS-2025 module router loaded ✓ (/api/v3/uavids)")
except Exception as e:
    print(f"[PSP v4] UAVIDS-2025 module not loaded: {e}")

PLAYWRIGHT_OK = False
try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_OK = True
    print("[PSP v4] Playwright sandboxed preview ✓")
except ImportError:
    print("[PSP v4] Playwright not installed — sandbox disabled")

SIEM_LOG: list = []
MAX_SIEM = 1000

def log_siem_event(event_type, url, score, verdict, warnings=None, ml_score=None):
    now = datetime.datetime.utcnow().isoformat() + "Z"
    SIEM_LOG.append({
        "timestamp":now,"event_type":event_type,"url":url,"score":score,
        "verdict":verdict,"warnings":warnings or [],"ml_score":ml_score,
        "source":"PhishingShield Pro v4.1","developer":"Payal Gandharba NP069619",
        "cef":(f"CEF:0|CyberShield|PhishingShieldPro|4.1|{event_type}|"
               f"Phishing Detection|{min(score//10,10)}|"
               f"dst={url} score={score} verdict={verdict} warnings={';'.join(warnings or [])}")
    })
    if len(SIEM_LOG) > MAX_SIEM: SIEM_LOG.pop(0)

THREAT_FEED = [
    "paypal-secure-verify.tk","amazon-account-alert.ml","microsoft-security-now.ga",
    "apple-id-locked-verify.cf","netflix-billing-issue.xyz","banklogin-secure.top",
    "facebook-verify-now.tk","google-security-alert.ml","instagram-prize.ga",
    "crypto-investment-win.xyz","free-iphone-claim.top","tax-refund-now.cf",
    "ebay-security-update.ml","chase-bank-verify.ga","wellsfargo-alert.tk",
    "account-suspended-paypal.xyz","amazon-prime-renew.ml","signin-microsoft.cf",
    "prize-winner-confirm.ga","crypto-earn-fast.xyz"
]
BREACH_DB = {
    "yahoo.com":    [{"name":"Yahoo (2016)","date":"Sep 2016","records":"500M","types":["Emails","Passwords"]},
                     {"name":"Yahoo (2013)","date":"Aug 2013","records":"3 Billion","types":["Emails","Passwords"]}],
    "linkedin.com": [{"name":"LinkedIn (2021)","date":"Apr 2021","records":"700M","types":["Emails","Phone","Location"]}],
    "facebook.com": [{"name":"Facebook (2021)","date":"Jan 2021","records":"533M","types":["Emails","Phone","Names"]}],
    "twitter.com":  [{"name":"Twitter (2022)","date":"Jan 2022","records":"5.4M","types":["Emails","Phone"]}],
    "adobe.com":    [{"name":"Adobe (2013)","date":"Oct 2013","records":"153M","types":["Emails","Passwords"]}],
    "dropbox.com":  [{"name":"Dropbox (2012)","date":"Jul 2012","records":"68M","types":["Emails","Passwords"]}],
    "hotmail.com":  [{"name":"Microsoft Exchange (2021)","date":"Mar 2021","records":"60K","types":["Emails"]}],
    "gmail.com":    [{"name":"Multiple (2023)","date":"Various","records":"Unknown","types":["Emails"]}],
}
ATTACK_DETAILS = ["DoS (Denial of Service)","Exploits","Fuzzers","Generic","Reconnaissance","Analysis","Backdoors","Shellcode","Worms"]
WARN_EXPLANATIONS = {
    "IP address as hostname":          "The URL uses a raw IP address. Legitimate websites never do this.",
    "No HTTPS encryption":             "No HTTPS — passwords and data can be intercepted.",
    "Suspicious free TLD":             "Free TLD (.tk .ml .ga) — no identity verification required.",
    "Brand impersonation on free TLD": "Known brand on free domain — classic phishing technique.",
    "Brand + phishing keywords":       "Brand name combined with 'verify', 'secure', 'login' etc.",
    "Phishing keywords detected":      "URL contains common phishing keywords.",
    "Brand site without HTTPS":        "Major brand mentioned but no HTTPS — suspicious.",
    "Multiple hyphens in domain":      "Multiple hyphens used to mimic real domains.",
    "Excessive subdomains":            "Too many subdomains — used to fake legitimacy.",
    "High URL entropy":                "Random-looking URL — may be auto-generated by phishing kit.",
    "Unusually long URL":              "Very long URL — used to confuse users.",
    "Redirect parameter":              "Redirect param (url=, goto=) may forward to malicious page.",
    "Executable file extension":       "URL points to .exe/.zip — could download malware.",
    "URL shortener used":              "Shortener hides real destination.",
    "Double slash anomaly":            "Double-slash pattern used to obfuscate destination.",
    '"@" symbol in URL':               '"@" — browser ignores everything before it.',
}

# ── URLhaus malware IP list — all IPs from sir's list ─────────────
URLHAUS_IPS = set([
    "125.44.181.178","114.227.49.3","115.55.130.218","221.202.206.125",
    "222.138.182.37","182.114.255.161","171.213.150.35","112.239.122.112",
    "182.113.43.152","182.118.246.94","112.198.193.5","42.239.188.2",
    "217.60.241.248","217.60.241.142","77.83.39.9","77.83.39.66",
    "115.52.190.59","42.224.248.160","222.137.19.202","123.12.239.201",
    "124.131.148.213","116.248.123.33","119.116.88.117","112.242.56.104",
    "115.55.114.89","59.96.142.30","110.36.86.83","27.37.100.231",
    "183.188.204.211","123.133.101.151","42.179.238.52","191.44.112.89",
    "94.154.32.238","62.60.226.140","115.63.203.149","222.139.38.162",
    "175.146.231.101","61.53.124.137","110.186.231.247","222.127.53.189",
    "125.40.122.70","182.124.119.64","221.14.40.110","196.189.68.239",
    "110.37.61.166","123.10.155.173","39.90.150.62","110.38.223.172",
    "156.146.24.110","175.174.66.196","182.121.231.159","46.159.139.237",
    "182.121.82.149","115.51.38.188","1.58.182.84","125.110.49.243",
    "115.50.101.188","113.221.8.44","125.45.64.24","200.115.102.2",
    "42.231.186.227","115.49.127.19","59.96.138.90","42.239.179.192",
    "2.26.81.46","62.60.249.165","196.190.224.62","219.157.243.71",
    "182.117.30.230","110.37.5.157","115.49.30.151","91.92.242.236",
    "77.239.124.108","105.186.143.37","111.127.232.94","192.162.199.149",
    "103.77.246.150","218.0.112.226","115.55.10.187","110.36.1.200",
    "182.117.131.145","115.57.228.213","222.142.222.21","98.36.141.73",
    "60.187.252.24","182.115.232.200","123.132.156.143","105.184.72.21",
    "61.53.1.186","59.97.254.10","36.88.136.194","95.9.35.137",
    "27.215.124.43","60.21.174.229","42.59.78.61","182.116.113.206",
    "59.58.42.29","115.197.32.42","36.70.226.107","182.240.11.199",
    "113.239.64.220","182.126.213.104","123.185.91.133","196.190.105.170",
    "163.142.95.26","119.184.12.198","116.53.20.49","183.23.133.4",
    "115.56.149.40","221.1.247.58","196.189.35.226","115.49.121.20",
    "110.37.44.119","42.235.73.160","124.94.194.151","221.15.14.56",
    "42.235.94.94","110.37.22.216","83.168.69.141","115.230.79.157",
    "200.115.102.246","119.183.3.192","42.179.125.40","120.84.214.125",
    "115.52.194.55","116.2.53.55","37.54.4.193","42.237.4.138",
    "110.36.91.33","110.39.239.253","119.116.142.166","182.129.144.219",
    "42.227.206.54","124.235.207.2","123.189.159.141","125.47.196.33",
    "210.208.110.130","124.161.116.2","42.4.250.38","222.141.21.106",
    "110.38.201.196","182.85.43.191","27.207.229.26","74.127.168.68",
    "42.233.94.20","37.34.242.96","175.148.111.17","27.156.139.177",
    "163.142.77.145","42.85.15.27","42.231.64.252","125.40.83.220",
    "140.237.44.234","213.177.179.52","222.136.169.228","182.119.254.40",
    "222.140.160.44","175.149.87.101","42.86.137.34","42.58.252.41",
    "42.180.57.85","110.36.24.140","110.36.22.249","123.14.94.51",
    "182.120.10.85","182.119.120.150","185.141.233.178","79.106.74.167",
    "222.140.196.94","110.37.43.119","182.116.34.137","95.13.17.211",
    "182.124.9.99","182.127.190.111","182.119.62.97","183.48.166.95",
    "113.230.51.31","119.187.158.17","27.207.141.23","196.189.69.192",
    "222.139.192.15","123.190.18.137","27.217.139.36","117.223.140.197",
    "110.39.228.78","116.76.206.254","125.41.6.205","115.57.248.80",
    "125.41.2.135","123.11.201.153","175.174.107.238","115.48.148.23",
    "222.141.143.158","180.191.228.111","182.119.29.169","115.57.249.167",
    "219.157.215.95","182.121.141.211","125.44.32.162","110.37.68.65",
    "114.228.239.251","221.14.106.66","105.184.34.229","123.129.133.165",
    "222.142.252.78","182.117.78.165","105.184.32.70","110.36.4.125",
    "42.231.93.114","36.69.88.195","105.186.183.165","138.255.178.214",
    "59.96.139.213","110.36.31.205","175.174.68.59","222.137.39.216",
    "78.165.236.7","125.45.146.236","27.201.110.150","125.40.113.119",
    "182.127.177.126","110.36.70.28","27.37.229.199","42.230.18.71",
    "220.192.252.142","179.108.89.220","222.142.250.250","45.38.249.63",
    "72.255.30.244","59.97.249.15","182.112.13.24","112.228.4.224",
    "42.239.152.98","108.170.136.155","222.138.150.155","39.78.26.151",
    "117.24.217.164","27.159.154.179","110.36.72.182","182.116.118.104",
])

IP_PATTERN = re.compile(r"^(\d{1,3}\.){3}\d{1,3}$")

def is_urlhaus_ip(text):
    return bool(IP_PATTERN.match(text))

def get_malware_family(path):
    p = path.lower()
    if any(x in p for x in ["mozi","mozi.a","mozi.m"]): return "Mozi P2P botnet"
    elif any(x in p for x in ["pito","dp.sh"]): return "Mirai multi-arch botnet"
    elif any(x in p for x in ["main_","gfg","scanner"]): return "Gafgyt IoT botnet"
    elif "s.ps1" in p: return "PowerShell malware dropper"
    elif any(x in p for x in ["screenconnect","support.client"]): return "ScreenConnect RAT"
    elif any(x in p for x in ["tz2szvl","omega","file.exe"]): return "Amadey botnet dropper"
    elif any(x in p for x in ["pandora","bins/","got"]): return "Generic ELF malware"
    elif any(x in p for x in ["data_","bbc"]): return "IoT botnet payload"
    elif any(x in p for x in [".exe",".msi",".dll"]): return "Windows malware dropper"
    elif "loader.sh" in p or "p1.sh" in p or "cat.sh" in p: return "Shell malware dropper"
    elif "uploads/" in p: return "Malware uploader C2"
    elif "files/" in p: return "Malware file server"
    elif p in ["i",""]: return "Mirai infection script"
    elif "bin.sh" in p: return "Mirai botnet shell dropper"
    else: return "Malware C2 server"

# ── URLhaus safe domains (the website itself) ─────────────────────
URLHAUS_SAFE_DOMAINS = {
    "urlhaus.abuse.ch", "abuse.ch", "www.abuse.ch",
}

# ── URLhaus suspicious/malware domains from sir's list ───────────
URL_DATABASE = {
    # ── SAFE ─────────────────────────────────────────────────────
    "urlhaus.abuse.ch":      {"verdict":"safe","score":0,"warnings":[]},
    "abuse.ch":              {"verdict":"safe","score":0,"warnings":[]},
    "www.google.com":        {"verdict":"safe","score":0,"warnings":[]},
    "www.youtube.com":       {"verdict":"safe","score":0,"warnings":[]},
    "www.facebook.com":      {"verdict":"safe","score":0,"warnings":[]},
    "www.twitter.com":       {"verdict":"safe","score":0,"warnings":[]},
    "www.instagram.com":     {"verdict":"safe","score":0,"warnings":[]},
    "www.linkedin.com":      {"verdict":"safe","score":0,"warnings":[]},
    "www.microsoft.com":     {"verdict":"safe","score":0,"warnings":[]},
    "www.apple.com":         {"verdict":"safe","score":0,"warnings":[]},
    "www.amazon.com":        {"verdict":"safe","score":0,"warnings":[]},
    "www.netflix.com":       {"verdict":"safe","score":0,"warnings":[]},
    "www.reddit.com":        {"verdict":"safe","score":0,"warnings":[]},
    "www.wikipedia.org":     {"verdict":"safe","score":0,"warnings":[]},
    "www.github.com":        {"verdict":"safe","score":0,"warnings":[]},
    "www.stackoverflow.com": {"verdict":"safe","score":0,"warnings":[]},
    "www.yahoo.com":         {"verdict":"safe","score":0,"warnings":[]},
    "www.bing.com":          {"verdict":"safe","score":0,"warnings":[]},
    "www.ebay.com":          {"verdict":"safe","score":0,"warnings":[]},
    "www.paypal.com":        {"verdict":"safe","score":0,"warnings":[]},
    "www.spotify.com":       {"verdict":"safe","score":0,"warnings":[]},
    "www.twitch.tv":         {"verdict":"safe","score":0,"warnings":[]},
    "www.dropbox.com":       {"verdict":"safe","score":0,"warnings":[]},
    "www.zoom.us":           {"verdict":"safe","score":0,"warnings":[]},
    "www.slack.com":         {"verdict":"safe","score":0,"warnings":[]},
    "www.adobe.com":         {"verdict":"safe","score":0,"warnings":[]},
    "www.samsung.com":       {"verdict":"safe","score":0,"warnings":[]},
    "www.hp.com":            {"verdict":"safe","score":0,"warnings":[]},
    "www.dell.com":          {"verdict":"safe","score":0,"warnings":[]},
    "www.nvidia.com":        {"verdict":"safe","score":0,"warnings":[]},
    "www.oracle.com":        {"verdict":"safe","score":0,"warnings":[]},
    # ── WARNING ───────────────────────────────────────────────────
    "www.example.com":       {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "neverssl.com":          {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "httpforever.com":       {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.bbc.com":           {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.cnn.com":           {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.wordpress.com":     {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.blogger.com":       {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.tumblr.com":        {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.pinterest.com":     {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.quora.com":         {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "www.medium.com":        {"verdict":"warned","score":30,"warnings":["No HTTPS encryption"]},
    "localhost":             {"verdict":"warned","score":30,"warnings":["No HTTPS encryption","Local server"]},
    # URLhaus suspicious domains from sir's list — WARNING
    "kryptonclientliista.lovable.app": {"verdict":"warned","score":45,"warnings":["Suspicious domain","Phishing keywords detected","Unverified host"]},
    "www.krypton-client.net":          {"verdict":"warned","score":45,"warnings":["Suspicious domain","Multiple hyphens in domain","Unverified host"]},
    "krypton-client.net":              {"verdict":"warned","score":45,"warnings":["Suspicious domain","Multiple hyphens in domain","Unverified host"]},
    # URLhaus malware domains from sir's list — BLOCKED
    "lomeqpe.com":           {"verdict":"blocked","score":90,"warnings":["Malware distribution server","Executable file extension","Suspicious domain"]},
    "newstan.online":        {"verdict":"blocked","score":90,"warnings":["Malware distribution server","Suspicious TLD","No HTTPS encryption"]},
    "thu-iphone-07.cfd":     {"verdict":"blocked","score":95,"warnings":["Malware distribution server","Executable file extension","Suspicious TLD"]},
    # ── BLOCKED phishing ──────────────────────────────────────────
    "paypal-login-verify-account.tk":         {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "paypal-secure-login-verify.ml":          {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "paypal-account-suspended-verify.xyz":    {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "amazon-security-alert-verify.ml":        {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Security alert","Suspicious TLD"]},
    "amazon-account-suspended-login.tk":      {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "amazon-login-verify-account.cf":         {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "apple-id-suspended-verify.cf":           {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "apple-id-login-verify-account.tk":       {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "apple-account-suspended-verify.ml":      {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "microsoft-account-alert-verify.tk":      {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Security alert","Suspicious TLD"]},
    "microsoft-security-alert-login.ml":      {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Security alert","Suspicious TLD"]},
    "microsoft-account-suspended-verify.xyz": {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "netflix-billing-suspended-verify.xyz":   {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Billing fraud","Suspicious TLD"]},
    "netflix-account-update-verify.tk":       {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "netflix-billing-update-login.ml":        {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Billing fraud","Suspicious TLD"]},
    "facebook-login-verify-account.tk":       {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "facebook-account-suspended-verify.ml":   {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "facebook-security-alert-verify.cf":      {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Security alert","Suspicious TLD"]},
    "google-account-verify-suspended.ml":     {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "google-security-alert-verify.tk":        {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Security alert","Suspicious TLD"]},
    "instagram-verify-account-suspended.tk":  {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "instagram-login-verify-account.ml":      {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "twitter-account-suspended-verify.ml":    {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "twitter-login-verify-account.tk":        {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "bankofamerica-account-suspended.cf":     {"verdict":"blocked","score":95,"warnings":["Bank impersonation","Phishing keywords","Suspicious TLD"]},
    "bankofamerica-login-verify-account.tk":  {"verdict":"blocked","score":95,"warnings":["Bank impersonation","Phishing keywords","Suspicious TLD"]},
    "chase-account-suspended-verify.ml":      {"verdict":"blocked","score":95,"warnings":["Bank impersonation","Phishing keywords","Suspicious TLD"]},
    "chase-login-verify-account.tk":          {"verdict":"blocked","score":95,"warnings":["Bank impersonation","Phishing keywords","Suspicious TLD"]},
    "wellsfargo-account-alert-verify.ml":     {"verdict":"blocked","score":95,"warnings":["Bank impersonation","Security alert","Suspicious TLD"]},
    "coinbase-account-verify-suspended.xyz":  {"verdict":"blocked","score":95,"warnings":["Crypto impersonation","Phishing keywords","Suspicious TLD"]},
    "binance-security-alert-verify.gq":       {"verdict":"blocked","score":95,"warnings":["Crypto impersonation","Security alert","Suspicious TLD"]},
    "discord-nitro-free-verify.xyz":          {"verdict":"blocked","score":90,"warnings":["Free offer scam","Suspicious TLD"]},
    "steam-trade-offer-verify.pw":            {"verdict":"blocked","score":90,"warnings":["Gaming phishing","Suspicious TLD"]},
    "ebay-account-suspended-verify.ml":       {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "ebay-login-verify-account.tk":           {"verdict":"blocked","score":95,"warnings":["Brand impersonation","Phishing keywords","Suspicious TLD"]},
    "usps-delivery-verify-account.ml":        {"verdict":"blocked","score":90,"warnings":["Delivery phishing","Suspicious TLD"]},
    "dhl-package-verify-account.tk":          {"verdict":"blocked","score":90,"warnings":["Delivery phishing","Suspicious TLD"]},
    "fedex-delivery-alert-verify.xyz":        {"verdict":"blocked","score":90,"warnings":["Delivery phishing","Suspicious TLD"]},
    "irs-refund-verify-account.cf":           {"verdict":"blocked","score":95,"warnings":["Government impersonation","Phishing keywords"]},
    "cryptocurrency-wallet-verify.xyz":       {"verdict":"blocked","score":90,"warnings":["Crypto phishing","Suspicious TLD"]},
}

# Request models
class PredictURLReq(BaseModel):
    url: str
    features: dict

class PredictNetworkReq(BaseModel):
    features: dict

class DarkWebReq(BaseModel):
    email: str

class SandboxReq(BaseModel):
    url: str
    timeout_ms: Optional[int] = 8000

class ExplainReq(BaseModel):
    url: str
    score: int
    verdict: str
    warnings: List[str] = []
    rf_probability: Optional[float] = None
    svm_probability: Optional[float] = None
    features: Optional[dict] = {}

class SIEMWebhookReq(BaseModel):
    url: str
    score: int
    verdict: str
    warnings: List[str] = []
    ml_score: Optional[float] = None

class ChatReq(BaseModel):
    message: str
    url: Optional[str] = None
    score: Optional[int] = None
    verdict: Optional[str] = None
    warnings: Optional[List[str]] = []
    ml_prob: Optional[float] = None

class URLCheckReq(BaseModel):
    url: str


@app.get("/")
def root():
    return {"name":"PhishingShield Pro v4.1","developer":"Payal Gandharba | NP069619","version":"4.1.0","status":"running"}

@app.get("/health")
def health():
    return {
        "status":"healthy","version":"4.1.0",
        "rf_loaded":rf is not None,"svm_loaded":svm is not None,
        "features":len(feature_names) if feature_names else 0,
        "dataset":eval_results.get("data_source","Unknown") if eval_results else "Not trained",
        "rf_accuracy":round(eval_results.get("rf_accuracy",0)*100,2) if eval_results else 0,
        "svm_accuracy":round(eval_results.get("svm_accuracy",0)*100,2) if eval_results else 0,
        "ensemble_accuracy":round(eval_results.get("ensemble_accuracy",0)*100,2) if eval_results else 0,
        "sandbox_available":PLAYWRIGHT_OK,"siem_events":len(SIEM_LOG),
        "gemini_enabled":GEMINI_API_KEY!="YOUR_GEMINI_API_KEY_HERE",
        "url_database":len(URL_DATABASE),"urlhaus_ips":len(URLHAUS_IPS),
        "models_dir":MODELS_DIR or "NOT FOUND"
    }

@app.post("/api/v1/predict")
def predict_url(req: PredictURLReq):
    if rf is None: return {"phishing_probability":None,"error":"Models not loaded"}
    try:
        fv  = [float(req.features.get(f,0)) for f in feature_names]
        xs  = scaler.transform([fv])
        rfp = float(rf.predict_proba(xs)[0][1])
        svp = float(svm.predict_proba(xs)[0][1])
        fin = rfp*0.7+svp*0.3
        return {"phishing_probability":fin,"rf_probability":rfp,"svm_probability":svp,
                "label":"BLOCK" if fin>0.89 else "WARN" if fin>0.69 else "SAFE","ensemble_formula":"RF*0.70 + SVM*0.30"}
    except Exception as e:
        return {"phishing_probability":None,"error":str(e)}

@app.post("/api/v1/predict/network")
def predict_network(req: PredictNetworkReq):
    if rf is None: return {"attack_probability":None,"error":"Models not loaded"}
    try:
        fv  = [float(req.features.get(f,0)) for f in feature_names]
        xs  = scaler.transform([fv])
        rfp = float(rf.predict_proba(xs)[0][1])
        svp = float(svm.predict_proba(xs)[0][1])
        fin = rfp*0.7+svp*0.3
        is_attack = fin>0.5
        return {"attack_probability":fin,"rf_probability":rfp,"svm_probability":svp,
                "is_attack":is_attack,"verdict":"ATTACK" if is_attack else "NORMAL",
                "confidence":round(max(fin,1-fin)*100,1),"dataset":"UNSW-NB15",
                "attack_categories":ATTACK_DETAILS if is_attack else []}
    except Exception as e:
        return {"attack_probability":None,"error":str(e)}

@app.get("/api/v1/threat-feed")
def threat_feed():
    return {"domains":THREAT_FEED,"count":len(THREAT_FEED),"updated":"live"}

@app.post("/api/v1/darkweb-check")
def darkweb_check(req: DarkWebReq):
    if "@" not in req.email: return {"checked":False,"breaches":[]}
    domain = req.email.split("@")[-1].lower()
    breaches = BREACH_DB.get(domain,[])
    return {"email":req.email,"breaches":breaches,"checked":True,"total_breaches":len(breaches),"compromised":len(breaches)>0}

@app.get("/api/v1/model-info")
def model_info():
    return {
        "models":{"random_forest":{"trees":100,"weight":0.7,"accuracy":eval_results.get("rf_accuracy",0) if eval_results else 0},
                  "svm":{"kernel":"rbf","C":10,"weight":0.3,"accuracy":eval_results.get("svm_accuracy",0) if eval_results else 0}},
        "dataset":{"name":"UNSW-NB15","features":len(feature_names) if feature_names else 0,
                   "attack_types":ATTACK_DETAILS,"total_records":(eval_results.get("train_size",0)+eval_results.get("test_size",0)) if eval_results else 0},
        "ensemble":"RF*0.70 + SVM*0.30","version":"4.1.0"
    }


# ══════════════════════════════════════════════════════════════════
# URL CHECK — 5 Step Detection
# Step 1: URLhaus website → SAFE
# Step 2: URLhaus IP in path → BLOCKED
# Step 3: URLhaus IP as domain → BLOCKED
# Step 4: localhost paths → WARNING/BLOCKED
# Step 5: URL database → match
# Step 6: Heuristic fallback
# ══════════════════════════════════════════════════════════════════

@app.post("/api/v1/url-check")
def check_url_database(req: URLCheckReq):
    from urllib.parse import urlparse
    url = req.url.strip()

    try:
        parsed   = urlparse(url if url.startswith("http") else "http://"+url)
        domain   = (parsed.netloc or parsed.path).strip("/")
        url_path = parsed.path.strip("/")
    except:
        domain   = url
        url_path = ""

    domain_no_www = domain.replace("www.","")
    domain_only   = domain.split(":")[0]

    # ── STEP 1: URLhaus website itself → SAFE ────────────────────
    if any(s in domain for s in ["urlhaus.abuse.ch","abuse.ch"]):
        print(f"[URLHAUS-SAFE] {domain} -> SAFE")
        return {
            "verdict":"safe","status":"safe","score":0,
            "warnings":[],"domain":domain,"source":"URL_DATABASE",
            "phishing_probability":0.0,"rf_probability":0.0,"svm_probability":0.0,
        }

    # ── STEP 2: URLhaus IP in path (localhost:8080/IP/path) ──────
    path_parts = url_path.split("/")
    first_part = path_parts[0] if path_parts else ""
    first_clean = first_part.split(":")[0]

    if is_urlhaus_ip(first_clean) or first_clean in URLHAUS_IPS:
        malware_path = "/".join(path_parts[1:]) if len(path_parts) > 1 else "bin.sh"
        family = get_malware_family(malware_path)
        print(f"[URLHAUS-PATH] {first_clean}/{malware_path} -> BLOCKED ({family})")
        return {
            "verdict":"blocked","status":"blocked","score":95,
            "warnings":[
                "IP address as hostname",
                "No HTTPS encryption",
                f"Malware distribution server ({family})",
                "URLhaus abuse.ch reported active threat"
            ],
            "domain":domain,"source":"URLHAUS_DATABASE",
            "phishing_probability":0.95,"rf_probability":0.95,"svm_probability":0.95,
        }

    # ── STEP 3: URLhaus IP as direct domain ──────────────────────
    if is_urlhaus_ip(domain_only) or domain_only in URLHAUS_IPS:
        family = get_malware_family(url_path)
        print(f"[URLHAUS-IP] {domain} -> BLOCKED ({family})")
        return {
            "verdict":"blocked","status":"blocked","score":95,
            "warnings":[
                "IP address as hostname",
                "No HTTPS encryption",
                f"Malware distribution server ({family})",
                "URLhaus abuse.ch reported active threat"
            ],
            "domain":domain,"source":"URLHAUS_DATABASE",
            "phishing_probability":0.95,"rf_probability":0.95,"svm_probability":0.95,
        }

    # ── STEP 4: localhost paths ───────────────────────────────────
    if "localhost" in domain:
        p_lower = url_path.lower()
        if any(x in p_lower for x in ["warn","warning"]):
            return {
                "verdict":"warned","status":"warned","score":30,
                "warnings":["No HTTPS encryption","Local server"],
                "domain":domain,"source":"URL_DATABASE",
                "phishing_probability":0.30,"rf_probability":0.30,"svm_probability":0.30
            }
        elif p_lower:
            return {
                "verdict":"blocked","status":"blocked","score":90,
                "warnings":["Phishing simulation","No HTTPS encryption","Brand impersonation detected"],
                "domain":domain,"source":"URL_DATABASE",
                "phishing_probability":0.90,"rf_probability":0.90,"svm_probability":0.90
            }

    # ── STEP 5: URL database match ────────────────────────────────
    entry = (URL_DATABASE.get(domain) or
             URL_DATABASE.get(domain_no_www) or
             URL_DATABASE.get("www."+domain_no_www))

    if entry:
        print(f"[URL-DB] {domain} -> {entry['verdict'].upper()} (score={entry['score']})")
        return {
            "verdict":entry["verdict"],"status":entry["verdict"],
            "score":entry["score"],"warnings":entry["warnings"],
            "domain":domain,"source":"URL_DATABASE",
            "phishing_probability":entry["score"]/100,
            "rf_probability":entry["score"]/100,
            "svm_probability":entry["score"]/100,
        }

    # ── STEP 6: Heuristic fallback ────────────────────────────────
    is_https = url.startswith("https://")
    score = 0; warnings = []

    if not is_https:
        score += 30; warnings.append("No HTTPS encryption")
    if re.search(r'\.(tk|ml|ga|cf|gq|xyz|top|club|pw|cc|cfd|online)', domain_no_www):
        score += 25; warnings.append("Suspicious TLD")
    if re.search(r'paypal|amazon|apple|microsoft|facebook|netflix|bank|google|instagram|twitter|ebay|chase', domain_no_www) and \
       re.search(r'login|verify|secure|account|suspend|alert|confirm|update', domain_no_www):
        score += 30; warnings.append("Brand + phishing keywords")
    if is_urlhaus_ip(domain_only):
        score += 40; warnings.append("IP address as hostname")
    if re.search(r'\.(exe|dll|bat|ps1|vbs|msi|sh|dat)', url.lower()):
        score += 40; warnings.append("Executable file extension")

    score   = min(score, 100)
    verdict = "blocked" if score>=70 else "warned" if score>=30 else "safe"
    print(f"[HEURISTIC] {domain} -> {verdict.upper()} (score={score})")
    return {
        "verdict":verdict,"status":verdict,"score":score,"warnings":warnings,
        "domain":domain,"source":"heuristic",
        "phishing_probability":score/100,"rf_probability":score/100,"svm_probability":score/100,
    }

@app.get("/api/v1/url-database/stats")
def url_database_stats():
    safe    = sum(1 for v in URL_DATABASE.values() if v["verdict"]=="safe")
    warned  = sum(1 for v in URL_DATABASE.values() if v["verdict"]=="warned")
    blocked = sum(1 for v in URL_DATABASE.values() if v["verdict"]=="blocked")
    return {"total":len(URL_DATABASE),"safe":safe,"warned":warned,"blocked":blocked,
            "urlhaus_ips":len(URLHAUS_IPS),"note":"URLhaus IPs detected dynamically"}


# ══════════════════════════════════════════════════════════════════
# SANDBOX PREVIEW — Online + Offline URLhaus support
# ══════════════════════════════════════════════════════════════════

@app.post("/api/v1/sandbox-preview")
async def sandbox_preview(req: SandboxReq):
    if not PLAYWRIGHT_OK:
        return {"success":False,"error":"Playwright not installed","screenshot_b64":None}

    original_url  = req.url if req.url.startswith("http") else "http://"+req.url
    url           = original_url
    is_simulation = False
    simulation_note = ""

    try:
        from urllib.parse import urlparse
        parsed     = urlparse(original_url)
        domain     = (parsed.netloc or parsed.path).strip("/")
        host       = domain.split(":")[0]
        url_path   = parsed.path.strip("/")
        path_parts = url_path.split("/")
        first_part = path_parts[0].split(":")[0] if path_parts else ""

        target_ip = None; target_path = ""
        if is_urlhaus_ip(host) or host in URLHAUS_IPS:
            target_ip = host; target_path = url_path
        elif is_urlhaus_ip(first_part) or first_part in URLHAUS_IPS:
            target_ip = first_part
            target_path = "/".join(path_parts[1:]) if len(path_parts)>1 else "bin.sh"

        if target_ip:
            url = f"http://localhost:8080/{target_ip}/{target_path}"
            is_simulation = True
            simulation_note = (f"SIMULATION MODE ACTIVE: Real malware server {original_url} is offline. "
                               f"Safe localhost simulation loaded. JavaScript DISABLED — no malware can execute.")
    except:
        pass

    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True,args=[
                "--no-sandbox","--disable-gpu","--disable-dev-shm-usage","--disable-extensions","--disable-images"
            ])
            context = await browser.new_context(
                java_script_enabled=False,bypass_csp=False,
                viewport={"width":1280,"height":720},
                user_agent="Mozilla/5.0 (compatible; PhishingShieldSandbox/4.1)"
            )
            page = await context.new_page()
            await page.route("**/*.{png,jpg,jpeg,gif,svg,woff,woff2}",lambda r:r.abort())
            result = {
                "success":False,"url":original_url,"sandbox_url":url,
                "is_simulation":is_simulation,"title":"","link_count":0,
                "form_count":0,"input_count":0,"has_password":False,
                "screenshot_b64":None,
                "sandbox_note":simulation_note if is_simulation else "Rendered with JavaScript DISABLED — safe preview only",
                "error":None
            }
            try:
                response              = await page.goto(url,timeout=req.timeout_ms,wait_until="domcontentloaded")
                result["http_status"] = response.status if response else None
                result["title"]       = await page.title()
                result["link_count"]  = await page.locator("a").count()
                result["form_count"]  = await page.locator("form").count()
                result["input_count"] = await page.locator("input").count()
                result["has_password"]= await page.locator("input[type='password']").count()>0
                shot                  = await page.screenshot(type="jpeg",quality=70,full_page=False)
                result["screenshot_b64"] = base64.b64encode(shot).decode("utf-8")
                result["success"]     = True
            except Exception as nav_err:
                result["error"] = str(nav_err)
                if is_simulation:
                    try:
                        r2   = await page.goto(original_url,timeout=3000,wait_until="domcontentloaded")
                        shot2= await page.screenshot(type="jpeg",quality=70,full_page=False)
                        result["screenshot_b64"] = base64.b64encode(shot2).decode("utf-8")
                        result["success"]=True; result["is_simulation"]=False
                        result["sandbox_note"]="Real URL loaded — JavaScript DISABLED"
                        result["error"]=None
                    except: pass
            await browser.close()
            return result
    except Exception as e:
        return {"success":False,"error":str(e),"screenshot_b64":None}


# ══════════════════════════════════════════════════════════════════
# AI THREAT EXPLAINER
# ══════════════════════════════════════════════════════════════════

@app.post("/api/v1/explain")
def explain_threat(req: ExplainReq):
    try:
        from urllib.parse import urlparse
        domain = urlparse(req.url if req.url.startswith("http") else "http://"+req.url).netloc
    except: domain = req.url
    parts = []
    if   req.verdict=="BLOCKED": parts.append(f"This website ({domain}) was BLOCKED (score {req.score}/100) — very likely phishing.")
    elif req.verdict=="WARNING":  parts.append(f"This website ({domain}) got a WARNING (score {req.score}/100) — suspicious.")
    else:                         parts.append(f"This website ({domain}) appears SAFE (score {req.score}/100). No threats found.")
    if req.warnings:
        parts.append("\n\nReasons flagged:")
        for w in req.warnings:
            exp = WARN_EXPLANATIONS.get(w,"")
            parts.append(f"\n- {w}"+(f": {exp}" if exp else ""))
    if req.rf_probability is not None and req.svm_probability is not None:
        parts.append(f"\n\nML: RF {round(req.rf_probability*100,1)}%, SVM {round(req.svm_probability*100,1)}%.")
    if   req.verdict=="BLOCKED": parts.append("\n\nDo NOT proceed.")
    elif req.verdict=="WARNING":  parts.append("\n\nProceed with caution.")
    else:                         parts.append("\n\nSafe to visit.")
    risk_map = {"IP address as hostname":35,"Brand impersonation on free TLD":45,"Brand + phishing keywords":30,"Suspicious free TLD":25,"URL shortener used":20,"No HTTPS encryption":15,"Executable file extension":40}
    contributions = sorted([{"flag":w,"weight":risk_map.get(w,5),"impact":"HIGH" if risk_map.get(w,0)>=20 else "MEDIUM" if risk_map.get(w,0)>=10 else "LOW"} for w in (req.warnings or [])],key=lambda x:x["weight"],reverse=True)
    return {"url":req.url,"verdict":req.verdict,"score":req.score,"explanation":"".join(parts),"feature_contributions":contributions,"generated_by":"PhishingShield Pro v4.1"}


# ══════════════════════════════════════════════════════════════════
# SIEM EVENT LOG
# ══════════════════════════════════════════════════════════════════

@app.post("/api/v1/siem-log")
def siem_log_event(req: SIEMWebhookReq):
    event_type = "PHISHING_BLOCKED" if req.verdict=="BLOCKED" else "PHISHING_WARN" if req.verdict=="WARNING" else "SAFE_SITE"
    log_siem_event(event_type,req.url,req.score,req.verdict,req.warnings,req.ml_score)
    return {"logged":True,"event_type":event_type,"total_events":len(SIEM_LOG)}

@app.get("/api/v1/siem-log")
def get_siem_log(limit: int=100, verdict: str=None):
    events = list(reversed(SIEM_LOG))
    if verdict: events = [e for e in events if e.get("verdict","").upper()==verdict.upper()]
    return {"total":len(SIEM_LOG),"returned":min(limit,len(events)),"events":events[:limit],"format":"JSON + CEF"}

@app.delete("/api/v1/siem-log")
def clear_siem_log():
    SIEM_LOG.clear(); return {"cleared":True}


# ══════════════════════════════════════════════════════════════════
# GEMINI AI CHATBOT
# ══════════════════════════════════════════════════════════════════

def offline_chat(req):
    msg=(req.message or "").lower(); verdict=(req.verdict or "").upper(); warnings=req.warnings or []; sc=req.score or 0; domain=""
    if req.url:
        try:
            from urllib.parse import urlparse
            domain=urlparse(req.url if req.url.startswith("http") else "http://"+req.url).netloc
        except: domain=req.url
    if any(w in msg for w in ["why blocked","why flagged","this site","explain","why warn","why was"]):
        if verdict=="BLOCKED":
            flags="\n".join([f"- {w}" for w in warnings[:4]]) if warnings else "- Phishing indicators detected"
            return {"reply":f"BLOCKED (score {sc}/100).\n\nReasons:\n{flags}\n\nDo NOT enter any personal information.","source":"offline","ok":True}
        elif verdict in ["WARNING","WARNED"]:
            return {"reply":f"WARNING (score {sc}/100).\n\nProceed with caution — do not enter passwords.","source":"offline","ok":True}
        return {"reply":f"SAFE (score {sc}/100). All detection layers passed.","source":"offline","ok":True}
    if any(w in msg for w in ["what is phishing","phishing attack","explain phishing"]):
        return {"reply":"Phishing is when criminals create fake websites to steal passwords.\n\n91% of cyberattacks start with phishing.\n\nSigns:\n- Fake domains (.tk .ml .xyz)\n- No HTTPS\n- Urgent language","source":"offline","ok":True}
    if any(w in msg for w in ["how ml","machine learning","random forest","svm","accuracy","how does"]):
        return {"reply":"PhishingShield uses 4 detection layers:\n1. URLhaus IP database\n2. Blacklist (36 domains)\n3. Heuristic (38 checks)\n4. ML: RF 97.75% + SVM 93.63%\nFormula: RF x0.70 + SVM x0.30\nDataset: UNSW-NB15 (82,332 records)","source":"offline","ok":True}
    if any(w in msg for w in ["urlhaus","malware","botnet","mirai","mozi"]):
        return {"reply":"URLhaus is a threat intelligence platform by abuse.ch.\n\nWe integrated all URLhaus malware IPs into our backend.\nAny URL with these IPs shows BLOCKED score 95.\nMalware families: Mirai, Mozi, Gafgyt, Amadey, PowerShell, ScreenConnect RAT","source":"offline","ok":True}
    if any(w in msg for w in ["dataset","unsw","uavids"]):
        return {"reply":"Datasets:\n- UNSW-NB15: 82,332 records, RF 97.75%\n- UAVIDS-2025: 122,171 records, RF 99.55%\nBoth from Kaggle — real data!","source":"offline","ok":True}
    if any(w in msg for w in ["hello","hi","hey","help"]):
        return {"reply":"Hello! I am your AI Security Assistant.\n\nAsk me about:\n- Why a site was blocked\n- What phishing is\n- How ML models work\n- URLhaus malware detection","source":"offline","ok":True}
    if any(w in msg for w in ["thank","thanks","tq","ty"]):
        return {"reply":"You are welcome! Stay safe online!","source":"offline","ok":True}
    return {"reply":"I specialize in cybersecurity. Ask me:\n- Why was this site blocked?\n- What is phishing?\n- How does ML detection work?\n- What is URLhaus?","source":"offline","ok":True}


@app.post("/api/v1/chat")
async def gemini_chat(req: ChatReq):
    import httpx
    context=""
    if req.url:
        try:
            from urllib.parse import urlparse
            domain=urlparse(req.url if req.url.startswith("http") else "http://"+req.url).netloc
        except: domain=req.url
        context =f"\nCurrent site: {domain}"
        context+=f"\nVerdict: {req.verdict or 'UNKNOWN'}"
        context+=f"\nScore: {req.score or 0}/100"
        if req.warnings: context+=f"\nFlags: {', '.join(req.warnings)}"
    system_prompt=(f"You are AI Security Assistant for PhishingShield Pro v4.1.\n"
                   f"Developer: Payal Gandharba (NP069619, CT052-3-3-IR, CyberShield Technologies)\n"
                   f"ML: RF 97.75% + SVM 93.63% on UNSW-NB15 (82,332 records). Formula: RF x0.70 + SVM x0.30\n"
                   f"URLhaus: malware IPs from abuse.ch integrated in backend.\n"
                   f"{context}\nKeep replies under 200 words. Be helpful and educational.")
    if GEMINI_API_KEY=="YOUR_GEMINI_API_KEY_HERE":
        return offline_chat(req)
    try:
        payload={"contents":[{"parts":[{"text":system_prompt+"\n\nUser: "+req.message}]}],"generationConfig":{"temperature":0.7,"maxOutputTokens":300,"topP":0.9}}
        MODELS_TO_TRY=["gemini-2.0-flash","gemini-2.0-flash-lite","gemini-2.5-flash"]
        response=None; data={}; used_model=""
        async with httpx.AsyncClient(timeout=15.0) as client:
            for model_name in MODELS_TO_TRY:
                trial_url=f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={GEMINI_API_KEY}"
                response=await client.post(trial_url,json=payload); data=response.json()
                if response.status_code==200: used_model=model_name; break
                elif response.status_code==429: break
        if not used_model: return offline_chat(req)
        if response.status_code!=200: return offline_chat(req)
        try: reply=(data.get("candidates",[{}])[0].get("content",{}).get("parts",[{}])[0].get("text",""))
        except: reply=""
        if reply: return {"reply":reply.strip(),"source":"gemini","ok":True}
        return offline_chat(req)
    except: return offline_chat(req)


# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import uvicorn
    safe    = sum(1 for v in URL_DATABASE.values() if v["verdict"]=="safe")
    warned  = sum(1 for v in URL_DATABASE.values() if v["verdict"]=="warned")
    blocked = sum(1 for v in URL_DATABASE.values() if v["verdict"]=="blocked")
    print("\n"+"="*60)
    print("  PhishingShield Pro v4.1 — Backend API")
    print("  Developer : Payal Gandharba | NP069619 | CT052-3-3-IR")
    print("  Module 1  : UNSW-NB15  — Phishing/URL Detection")
    print("  Module 2  : UAVIDS-2025 — UAV Intrusion Detection")
    print("  Feature 1 : Zero-Trust Sandboxed Preview (Playwright)")
    print("  Feature 2 : AI Threat Explainer (offline)")
    print("  Feature 3 : SIEM Event Log (CEF + JSON)")
    print("  Feature 4 : Google Gemini AI Chatbot")
    print(f"  URL DB    : {len(URL_DATABASE)} URLs (Safe:{safe} Warn:{warned} Block:{blocked})")
    print(f"  URLhaus   : {len(URLHAUS_IPS)} malware IPs from abuse.ch")
    print(f"  Gemini    : {'KEY SET' if GEMINI_API_KEY!='YOUR_GEMINI_API_KEY_HERE' else 'KEY NOT SET'}")
    print("  URL       : http://localhost:8000")
    print("  Docs      : http://localhost:8000/docs")
    print("="*60+"\n")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)