"""
PhishingShield Pro v4.0 — UAVIDS-2025 Module API Routes
Developer: Payal Gandharba | NP069619

SEPARATE module from the main UNSW-NB15 phishing detector.
Add this router to your existing main.py with:
    from uavids_routes import router as uavids_router
    app.include_router(uavids_router)
"""
from fastapi import APIRouter
from pydantic import BaseModel
import pickle, os, json

router = APIRouter(prefix="/api/v3/uavids", tags=["UAVIDS-2025 UAV Intrusion Detection"])

import os as _os, sys as _sys
_BACKEND_DIR2 = _os.path.dirname(_os.path.abspath(__file__))
_ROOT = _os.path.join(_BACKEND_DIR2, "..")
# Search for uavids models relative to project root
for _candidate in [
    _os.path.join(_ROOT, "ml", "models", "uavids"),
    _os.path.join(_os.getcwd(), "ml", "models", "uavids"),
    "ml/models/uavids"
]:
    if _os.path.exists(_os.path.join(_candidate, "rf_model.pkl")):
        MODELS_DIR = _os.path.abspath(_candidate)
        break
else:
    MODELS_DIR = _os.path.join(_ROOT, "ml", "models", "uavids")
rf_model = svm_model = scaler = proto_encoder = None
eval_results = {}

def load_uavids_models():
    global rf_model, svm_model, scaler, proto_encoder, eval_results
    try:
        with open(f"{MODELS_DIR}/rf_model.pkl", "rb") as f: rf_model = pickle.load(f)
        with open(f"{MODELS_DIR}/svm_model.pkl", "rb") as f: svm_model = pickle.load(f)
        with open(f"{MODELS_DIR}/scaler.pkl", "rb") as f: scaler = pickle.load(f)
        with open(f"{MODELS_DIR}/proto_encoder.pkl", "rb") as f: proto_encoder = pickle.load(f)
        print("[UAVIDS-2025] Models loaded ✓")
    except FileNotFoundError:
        print("[UAVIDS-2025] Models not found — run train_uavids.py first")
    try:
        if os.path.exists("uavids_result.json"):
            with open("uavids_result.json") as f:
                eval_results = json.load(f)
    except Exception:
        pass

load_uavids_models()

class UAVIDSFeatures(BaseModel):
    flow_duration: float = 1.0
    src_port: int = 80
    dst_port: int = 80
    protocol: str = "UDP"
    tx_packets: int = 100
    rx_packets: int = 100
    lost_packets: int = 0
    tx_bytes: float = 10000
    rx_bytes: float = 10000
    tx_packet_rate: float = 1.0
    rx_packet_rate: float = 1.0
    tx_byte_rate: float = 100.0
    rx_byte_rate: float = 100.0
    mean_delay: float = 0.02
    mean_jitter: float = 0.02
    throughput_kbps: float = 1.0
    mean_packet_size: float = 76
    packet_drop_rate: float = 0.05
    avg_hop_count: float = 0.1

@router.get("/health")
def uavids_health():
    return {
        "module": "UAVIDS-2025 UAV Network Intrusion Detection",
        "status": "healthy" if rf_model else "models not loaded",
        "rf_loaded": rf_model is not None,
        "svm_loaded": svm_model is not None,
        "dataset": "UAVIDS-2025 (kaggle.com/datasets/qinglizeng1997/uavids-2025)",
        "rf_accuracy": eval_results.get("rf_accuracy", "N/A"),
        "svm_accuracy": eval_results.get("svm_accuracy", "N/A"),
        "ensemble_accuracy": eval_results.get("ensemble_accuracy", "N/A"),
        "total_records": eval_results.get("total_records", "N/A"),
        "attack_types": ["Blackhole", "Flooding", "Sybil", "Wormhole"],
        "note": "This is a SEPARATE module from the UNSW-NB15 phishing detector"
    }

@router.post("/predict")
def uavids_predict(feats: UAVIDSFeatures):
    if not rf_model:
        return {"error": "UAVIDS-2025 models not trained yet. Run train_uavids.py first."}
    try:
        proto = proto_encoder.transform([feats.protocol])[0] \
                if feats.protocol in proto_encoder.classes_ else 0

        x = [[feats.flow_duration, feats.src_port, feats.dst_port, proto,
              feats.tx_packets, feats.rx_packets, feats.lost_packets,
              feats.tx_bytes, feats.rx_bytes, feats.tx_packet_rate,
              feats.rx_packet_rate, feats.tx_byte_rate, feats.rx_byte_rate,
              feats.mean_delay, feats.mean_jitter, feats.throughput_kbps,
              feats.mean_packet_size, feats.packet_drop_rate, feats.avg_hop_count]]

        x_scaled = scaler.transform(x)
        rf_prob = rf_model.predict_proba(x_scaled)[0][1]
        svm_prob = svm_model.predict_proba(x_scaled)[0][1]
        ensemble = rf_prob * 0.7 + svm_prob * 0.3

        return {
            "module": "UAVIDS-2025",
            "rf_probability": round(float(rf_prob), 4),
            "svm_probability": round(float(svm_prob), 4),
            "ensemble_probability": round(float(ensemble), 4),
            "verdict": "ATTACK" if ensemble >= 0.5 else "NORMAL"
        }
    except Exception as e:
        return {"error": str(e)}
