# PhishingShield Pro v4.1
**Developer:** Payal Gandharba | NP069619 | CT052-3-3-IR  
**Company:** CyberShield Technologies | Final Year Project

---

## Quick Start

```
1. INSTALL_REQUIREMENTS.bat   ← install everything
2. Add CSVs to ml\data\
3. TRAIN_MODELS.bat           ← train both ML models
4. RUN_API.bat                ← start backend
5. Load extension\ in chrome://extensions
```

---

## Project Structure

```
PhishingShield_Pro_v4.1\
├── backend\
│   ├── main.py              ← FastAPI (11 endpoints)
│   └── uavids_routes.py     ← UAVIDS-2025 Module 2
├── ml\
│   ├── data\                ← place CSV files here
│   ├── models\              ← pkl files saved here
│   │   └── uavids\
│   └── scripts\
│       ├── train_unsw.py
│       └── train_uavids.py
├── extension\
│   ├── manifest.json
│   ├── background\sw.js     ← detection engine (567 lines)
│   ├── content\content.js   ← warning banner
│   ├── popup\               ← redesigned popup + email analyzer
│   ├── blocked\             ← block warning page
│   ├── dashboard\           ← scan history dashboard
│   ├── settings\            ← 7-section settings page
│   └── icons\
├── INSTALL_REQUIREMENTS.bat
├── TRAIN_MODELS.bat
└── RUN_API.bat
```

---

## ML Results

| Model | Dataset | Accuracy |
|---|---|---|
| Random Forest | UNSW-NB15 | 97.75% |
| SVM (RBF) | UNSW-NB15 | 93.63% |
| Ensemble | UNSW-NB15 | 97.57% |
| Random Forest | UAVIDS-2025 | 99.55% |
| SVM (RBF) | UAVIDS-2025 | 97.53% |
| Ensemble | UAVIDS-2025 | 99.54% |

---

## API Endpoints

| Endpoint | Description |
|---|---|
| GET /health | Models status + accuracy |
| POST /api/v1/predict | Phishing URL prediction |
| GET /api/v1/threat-feed | Known phishing domains |
| POST /api/v1/darkweb-check | Email breach checker |
| GET /api/v1/model-info | Model details |
| POST /api/v1/sandbox-preview | Zero-trust screenshot |
| POST /api/v1/explain | AI threat explanation |
| POST /api/v1/siem-log | Log scan event (CEF) |
| GET /api/v1/siem-log | Retrieve SIEM events |
| GET /api/v3/uavids/health | UAVIDS module status |
| POST /api/v3/uavids/predict | UAV intrusion detection |

---

## New Features v4.1

1. **Zero-Trust Sandboxed Preview** — Playwright renders page with JS disabled
2. **AI Threat Explainer** — plain-English explanation of why site was flagged
3. **Gamified Micro-Training** — lesson card + streak badges after blocks
4. **SIEM Event Log** — CEF format for Splunk/Microsoft Sentinel
5. **Phishing Email Analyzer** — paste email text, scans all URLs found
6. **In-popup slide panels** — Dashboard, Settings, Trust all inside popup

---

## Datasets

- UNSW-NB15: kaggle.com/datasets/mrwellsdavid/unsw-nb15
- UAVIDS-2025: kaggle.com/datasets/qinglizeng1997/uavids-2025
