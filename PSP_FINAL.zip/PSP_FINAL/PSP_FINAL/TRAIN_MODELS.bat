@echo off
echo =====================================================
echo  PhishingShield Pro v4.1 - Train ML Models
echo  Developer: Payal Gandharba NP069619
echo =====================================================
echo.
cd /d %~dp0
echo [1/2] Training UNSW-NB15 (Module 1 - Phishing Detection)
echo       Requires: ml\data\UNSW_NB15_training-set.csv
echo.
python ml\scripts\train_unsw.py
echo.
echo [2/2] Training UAVIDS-2025 (Module 2 - UAV Intrusion Detection)
echo       Requires: ml\data\UAVIDS-2025.csv
echo.
python ml\scripts\train_uavids.py
echo.
echo =====================================================
echo  Training Complete! Models saved to ml\models\
echo  Now run RUN_API.bat
echo =====================================================
pause
