@echo off
echo =====================================================
echo  PhishingShield Pro v4.1 - Backend API
echo  Developer: Payal Gandharba NP069619
echo  Module 1: UNSW-NB15  (RF 97.75%% / SVM 93.63%%)
echo  Module 2: UAVIDS-2025 (RF 99.55%% / SVM 97.53%%)
echo  Features: Sandbox Preview + AI Explain + SIEM Log
echo =====================================================
echo.
cd /d %~dp0
if not exist "ml\models\rf_model.pkl" (
  echo [WARNING] Models not found!
  echo Please run TRAIN_MODELS.bat first
  echo Or copy your existing pkl files to ml\models\
  echo.
  pause
  exit /b
)
echo Models found. Starting API...
echo.
echo API:  http://localhost:8000
echo Docs: http://localhost:8000/docs
echo.
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
pause
